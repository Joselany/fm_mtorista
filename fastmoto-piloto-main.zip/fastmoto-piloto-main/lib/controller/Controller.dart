// ignore_for_file: non_constant_identifier_names
import 'package:get/get.dart';

class Controller extends GetxController{
  static Controller get to => Get.find();

  int status_pedido=0;
}