import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:geocoding/geocoding.dart';

double posicaoV1 = 0.0;
double posicaoV2 = 0.0;
double posicaoOrigemA = -8.81541043660967;
double posicaoOrigemB =  13.231317794043376;
double posicaoDestinoA = -8.826209609050453;
double posicaoDestinoB = 13.24330423814466;
var posicaomotorista;
var localMotorista;

class MapController extends GetxController {
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;


  late String _currentAddress;


  getAddress() async {
    try {
      List<Placemark> p =
          await placemarkFromCoordinates(latitude.value, longitude.value);
      Placemark place = p[0];
      posicaoV1 = latitude.value;
      posicaoV2 = longitude.value;
      _currentAddress =
          "${place.name}, ${place.locality}, ${place.postalCode}, ${place.country}";
      localMotorista = _currentAddress;
      posicaomotorista="$posicaoV1,$posicaoV2";
    } catch (e) {
      print(e);
    }
  }
  Future<Position> posicaoActual() async {
    LocationPermission permission;
    bool activado = await Geolocator.isLocationServiceEnabled();
    if (!activado) {
      return Future.error('Por favor, habilite a sua localização');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      return Future.error('Você precisa autorizar o acesso à localização');
    }

    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);
  }


  getPosition() async {
    try {
      final posicao = await posicaoActual();
      latitude.value = posicao.latitude;
      longitude.value = posicao.longitude;
      await getAddress();
    } catch (e) {
      Get.snackbar(
        'Erro',
        e.toString(),
        backgroundColor: Colors.grey[980],
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }
}
