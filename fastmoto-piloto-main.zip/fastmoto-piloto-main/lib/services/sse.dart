import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../config/Constats.dart';

class SSEService {
  static final SSEService _instance = SSEService._internal();
  factory SSEService() => _instance;
  SSEService._internal();

  final ValueNotifier<Map<String, dynamic>> sseDataNotifier = ValueNotifier({});

  void startSSE() {
    final Uri sseUrl = Uri.parse('$newEndpoint/sse');
    final client = http.Client();

    client.send(http.Request('GET', sseUrl)).then((response) {
      response.stream.transform(utf8.decoder).listen((message) {
        final event = json.decode(message);
        if (message.trim().isNotEmpty) {
          try {
            final event = json.decode(message);
            sseDataNotifier.value = event;
          } catch (e) {
          }
        }
      }, onError: (error) {
      });
    });
  }

  void stopSSE() {
    sseDataNotifier.value = {}; 
  }
}
