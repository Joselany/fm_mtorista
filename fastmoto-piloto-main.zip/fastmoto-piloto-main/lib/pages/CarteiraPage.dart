// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:fastmoto_piloto/pages/CarregarCarteiraPage.dart';
import 'package:fastmoto_piloto/pages/MovimentosCarteiraPage.dart';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import '../modelos/CardMovimentosCarteira.dart';
import 'Loading.dart';

var iban;
var titularBanco;
var banco;

class CarteiraPage extends StatefulWidget {
  @override
  _CarteiraPage createState() => _CarteiraPage();
}

class _CarteiraPage extends State<CarteiraPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var MovimentoCarteira;
  var dataActual = DateTime.now().add(const Duration(days: -7));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));

  bool carregado = false;
  loading load = loading();

  var dataEmpresa;
  var dataBanco;

  @override
  void initState() {
    super.initState();
    ConsultarMovimento();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future ConsultarMovimento() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/saldo-extrato');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      MovimentoCarteira = map['movimentos'];
      setState(() {
        SaldoConta = double.parse(map['saldo']);
        carregado = true;
      });
    } catch (e) {
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        CustomSnackBar.error(
          message: "$e",
        ),
      );
      print(e);
    }
  }

  Widget _daoMovimentos() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 0, bottom: 20),
      child: !carregado
          ? SizedBox(
              width: MediaQuery.of(context).size.width,
              child: const Center(
                child: Text(
                  "Nenhum Movimento",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: MovimentoCarteira.length,
              itemBuilder: (BuildContext context, int index) {
                return CardMovimentosCarteira(
                  id: MovimentoCarteira[index]['id'].toString(),
                  data: MovimentoCarteira[index]['data_movimento'],
                  valor: MovimentoCarteira[index]['valor'].toString(),
                  tipo: MovimentoCarteira[index]['tipo_movimento'],
                  metodo_pagamento: MovimentoCarteira[index]
                      ['metodo_movimento'],
                  estado: MovimentoCarteira[index]['status'].toString(),
                  comprovativo: MovimentoCarteira[index]['tipo_comprovativo'],
                );
              },
            ),
    );
  }

  Future getEmpresa() async {
    try {
      String baseURL = "$endpoint/dados-empresa";
      String request = '$baseURL?provincia=$reg';
      final response = await http.get(Uri.parse(request));
      final map = json.decode(response.body);
      setState(() {
        dataEmpresa = map["empresa"];
        dataBanco = map["contas_bancarias"];
        iban = dataBanco['iban'];
        banco = dataBanco['banco'];
        titularBanco = dataEmpresa['nome'];
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            elevation: 10,
            color: const Color(0xFFFF0066),
            shadowColor: const Color(0xFFFF0066),
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10))),
            child: InkWell(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: const Text(
                            "Saldo",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        IconButton(
                            onPressed: () {
                              Navigator.of(context).push(CupertinoPageRoute(
                                  builder: (BuildContext context) =>
                                      CarregarCarteiraPage()));
                            },
                            icon: const Icon(
                              Icons.add,
                              size: 50,
                              color: Colors.white,
                            ))
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                      alignment: Alignment.bottomLeft,
                      child: SaldoConta == null
                          ? const Text(
                              "0.00 KZ",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 40.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                            )
                          : Text(
                              NumberFormat.currency(locale: 'eu', symbol: 'KZ')
                                  .format(SaldoConta)
                                  .toString(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 40.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                            ),
                    ),
                  ],
                ),
              ),
              onTap: () {
                // Function is executed on tap.
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Movimentos recentes",
                  style: TextStyle(
                    color: Color(0xFFFF0066),
                    fontSize: 14.0,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'gotham',
                  ),
                ),
                Row(
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).push(CupertinoPageRoute(
                            builder: (BuildContext context) =>
                                MovimentosCarteiraPage()));
                      },
                      child: const Text(
                        "Filtrar movimentos",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 12.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(top: 0, bottom: 0),
              child: RefreshIndicator(
                  triggerMode: RefreshIndicatorTriggerMode.onEdge,
                  edgeOffset: 20,
                  strokeWidth: 3,
                  color: Colors.white,
                  backgroundColor: const Color(0xFFFF0066),
                  onRefresh: ConsultarMovimento,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        _daoMovimentos(),
                      ],
                    ),
                  )),
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Carteira",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
