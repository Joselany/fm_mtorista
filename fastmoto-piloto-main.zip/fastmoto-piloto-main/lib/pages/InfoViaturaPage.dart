import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

import 'SplashPage.dart';

class InfoViaturaPage extends StatefulWidget {
  @override
  _InfoViaturaPage createState() => _InfoViaturaPage();
}

class _InfoViaturaPage extends State<InfoViaturaPage> {
  loading load = loading();
  String? selectedCategoria;
  final TextEditingController _marca = TextEditingController();
  final TextEditingController _modelo = TextEditingController();
  final TextEditingController _matricula = TextEditingController();
  final TextEditingController _cor = TextEditingController();
  final TextEditingController _livrete = TextEditingController();
  final TextEditingController _titulo = TextEditingController();

  Future pegarDados() async {
    _marca.text = marca_viatura.toString();
    _modelo.text = modelo_viatura.toString();
    _matricula.text = matricula.toString();
    _cor.text = cor.toString();
    _livrete.text = livrete.toString();
    _titulo.text = titulo_propriedade.toString();
    selectedCategoria = categoria_motorista.toString();
  }

  List data = [];
  var res;

  Future getViaturas() async {
    try {
      String baseURL = "$endpoint/corridaapi/listar/viaturas";
      final response = await http.get(Uri.parse(baseURL));
      final map = json.decode(response.body);
      setState(() {
        data = map["viaturas"];
      });
    } catch (e) {
      print(e);
    }
  }

  Future getViaturaDados() async {
    try {
      String baseURL = "$endpoint/motoristaapi/dados";
      var response = await http.post(Uri.parse(baseURL), body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final info = map["info_motorista"];
      categoria_motorista = info['categoria'];
      marca_viatura = info['marca_viatura'];
      modelo_viatura = info['modelo_viatura'];
      matricula = info['matricula'];
      cor = info['cor'];
      livrete = info['livrete'];
      titulo_propriedade = info['titulo_propriedade'];
      validade_carta_conducao = info['validade_carta_conducao'];
      provincia_motorista = info['provincia'];
      // print("=== Result info: $info");
    } catch (e) {
      print(e);
    }
  }

  Future Registar() async {
    try {
      setState(() {
        btnRg4 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/info');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "marca_viatura": _marca.text,
        "modelo_viatura": _modelo.text,
        "matricula": _matricula.text,
        "categoria": selectedCategoria,
        "cor": _cor.text,
        "livrete": _livrete.text,
        "titulo_propriedade": _titulo.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["info_motorista"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Actualizado com sucesso.',
          ),
        );
        setState(() {
          btnRg4 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else if (msgr == 0) {
        setState(() {
          btnRg4 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao efectuar o registo.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg4 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getViaturaDados();
    pegarDados();
    getViaturas();
  }

  List<String> items = [
    'Categoria 1',
    'Categoria 2',
  ];

  Widget _TxtCategoria() {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        barrierColor: Colors.black12,
        style: const TextStyle(
          fontFamily: 'Gotham',
          color: Colors.black,
        ),
        buttonStyleData: ButtonStyleData(
          height: 60,
          width: MediaQuery.of(context).size.width * 0.8,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          overlayColor: WidgetStateProperty.all(Colors.black26),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.black12,
          ),
        ),
        isExpanded: true,
        hint: Text(
          categoria_motorista.toString(),
          style: const TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        items: data.map(
          (value) {
            return DropdownMenuItem(
              value: value['tipo'],
              child: Text(value['descricao']),
            );
          },
        ).toList(),
        value: selectedCategoria,
        onChanged: (value) {
          setState(() {
            selectedCategoria = value as String;
          });
        },
        menuItemStyleData: const MenuItemStyleData(
          height: 60, // Correção: altura dos itens definida aqui
          padding: EdgeInsets.symmetric(horizontal: 16),
        ),
        dropdownStyleData: const DropdownStyleData(
          maxHeight: 200,
          scrollPadding: EdgeInsets.all(8), // Ajuste para evitar sobreposição
        ),
      ),
    );
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: const Color(0xFFFF0066),
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        onPressed: btnRg4 == false
            ? () {
                if (selectedCategoria == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe a categoria.',
                    ),
                  );
                } else if (_marca.text == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe a marca da motorizada.',
                    ),
                  );
                } else if (_modelo.text == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe a cilindrada da motorizada.',
                    ),
                  );
                } else if (_cor.text == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe a cor da motorizada.',
                    ),
                  );
                } else if (_matricula.text == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe a matrícula da motorizada.',
                    ),
                  );
                } else if (_livrete.text == "") {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe o número do seu Livrete.',
                    ),
                  );
                } else {
                  Registar();
                }
              }
            : () {},
        child: Padding(
          padding: const EdgeInsets.only(top: 10.0),
          child: btnRg4 == false
              ? const Text(
                  'Concluir',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                  maxLines: 1,
                )
              : const CircularProgressIndicator.adaptive(
                  backgroundColor: Color(0xFFFF0066),
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
        ),
      ),
    );
  }

  Widget _TxtMarca() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Marca",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _marca,
      ),
    );
  }

  Widget _TxtModelo() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Cilindrada",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _modelo,
      ),
    );
  }

  Widget _TxtCor() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Cor",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _cor,
      ),
    );
  }

  Widget _TxtMatricula() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Matrícula",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _matricula,
      ),
    );
  }

  Widget _TxtLivrete() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Livrete",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _livrete,
      ),
    );
  }

  Widget _TxtTitulo() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Título de Propriedade",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.motorcycle_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _titulo,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(
                  height: 30,
                ),
                const Align(
                  alignment: Alignment.center,
                ),
                const SizedBox(
                  height: 5,
                ),
                _TxtCategoria(),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      children: [_TxtMarca()],
                    ),
                    Column(
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width * 0.02)
                      ],
                    ),
                    Column(
                      children: [_TxtModelo()],
                    )
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      children: [_TxtCor()],
                    ),
                    Column(
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width * 0.02)
                      ],
                    ),
                    Column(
                      children: [_TxtMatricula()],
                    )
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      children: [_TxtLivrete()],
                    ),
                    Column(
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width * 0.02)
                      ],
                    ),
                    Column(
                      children: [_TxtTitulo()],
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                _BtnComecar(),
                const SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Configurar dados da Motorizada",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
