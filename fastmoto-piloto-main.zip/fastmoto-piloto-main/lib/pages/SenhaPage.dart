import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';


class SenhaPage extends StatefulWidget {
  @override
  _SenhaPage createState() => _SenhaPage();
}

class _SenhaPage extends State<SenhaPage> {

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.black54,
            elevation: 5,
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            )),
        onPressed: () {

        },
        child: const Text(
          'Alterar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  Widget _TxtSenha1() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        obscureText: true,
        labelText: "Senha Actual",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.lock),
        validator: FormValidation.requiredTextField,
      ),
    );
  }

  Widget _TxtSenha2() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        obscureText: true,
        labelText: "Nova Senha",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.lock),
        validator: FormValidation.requiredTextField,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height: 80,
              width: MediaQuery.of(context).size.width / 1.5,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Alteração de Senha',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                  SizedBox(
                    height: 2,
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      'A alteração da senha deixa a conta mais segura.',
                      style: TextStyle(
                        color: Colors.black87,
                        letterSpacing: 0,
                        fontSize: 12.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham light',
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                'Informe as sua credenciais',
                style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 0,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                '',
                style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 0,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            _TxtSenha1(),
            const SizedBox(
              height: 10,
            ),
            _TxtSenha2(),
            const SizedBox(
              height: 10,
            ),
            const SizedBox(
              height: 20,
            ),
            _BtnComecar(),
          ],
        ),
      ),
      appBar: AppBar(
        actionsIconTheme: const IconThemeData(color: Color(0xFFb21414)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFb21414), size: 40),
        actions: const [],
      ),
    );
  }
}
