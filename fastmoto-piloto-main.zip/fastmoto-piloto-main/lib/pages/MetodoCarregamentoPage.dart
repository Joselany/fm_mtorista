import 'dart:convert';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import 'CarregarCarteiraPage.dart';
import 'CarteiraPage.dart';
import 'Loading.dart';

class MetodoCarregamentoPage extends StatefulWidget {
  @override
  _MetodoCarregamentoPage createState() => _MetodoCarregamentoPage();
}

class _MetodoCarregamentoPage extends State<MetodoCarregamentoPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  bool btnCarregar2 = false;

  @override
  void initState() {
    metodo_pagamento = "Cash";
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  List<Map> staticData = MyPay.data;
  List<bool> _isSelectedlist = [
    true,
    false,
    false,
  ];

  Widget Metodos() {
    return Expanded(
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 10),
        scrollDirection: Axis.vertical,
        itemCount: staticData.length,
        itemBuilder: (BuildContext context, int index) => Card(
          shape: RoundedRectangleBorder(
              side: BorderSide(
                color: _isSelectedlist[index] == true
                    ? const Color(0xFFFF0066)
                    : Colors.transparent,
                width: _isSelectedlist[index] == true ? 1 : 0,
              ),
              borderRadius: BorderRadius.circular(10)),
          borderOnForeground: true,
          elevation: _isSelectedlist[index] == true ? 2 : 0,
          color: _isSelectedlist[index] == true ? Colors.white70 : Colors.white,
          child: ListTile(
            selected: _isSelectedlist[index],
            dense: true,
            contentPadding: const EdgeInsets.only(top: 0, left: 10, right: 10),
            title: Text(
              staticData[index]['forma'].toString(),
              style: TextStyle(
                fontFamily: "Gotham",
                fontSize: _isSelectedlist[index] == true ? 25 : 20,
                // color: Colors.white,
              ),
            ),
            trailing: _isSelectedlist[index] == true
                ? Icon(
                    Icons.check_circle,
                    size: 15,
                    color: _isSelectedlist[index] == true
                        ? const Color(0xFFFF0066)
                        : Colors.white,
                  )
                : null,
            leading: staticData[index]['forma'] == "Cash"
                ? Icon(
                    Icons.payments_outlined,
                    color: _isSelectedlist[index] == true
                        ? const Color(0xFFFF0066)
                        : Colors.black54,
                  )
                : staticData[index]['forma'] == "TPA"
                    ? Icon(
                        Icons.payment,
                        color: _isSelectedlist[index] == true
                            ? const Color(0xFFFF0066)
                            : Colors.black54,
                      )
                    : Icon(
                        Icons.phone_android_rounded,
                        color: _isSelectedlist[index] == true
                            ? const Color(0xFFFF0066)
                            : Colors.black54,
                      ),
            selectedColor: const Color(0xFFFF0066),
            onLongPress: () {},
            onTap: () {
              print(staticData[index]['codigo']);
              metodo_pagamento = staticData[index]['codigo'];
              _updateList(index);
              setState(() {});
            },
          ),
        ),
      ),
    );
  }

  _updateList(int index) {
    _isSelectedlist[0] = false;
    _isSelectedlist[1] = false;
    _isSelectedlist[2] = false;
    if (_isSelectedlist[index] == true) {
      setState(() {
        _isSelectedlist[index] = false;
      });
    } else {
      setState(() {
        _isSelectedlist[index] = true;
      });
    }
  }

  loading load = loading();

  _OPC() {
    if (metodo_pagamento == 'Tranferencia') {
      setState(() {
        btnCarregar2 = false;
      });
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.info(
          message: 'Método de carregamento indisponível',
        ),
      );
    } else {
      CarregarSaldo();
    }
  }

  Future CarregarSaldo() async {
    setState(() {
      btnCarregar2 = true;
    });
    try {
      var url = Uri.parse('$endpoint/motoristaapi/saldo-carregar');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "metodo_movimento": metodo_pagamento.toString(),
        "valor": valor_carregamento,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar a carteira',
          ),
        );
      } else {
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        setState(() {
          btnCarregar2 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarteiraPage()));
      }
    } catch (e) {
      setState(() {
        btnCarregar2 = false;
      });
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print(e);
    }
  }

  Widget _BtnCarregar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnCarregar2 == false
            ? () {
                _OPC();
              }
            : () {},
        child: btnCarregar2 == false
            ? const Text(
                'Concluir',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Metodos(),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _BtnCarregar(),
                const SizedBox(
                  height: 100,
                )
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Escolher Método de Pagamento",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}

class MyPay {
  static List<Map> data = [
    {
      "id": 1,
      "codigo": "Cash",
      "forma": "Cash",
    },
    {
      "id": 2,
      "codigo": "TPA",
      "forma": "TPA",
    },
  ];
}
