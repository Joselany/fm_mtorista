import 'dart:convert';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/CardPagamentos.dart';

var totalGanhos;
var totalComissao;

class GanhosPage extends StatefulWidget {
  @override
  _GanhosPage createState() => _GanhosPage();
}

class _GanhosPage extends State<GanhosPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var dataActual = DateTime.now().add(const Duration(days: -7));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));
  var dadosViagem;
  bool carregado = false;

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 100,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.zero),
            color: Colors.white),
        child: Row(
          children: [
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width - 50,
                      height: 100,
                      child: totalGanhos == null
                          ? const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "Total geral:",
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontFamily: 'Gotham',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "0.0",
                                  style: TextStyle(
                                    fontSize: 25,
                                    fontFamily: 'Gotham',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const Text(
                                  "Total geral:",
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontFamily: 'Gotham',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  NumberFormat.currency(
                                          locale: 'eu', symbol: 'Kz')
                                      .format(totalGanhos)
                                      .toString(),
                                  style: const TextStyle(
                                    fontSize: 25,
                                    fontFamily: 'Gotham',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ],
                ),
                SizedBox(
                  width: 50,
                  height: 50,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _btnMoney(),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget _btnMoney() {
    return SizedBox(
      width: 45,
      height: 45,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0),
            )),
        onPressed: () {},
        child: const Icon(
          Icons.monetization_on_sharp,
          color: Color(0xFFFF0066),
          size: 30,
        ),
      ),
    );
  }

  @override
  void initState() {
    data1 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    data2 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual2));
    setState(() {});
    CarregarViagens();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future CarregarViagens() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/ganhos');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "data1": data1.text,
        "data2": data2.text,
      });
      final map = json.decode(response.body);
      dadosViagem = map['viagens'];
      totalGanhos = map["ganhos"];
      totalComissao = map["comissao"];
      setState(() {
        carregado = true;
      });
    } catch (e) {
      print(e);
    }
  }

  Widget _daoViagens() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregado
          ? SizedBox(
              width: MediaQuery.of(context).size.width,
              child: const Center(
                child: Text(
                  "Nenhum Movimento",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: dadosViagem.length,
              itemBuilder: (BuildContext context, int index) {
                return CardPagamentos(
                  id: dadosViagem[index]['id'].toString(),
                  data: dadosViagem[index]['inicio_viagem'],
                  valor: dadosViagem[index]['valor'].toString(),
                  valor_comissao: dadosViagem[index]['comissao'],
                  metodo_pagamento: dadosViagem[index]['metodo_pagamento'],
                );
              },
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Pagamentos",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
      body: Stack(
        children: [
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                  padding: const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(0),
                          color: Colors.white,
                        ),
                        width: MediaQuery.of(context).size.width,
                        height: 65,
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [_Data1()],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _Data2(),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            alignment: Alignment.center,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _daoViagens(),
              ],
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              children: [
                Row(
                  children: [
                    InfoBar(),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      data1 = TextEditingController(text: selectdata1);
      setState(() {
        CarregarViagens();
      });
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String Selectdata2 = DateFormat('yyyy-MM-dd').format(picked!);
      data2 = TextEditingController(text: "${Selectdata2}");
      setState(() {
        CarregarViagens();
      });
    });
  }

  Widget _Data1() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate1(context);
            },
            readOnly: true,
            controller: data1,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 12,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data inicial',
            ),
          ),
        ),
      ],
    );
  }

  Widget _Data2() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate2(context);
            },
            readOnly: true,
            controller: data2,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 12,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data final',
            ),
          ),
        ),
      ],
    );
  }
}
