// ignore_for_file: no_logic_in_create_state
import 'dart:convert';
import 'dart:async';
// ignore: depend_on_referenced_packages
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../config/Constats.dart';
import 'PrincipalPage.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:flutter_callkit_incoming/entities/call_kit_params.dart';
import 'package:flutter_callkit_incoming/entities/entities.dart';

var status_service;
var valorId;
var valorChave;
int contador = 0;
int contador2 = 0;
var locationMotorista;
bool con2 = false;
bool locked = true;
bool caller = false;
int tempoDuracao = 20;
String latitude1 = "";
String longitude1 = "";

class MeuServico extends StatefulWidget {

  void requestPermissionsNotification() async {
    final notification = await Permission.notification.status;
    if (notification != PermissionStatus.granted) {
      await Permission.notification.request();
    }
  }

  Future getPosicaoActual() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) {
      String lat1 = position.latitude.toString();
      String long1 = position.longitude.toString();
      locationMotorista = "$lat1,$long1";
    }).catchError((e) {
    });
  }

  Future ActualizaLocalizacao() async {
    if (locationMotorista == null || locationMotorista == "") {
    } else {
      try {
        var url = Uri.parse('$endpoint/motoristaapi/actualizar/info');
        var response = await http.post(url, body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "localizacao_actual": locationMotorista.toString(),
        });
      } catch (e) {
      }
    }
  }

  Future Tracking() async {
    if (locationMotorista == null || locationMotorista == "") {
    } else {
      try {
        var url = Uri.parse('$endpoint/motoristaapi/localizacao/enviar');
        var response = await http.post(url, body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "localizacao_actual": locationMotorista.toString(),
        });
        final map = json.decode(response.body);
      } catch (e) {
      }
    }
  }

  Future<void> CallInComing() async {
    if ("FAST01".isEmpty || "Pedido de Corrida".isEmpty || "FastMoto".isEmpty) {
      print("Parâmetros obrigatórios estão ausentes!");
      return;
    }

    CallKitParams params = CallKitParams(
      id: "FAST01",
      nameCaller: "Pedido de Corrida",
      handle: "1234567890", 
      type: 0,
      appName: "Passageiro",
      avatar: "$endpoint/img/Logo_FastMoto.png",
      textAccept: "Abrir Pedido",
      textDecline: "Rejeitar Pedido",
      duration: 30000, 
      extra: <String, dynamic>{}, 
      android: const AndroidParams(
        isCustomNotification: true,
        isShowLogo: true,
        ringtonePath: 'system_ringtone_default',
        backgroundColor: '#0955fa',
        actionColor: '#4CAF50',
      ),
      ios: const IOSParams(
        iconName: 'CallKitLogo',
        supportsVideo: false,
        maximumCallGroups: 1,
        maximumCallsPerCallGroup: 1,
      ),
    );

    try {
      await FlutterCallkitIncoming.showCallkitIncoming(params as CallKitParams);
    } catch (e) {
      print("Erro ao exibir chamada: $e");
    }
  }

  Future ActivarServico() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/perfil');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "status_servico": "1",
      });
      final map = json.decode(response.body);
    } catch (e) {
    }
  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    throw UnimplementedError();
  }
}
