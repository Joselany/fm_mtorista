import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:material_dialogs/dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import '../config/Constats.dart';
import 'ChamadaPage.dart';
import 'DriverPage.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';

// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';

import 'SplashPage.dart';

class CarregarViagem extends StatefulWidget {
  @override
  // ignore: library_private_types_in_public_api
  _CarregarViagem createState() => _CarregarViagem();
}

class _CarregarViagem extends State<CarregarViagem> {
  loading load = loading();

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  Future DadosViagem() async {
    try {
      String baseURL = "$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final dados_pedido = map["pedido"];
      final dados_passageiro = map["passageiro"];
      setState(() {
        origem_viajante = dados_pedido['origem'];
        destino_viajante = dados_pedido['destino'];
        avaliacao_passageiro = double.parse(map['avaliacao']);
        origem1 = dados_pedido['desc_origem'];
        destino1 = dados_pedido['desc_destino'];
        metodo_pagamento = dados_pedido['metodo_pagamento'];
        viajante = dados_passageiro['nome'];
        passageiroOn = dados_passageiro['id'];
        contacto_viajante = dados_pedido['contacto'];
        foto_viajante = dados_passageiro['foto'];
        status_pedido = dados_pedido['status'];
        CalculaViagem();
      });
      Carregamento();
    } catch (e) {
      print(e);
    }
  }

  void PegarTarifa() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/tarifa');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final tarifa = map["tarifa"];
      tarifa_base = double.tryParse(tarifa[0]['tarifa_base'])!;
      taxakm = double.tryParse(tarifa[0]['tarifa_km'])!;
      inicio_cobranca = int.parse(tarifa[0]['inicio_cobranca']);
      print(tarifa_base);
    } catch (e) {
      print(e);
    }
  }

  CalculaViagem() {
    setState(() {
      lat1 = double.tryParse(origem_viajante.toString().split(',')[0]);
      long1 = double.tryParse(origem_viajante.toString().split(',')[1]);
      lat2 = double.tryParse(destino_viajante.toString().split(',')[0]);
      long2 = double.tryParse(destino_viajante.toString().split(',')[1]);
      distance_rota = Geolocator.distanceBetween(lat1!, long1!, lat2!, long2!);
      calc_distancia_viagem = distance_rota / 1000;

      if (calc_distancia_viagem <= inicio_cobranca) {
        valorViagem = tarifa_base;
      } else {
        double distanciaContagem = calc_distancia_viagem - inicio_cobranca;
        valorViagem = (taxakm * distanciaContagem.round()) + tarifa_base;
      }
    });
  }

  void pegarVariaveisViagem() async {
    numeropedido = await SessionManager().get("numeropedido");
    idViagem = await SessionManager().get("idViagem");
    btnIniciar = await SessionManager().get("btnIniciar");
    btnPausar = await SessionManager().get("btnPausar");
    btnPegar = await SessionManager().get("btnPegar");
    call = await SessionManager().get("call");
    btnRetomar = await SessionManager().get("btnRetomar");
    btnConcluir = await SessionManager().get("btnConcluir");
  }

  bool con = false;

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    print(con);
  }

  @override
  void initState() {
    conexao();
    pegarVariaveisViagem();
    PegarTarifa();
    DadosViagem();
    super.initState();
    Timer(const Duration(seconds: 10), () {
      conexao();
      if (con == true) {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => DriverPage()));
      } else {
        // ignore: use_build_context_synchronously
        Dialogs.bottomMaterialDialog(
            msg:
                'A sua internet não é boa o suficiente para usar o App. Deseja tentar novamente?',
            title: 'Falha de Conexão',
            context: context,
            actions: [
              IconsOutlineButton(
                onPressed: () {
                  Future.delayed(const Duration(milliseconds: 1000), () {
                    if (Platform.isAndroid) {
                      SystemNavigator.pop();
                    } else if (Platform.isIOS) {
                      exit(0);
                    }
                  });
                },
                text: 'Não',
                iconData: Icons.exit_to_app,
                color: const Color(0xFFFF0066),
                textStyle: const TextStyle(color: Colors.white),
                iconColor: Colors.white,
              ),
              IconsButton(
                onPressed: () async {
                  Navigator.of(context).pushReplacement(CupertinoPageRoute(
                      builder: (BuildContext context) => SplashPage()));
                },
                text: 'Sim',
                iconData: CupertinoIcons.restart,
                color: Colors.green,
                textStyle: const TextStyle(color: Colors.white),
                iconColor: Colors.white,
              ),
            ]);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(fontFamily: 'Gotham'),
        home: const Scaffold(
            backgroundColor: Color(0xFFFBFCFD),
            body: Stack(
              alignment: Alignment.center,
              children: [
                Center(
                  child: CircularProgressIndicator(
                    strokeWidth: 10,
                    color: Color(0xFFFF0066), //<-- SEE HERE
                    backgroundColor: Colors.white, //<-- SEE HERE
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  ' Carregando...  ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFFF0066),
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                )
              ],
            )));
  }
}
