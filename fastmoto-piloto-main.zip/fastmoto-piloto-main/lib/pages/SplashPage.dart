import 'dart:async';
import 'dart:io';
import 'package:fastmoto_piloto/pages/CarregarViagem.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import '../controller/MapController.dart';
import 'Back_Services.dart';
import 'CarregarPerfilPage.dart';
import 'IniciarPage.dart';
import 'PrincipalPage.dart';
import 'package:get/get.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

bool btnRg1 = false;
bool btnRg2 = false;
bool btnRg3 = false;
bool btnRg4 = false;

class SplashPage extends StatefulWidget {
  @override
  // ignore: library_private_types_in_public_api
  _SplashPage createState() => _SplashPage();
}

class _SplashPage extends State<SplashPage> {
  final controller = Get.put(MapController());
  bool con = false;

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
  }

  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  bool carregarDados = false;

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.high))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 13.5,
      )));
      posicaoV1 = position.latitude;
      posicaoV2 = position.longitude;
      posicaomotorista = "$posicaoV1,$posicaoV2";
    }).catchError((e) {
      print(e);
    });
  }

  void RecuperarSessao() async {
    status_service = await SessionManager().get("status_service");
    categoria_motorista = await SessionManager().get("categoria_motorista") ?? "";
    sessao_usuario = await SessionManager().get("sessao_usuario") ?? 0;
    idMotorista = await SessionManager().get("idMotorista") ?? "";
    idMotoristaInteiro = await SessionManager().get("idMotoristaInteiro") ?? "";
    ChavePublica = await SessionManager().get("ChavePublica") ?? "";
    status_viagem = await SessionManager().get("status_viagem") ?? false;
    btnRg1 = false;
    btnRg2 = false;
    btnRg3 = false;
    btnRg4 = false;
  }

  @override
  void initState() {
    RecuperarSessao();
    controllerMap.getAddress();
    controllerMap.getPosition();
    getCurrentLocation();
    conexao();
    super.initState();
    Timer(const Duration(seconds: 3), () async {
      numeropedido = await SessionManager().get("numeropedido");
      if (con == true) {
        sessao_usuario == 1
            ? status_viagem == true
                ?
                // ignore: use_build_context_synchronously
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => CarregarViagem()))
                // ignore: use_build_context_synchronously
                : Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => CarregarPerfilPage()))
            :
            // ignore: use_build_context_synchronously
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => IniciarPage()));
      } else {
        // ignore: use_build_context_synchronously
        Dialogs.bottomMaterialDialog(
            msg:
                'A sua internet não é boa o suficiente para usar o App. Deseja tentar novamente?',
            title: 'Falha de Conexão',
            context: context,
            actions: [
              IconsOutlineButton(
                onPressed: () {
                  Future.delayed(const Duration(milliseconds: 1000), () {
                    if (Platform.isAndroid) {
                      SystemNavigator.pop();
                    } else if (Platform.isIOS) {
                      exit(0);
                    }
                  });
                },
                text: 'Não',
                iconData: Icons.exit_to_app,
                color: const Color(0xFFFF0066),
                textStyle: const TextStyle(color: Colors.white),
                iconColor: Colors.white,
              ),
              IconsButton(
                onPressed: () async {
                  Navigator.of(context).pushReplacement(CupertinoPageRoute(
                      builder: (BuildContext context) => SplashPage()));
                },
                text: 'Sim',
                iconData: CupertinoIcons.restart,
                color: Colors.green,
                textStyle: const TextStyle(color: Colors.white),
                iconColor: Colors.white,
              ),
            ]);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(fontFamily: 'Gotham'),
        home: Scaffold(
            backgroundColor: const Color(0xFF00008B),
            body: Stack(
              alignment: Alignment.center, //Color(0xFFb21414)
              children: [
                const Center(
                  child: Image(
                    image: AssetImage("assets/images/logo_branco.png"),
                    width: 280,
                    height: 154,
                  ),
                ),
                Container(
                  alignment: Alignment.bottomCenter,
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator.adaptive(
                        backgroundColor: Color(0xFF00008B),
                        valueColor:
                            AlwaysStoppedAnimation<Color>(Color(0xFFFF0066)),
                      ),
                      SizedBox(
                        height: 200,
                      )
                    ],
                  ),
                ),
              ],
            )));
  }
}
