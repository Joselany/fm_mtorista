import 'dart:convert';
import 'package:fastmoto_piloto/pages/GanhosPage.dart';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/CardViagens.dart';

class ViagensPage extends StatefulWidget {
  @override
  _ViagensPage createState() => _ViagensPage();
}

class _ViagensPage extends State<ViagensPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var dataActual = DateTime.now().add(const Duration(days: -7));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));
  var dadosViagem;
  bool carregado = false;

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 10,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.zero),
            color: Colors.white),
        child: const Row(
          children: [],
        ));
  }

  @override
  void initState() {
    data1 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    data2 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual2));
    setState(() {});
    CarregarViagens();
    super.initState();
  }

  @override
  void dispose() {
    totalGanhos = 0.00;
    totalComissao = 0.00;
    super.dispose();
  }

  Future CarregarViagens() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/ganhos');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "data1": data1.text,
        "data2": data2.text,
      });
      final map = json.decode(response.body);
      dadosViagem = map['viagens'];
      setState(() {
        carregado = true;
      });
    } catch (e) {
      print(e);
    }
  }

  Widget _daoViagens() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregado
          ? SizedBox(
              width: MediaQuery.of(context).size.width,
              child: const Center(
                child: Text(
                  "Nenhum Movimento",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: dadosViagem.length,
              itemBuilder: (BuildContext context, int index) {
                return CardViagens(
                  origem: dadosViagem[index]['desc_origem'],
                  id: dadosViagem[index]['id'].toString(),
                  destino: dadosViagem[index]['desc_destino'],
                  data: dadosViagem[index]['inicio_viagem'],
                );
              },
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Viagens",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
      body: Stack(
        children: [
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                  padding: const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(0),
                          color: Colors.white,
                        ),
                        width: MediaQuery.of(context).size.width,
                        height: 65,
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [_Data1()],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _Data2(),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            alignment: Alignment.center,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _daoViagens(),
              ],
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              children: [
                Row(
                  children: [
                    InfoBar(),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      data1 = TextEditingController(text: selectdata1);
      setState(() {
        CarregarViagens();
      });
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String Selectdata2 = DateFormat('yyyy-MM-dd').format(picked!);
      data2 = TextEditingController(text: Selectdata2);
      setState(() {
        CarregarViagens();
      });
    });
  }

  Widget _Data1() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate1(context);
            },
            readOnly: true,
            controller: data1,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 12,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data inicial',
            ),
          ),
        ),
      ],
    );
  }

  Widget _Data2() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate2(context);
            },
            readOnly: true,
            controller: data2,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 12,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data final',
            ),
          ),
        ),
      ],
    );
  }
}
