import 'dart:convert';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import '../modelos/CardMovimentosCarteira.dart';
import 'Loading.dart';
import 'package:intl/intl.dart';

class MovimentosCarteiraPage extends StatefulWidget {
  @override
  _MovimentosCarteiraPage createState() => _MovimentosCarteiraPage();
}

class _MovimentosCarteiraPage extends State<MovimentosCarteiraPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var MovimentoCarteira;
  var dataActual = DateTime.now().add(const Duration(days: -7));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));

  bool carregado = false;
  loading load = loading();

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      data1 = TextEditingController(text: selectdata1);
      setState(() {
        ConsultarMovimento();
      });
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String Selectdata2 = DateFormat('yyyy-MM-dd').format(picked!);
      data2 = TextEditingController(text: "${Selectdata2}");
      setState(() {
        ConsultarMovimento();
      });
    });
  }

  Widget _Data1() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate1(context);
            },
            readOnly: true,
            controller: data1,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                size: 30,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data inicial',
            ),
          ),
        ),
      ],
    );
  }

  Widget _Data2() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate2(context);
            },
            readOnly: true,
            controller: data2,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                size: 30,
                color: Color(0xFFFF0066),
              ),
              hintText: 'Data final',
            ),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    data1 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    data2 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual2));
    setState(() {
      ConsultarMovimento();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future ConsultarMovimento() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/saldo-extrato');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "de": data1.text,
        "ate": data2.text,
      });
      final map = json.decode(response.body);
      MovimentoCarteira = map['movimentos'];
      setState(() {
        SaldoConta = double.parse(map['saldo']);
      });
      setState(() {
        carregado = true;
      });
    } catch (e) {
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              "Ops! Não foi possível completar a acção. Tente novamente mais tarde.",
        ),
      );
      print(e);
    }
  }

  Widget _daoMovimentos() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 0, bottom: 20),
      child: !carregado
          ? SizedBox(
              width: MediaQuery.of(context).size.width,
              child: const Center(
                child: Text(
                  "Nenhum Movimento",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: MovimentoCarteira.length,
              itemBuilder: (BuildContext context, int index) {
                return CardMovimentosCarteira(
                  id: MovimentoCarteira[index]['id'].toString(),
                  data: MovimentoCarteira[index]['data_movimento'],
                  valor: MovimentoCarteira[index]['valor'].toString(),
                  tipo: MovimentoCarteira[index]['tipo_movimento'],
                  metodo_pagamento: MovimentoCarteira[index]
                      ['metodo_movimento'],
                  estado: MovimentoCarteira[index]['status'].toString(),
                  comprovativo: MovimentoCarteira[index]['tipo_comprovativo'],
                );
              },
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding:
                const EdgeInsets.only(top: 10, left: 20, bottom: 10, right: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SafeArea(
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                        padding:
                            const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(0),
                                color: Colors.white,
                              ),
                              width: MediaQuery.of(context).size.width,
                              height: 65,
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [_Data1()],
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          _Data2(),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(top: 0, bottom: 0),
              child: RefreshIndicator(
                  triggerMode: RefreshIndicatorTriggerMode.onEdge,
                  edgeOffset: 20,
                  strokeWidth: 3,
                  color: Colors.white,
                  backgroundColor: const Color(0xFFFF0066),
                  onRefresh: ConsultarMovimento,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Padding(
                            padding: const EdgeInsets.only(
                                bottom: 5, left: 0, right: 0, top: 5),
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width,
                              child: Column(
                                children: [
                                  _daoMovimentos(),
                                ],
                              ),
                            )),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  )),
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Movimentos da Carteira",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
