import 'dart:convert';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:fastmoto_piloto/pages/ConfigPerfilPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_text_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/style.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import '../config/Constats.dart';
import 'Loading.dart';
import 'package:http/http.dart' as http;
import 'NovaSenhaPage.dart';
import 'SplashPage.dart';

class DigitePinPage extends StatefulWidget {
  @override
  _DigitePinPage createState() => _DigitePinPage();
}

class _DigitePinPage extends State<DigitePinPage> {
  final TextEditingController OtpController = TextEditingController();
  loading load = loading();
  var otp;
  FocusNode myfocus = FocusNode();

  @override
  void initState() {
    myfocus.requestFocus();
    super.initState();
  }

  void GerarSessao() async {
    await SessionManager().set("idMotorista", idMotorista);
    await SessionManager().set("ChavePublica", ChavePublica);
    await SessionManager().set("idMotoristaInteiro", idMotoristaInteiro);
  }

  Future ValidarCodigo() async {
    try {
      setState(() {
        btnRg4 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo2');
      var response = await http.post(url, body: {
        "telefone": numeroTel,
        "codigo": otp,
      });

      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      final dados = map['perfil_motorista'];
      print(map);
      if (msgr == 1) {
        idMotorista = dados['id'];
        ChavePublica = map['chave_publica'];
        print(idMotorista);
        print(ChavePublica);
        GerarSessao();
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Código validado com sucesso.',
          ),
        );
        setState(() {
          btnRg4 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => NovaSenhaPage()));
      } else if (msgr == 0) {
        setState(() {
          btnRg4 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Código inválido. Digite novamente',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg4 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Future ValidarNumero() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo1');
      var response = await http.post(url, body: {
        "telefone": numeroTel.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPage()));
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Número inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnRg4 == false
            ? () async {
                if (otp == "") {
                  showTopSnackBar(
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Por favor, Preencher o Código OTP.',
                    ),
                  );
                } else {
                  ValidarCodigo();
                }
              }
            : () {},
        child: btnRg4 == false
            ? const Text(
                'Continuar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _BtnEnviar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
        ),
        onPressed: () async {
          setState(() {
            otp = null;
          });
          await showDialog(
            context: context,
            builder: (context) => FutureProgressDialog(load.getFuture()),
          );
          ValidarNumero();
        },
        child: const Text(
          'Reenviar código',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 14.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  Widget _TxtOPT() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 70,
      child: OTPTextField(
        length: 5,
        spaceBetween: 4,
        width: MediaQuery.of(context).size.width,
        fieldWidth: 40,
        style: const TextStyle(
            fontFamily: 'Gotham', fontWeight: FontWeight.bold, fontSize: 30),
        textFieldAlignment: MainAxisAlignment.center,
        fieldStyle: FieldStyle.underline,
        onCompleted: (pin) {
          otp = pin;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 20,
            ),
            Text(
              'Digite o código enviado para: $numeroTel',
              style: const TextStyle(
                color: Colors.black54,
                letterSpacing: 0,
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            _TxtOPT(),
            const SizedBox(
              height: 10,
            ),
            _BtnEnviar(),
            const SizedBox(
              height: 2,
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Column(
                //crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _BtnComecar(),
                ],
              ),
            ),
          ],
        ));
  }
}
