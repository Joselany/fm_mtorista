import 'dart:convert';
import 'package:fastmoto_piloto/config/Constats.dart';
import 'package:fastmoto_piloto/pages/ConfigPerfilPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'DigitePinPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';

class ResetSenhaPage extends StatefulWidget {
  @override
  _ResetSenhaPage createState() => _ResetSenhaPage();
}

class _ResetSenhaPage extends State<ResetSenhaPage> {
  final globalKey = GlobalKey<FormState>();
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();

  @override
  void initState() {
    myfocus.requestFocus();
    super.initState();
  }

  loading load = loading();
  FocusNode myfocus = FocusNode();

  Future ValidarNumero() async {
    try {
      setState(() {
        btnRg1 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo1');
      var response = await http.post(url, body: {
        "telefone": PhoneController.text.toString(),
      });
      final map = json.decode(response.body);
      print(map);
      final msgr = map["retorno"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        setState(() {
          btnRg1 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPage()));
      } else if (msgr == 0) {
        setState(() {
          btnRg1 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ops! Telefone incorrecto. Tente novamente!',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg1 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnRg1 == false
            ? () {
                numeroTel = PhoneController.text;
                if (PhoneController.text == "") {
                  showTopSnackBar(
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Por favor, Preencher o número de telefone.',
                    ),
                  );
                  myfocus.requestFocus();
                } else {
                  ValidarNumero();
                }
              }
            : () {},
        child: btnRg1 == false
            ? const Text(
                'Continuar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  String text = "";
  int maxLength = 9;

  Widget _TxtTelefone() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        onChanged: (String newVal) {
          if (newVal.length <= maxLength) {
            text = newVal;
          } else {
            PhoneController.text = text;
          }
        },
        keyboardType: TextInputType.number,
        labelText: "Telefone",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 20,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.phone_android_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: PhoneController,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 200,
            ),
            const Text(
              'Digite o seu Telefone',
              style: TextStyle(
                color: Colors.black54,
                letterSpacing: 0,
                fontSize: 22.0,
                fontWeight: FontWeight.normal,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            _TxtTelefone(),
            const SizedBox(
              height: 10,
            ),
            const SizedBox(
              height: 15,
            ),
            _BtnComecar(),
            const SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: const Text(
          "Reset de Palavra-passe",
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
