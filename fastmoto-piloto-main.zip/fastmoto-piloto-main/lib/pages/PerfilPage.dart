import 'dart:convert';
import 'dart:io';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'Back_Services.dart';
import 'EditarPerfilPage.dart';
import 'EditarSenha.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import 'Loading.dart';
import 'package:image_picker/image_picker.dart';

class PerfilPage extends StatefulWidget {
  @override
  _PerfilPage createState() => _PerfilPage();
}

class _PerfilPage extends State<PerfilPage> {
  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();

  void pegarDados() {
    _email.text = emailMotorista?.toString() ?? '';
    _nome.text = nomeMotorista?.toString() ?? '';
    _sobrenome.text = sobrenomeMotorista?.toString() ?? '';
  }

  loading load = loading();

  @override
  void initState() {
    pegarDados();
    super.initState();
  }

  void ZerarSessao() async {
    await SessionManager().set("idMotorista", "");
    await SessionManager().set("ChavePublica", "");
    await SessionManager().set("idMotoristaInteiro", "");
  }

  Future ExcluirPerfil() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/conta/excluir');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(message: 'Perfil excluido com sucesso.'),
        );
        await SessionManager().set("sessao_usuario", 0);
        await SessionManager().set("idMotorista", "");
        await SessionManager().set("idMotoristaInteiro", "");
        await SessionManager().set("ChavePublica", "");
        // ignore: use_build_context_synchronously
        Future.delayed(const Duration(milliseconds: 3000), () async {
          await showDialog(
            context: context,
            builder: (context) => FutureProgressDialog(load.getFuture()),
          );
          if (Platform.isAndroid) {
            SystemNavigator.pop();
          } else if (Platform.isIOS) {
            exit(0);
          }
        });
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao efectuar o registo.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget BarraInferior() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.40,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomLeft: Radius.circular(0),
          bottomRight: Radius.circular(0),
          topRight: Radius.circular(20),
        ),
        // color: Colors.white,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.white, Color(0xFFEDEEE9)],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Divider(height: 10, color: Colors.white),
          ListTile(
            onTap: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (BuildContext context) => EditarSenhaPage(),
                ),
              );
            },
            leading: const Icon(
              Icons.lock_outline,
              size: 25,
              color: Colors.black,
            ),
            title: const Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Text(
                "Actualizar Senha",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
          ),
          const Divider(height: 10, color: Colors.black12),
          ListTile(
            onTap: () {
              Dialogs.bottomMaterialDialog(
                msg: 'Deseja terminar a sessão?',
                title: 'Sair do Aplicativo',
                context: context,
                actions: [
                  IconsOutlineButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    text: 'Não',
                    color: Colors.green,
                    iconData: Icons.cancel_outlined,
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                  IconsButton(
                    onPressed: () async {
                      if (status_service == true) {
                        Navigator.of(context).pop();
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message:
                                'Não é possível terminar a sessão com o serviço activo',
                          ),
                        );
                      } else {
                        await SessionManager().set("sessao_usuario", 0);
                        ZerarSessao();
                        Future.delayed(
                          const Duration(milliseconds: 3000),
                          () async {
                            await showDialog(
                              context: context,
                              builder: (context) =>
                                  FutureProgressDialog(load.getFuture()),
                            );
                            if (Platform.isAndroid) {
                              SystemNavigator.pop();
                            } else if (Platform.isIOS) {
                              exit(0);
                            }
                          },
                        );
                      }
                    },
                    text: 'Sim',
                    iconData: Icons.exit_to_app,
                    color: const Color(0xFFFF0066),
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                ],
              );
            },
            leading: const Icon(
              Icons.exit_to_app_outlined,
              size: 25,
              color: Colors.black54,
            ),
            title: const Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Text(
                "Terminar Sessão",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
          ),
          const Divider(height: 10, color: Colors.black12),
          ListTile(
            onTap: () {
              Dialogs.bottomMaterialDialog(
                msg: 'Deseja excluir a sua conta?',
                title: 'Excluir Perfil',
                context: context,
                actions: [
                  IconsOutlineButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    text: 'Não',
                    iconData: Icons.cancel_outlined,
                    color: Colors.green,
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                  IconsButton(
                    onPressed: () {
                      if (status_service == true) {
                        Navigator.of(context).pop();
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message:
                                'Não é possível excluir a conta com o serviço activo',
                          ),
                        );
                      } else {
                        Navigator.of(context).pop();
                        ExcluirPerfil();
                      }
                    },
                    text: 'Sim',
                    iconData: Icons.done_outline,
                    color: const Color(0xFFFF0066),
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                ],
              );
            },
            leading: const Icon(Icons.delete, size: 25, color: Colors.red),
            title: const Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Text(
                "Eliminar a Conta",
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
          ),
          const Divider(height: 20, color: Colors.black12),
        ],
      ),
    );
  }

  Widget BarraSuperior() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.45,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(0),
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
          topRight: Radius.circular(0),
        ),
        color: Colors.white,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 5),
          Center(
            child: CircleAvatar(
              radius: 50,
              backgroundColor: const Color(0xFFFF0066),
              backgroundImage: file == null
                  ? (fotoPerfil != null
                      ? Image.network(fotoPerfil!).image
                      : null)
                  : Image.file(File(file!.path)).image,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              // color: const Color(0x0faeb2b5),
            ),
            height: 50,
            width: 30,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () {
                    Dialogs.bottomMaterialDialog(
                      msg: 'Carregar foto de perfil',
                      title: 'Foto de Perfil',
                      context: context,
                      actions: [
                        IconsOutlineButton(
                          onPressed: () {
                            getImageCamera();
                            Navigator.of(context).pop();
                          },
                          text: 'Câmera',
                          iconData: Icons.camera_alt,
                          color: const Color(0xFFFF0066),
                          textStyle: const TextStyle(color: Colors.white),
                          iconColor: Colors.white,
                        ),
                        IconsButton(
                          onPressed: () {
                            getImageGaleria();
                            Navigator.of(context).pop();
                          },
                          text: 'Galeria',
                          iconData: Icons.image,
                          color: const Color(0xFFFF0066),
                          textStyle: const TextStyle(color: Colors.white),
                          iconColor: Colors.white,
                        ),
                      ],
                    );
                  },
                  icon: const Icon(
                    Icons.add_a_photo,
                    size: 25,
                    color: Color(0xFFFF0066),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 15, color: Colors.black12),
          ListTile(
            onTap: () {},
            leading: const Icon(Icons.person, size: 25, color: Colors.black54),
            title: Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Text(
                '$nomeMotorista $sobrenomeMotorista',
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'gotham',
                ),
              ),
            ),
          ),
          const Divider(height: 10, color: Colors.black12),
          ListTile(
            onTap: () {},
            leading: const Icon(
              Icons.phone_android_outlined,
              size: 25,
              color: Colors.black54,
            ),
            title: Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Text(
                '$telefoneMotorista',
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
          ),
          const Divider(height: 15, color: Colors.black12),
        ],
      ),
    );
  }

  File? file;
  XFile? _image;

  final picker = ImagePicker();

  Future getImageGaleria() async {
    _image = await picker.pickImage(source: ImageSource.gallery);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
      // ignore: use_build_context_synchronously
      Dialogs.bottomMaterialDialog(
        msg: 'Deseja salvar a foto?',
        title: 'Actualizar foto de perfil',
        context: context,
        actions: [
          IconsOutlineButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            text: 'Não',
            iconData: Icons.cancel,
            color: Colors.white38,
            textStyle: const TextStyle(color: Colors.grey),
            iconColor: Colors.white,
          ),
          IconsButton(
            onPressed: () {
              Navigator.of(context).pop();
              _UploadFoto();
            },
            text: 'Sim',
            iconData: Icons.done_outline,
            color: Colors.green,
            textStyle: const TextStyle(color: Colors.white),
            iconColor: Colors.white,
          ),
        ],
      );
    }
  }

  Future<void> getImageCamera() async {
    _image = await picker.pickImage(source: ImageSource.camera);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
      // ignore: use_build_context_synchronously
      Dialogs.bottomMaterialDialog(
        msg: 'Deseja salvar a foto?',
        title: 'Actualizar foto de perfil',
        context: context,
        actions: [
          IconsOutlineButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            text: 'Não',
            iconData: Icons.cancel,
            color: Colors.white38,
            textStyle: const TextStyle(color: Colors.grey),
            iconColor: Colors.white,
          ),
          IconsButton(
            onPressed: () {
              Navigator.of(context).pop();
              _UploadFoto();
            },
            text: 'Sim',
            iconData: Icons.done_outline,
            color: Colors.green,
            textStyle: const TextStyle(color: Colors.white),
            iconColor: Colors.white,
          ),
        ],
      );
    }
  }

  Future _UploadFoto() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/alterarfoto');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("foto", file!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        file = null;
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Registo actualizado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (BuildContext context) => PrincipalPage()),
        );
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar a foto de perfil.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de foto");
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEEE9),
      body: Stack(
        children: [
          Container(
            alignment: Alignment.topCenter,
            child: Row(
              children: [
                Row(children: [BarraSuperior()]),
              ],
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              children: [
                Row(children: [BarraInferior()]),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Perfil",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (BuildContext context) => EditarPerfilPage(),
                ),
              );
            },
            child: const Text(
              "Editar Perfil",
              style: TextStyle(
                color: Color(0xFFFF0066),
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
