// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:image_picker/image_picker.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';

var fotoLivrete;
var fotoCarta;
var fotoBI;
var fotoTitulo;
var fotoRC;

class DocumentosPage extends StatefulWidget {
  @override
  _DocumentosPage createState() => _DocumentosPage();
}

class _DocumentosPage extends State<DocumentosPage> {
  @override
  void initState() {
    CarregarDados();
    super.initState();
  }

  Future CarregarDados() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/dados');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final perfil = map["perfil_motorista"];
      final info = map["info_motorista"];
      final docs = map["docs_motorista"];
      setState(() {
        nomeMotorista = perfil['nome'];
        sobrenomeMotorista = perfil['apelido'];
        fotoPerfil = urlImagem + perfil['foto'];
        emailMotorista = perfil['email'];
        fotoLivrete = docs['livrete'];
        fotoCarta = docs['carta_conducao'];
        fotoBI = docs['bi'];
        fotoTitulo = docs['titulo_propriedade'];
        fotoRC = docs['registo_criminal'];
      });
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  loading load = loading();

  File? carta;
  File? bi;
  File? livrete;
  File? titulo;
  File? rc;
  XFile? _imageCarta;
  XFile? _imageBi;
  XFile? _imageLivrete;
  XFile? _imageTitulo;
  XFile? _imageRC;

  final picker = ImagePicker();

  // carta de condução
  Future getCartaGaleria() async {
    _imageCarta = await picker.pickImage(source: ImageSource.gallery);
    if (_imageCarta != null) {
      setState(() {
        carta = File(_imageCarta!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadCarta();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getCartaCamera() async {
    _imageCarta = await picker.pickImage(source: ImageSource.camera);
    if (_imageCarta != null) {
      setState(() {
        carta = File(_imageCarta!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadCarta();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadCarta() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/carta_conducao');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic =
          await http.MultipartFile.fromPath("carta_conducao", carta!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar a Carta.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de carta");
      print(e);
    }
  }

  // Bilhete de identidade
  Future getBIGaleria() async {
    _imageBi = await picker.pickImage(source: ImageSource.gallery);
    if (_imageBi != null) {
      setState(() {
        bi = File(_imageBi!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadBI();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getBICamera() async {
    _imageBi = await picker.pickImage(source: ImageSource.camera);
    if (_imageBi != null) {
      setState(() {
        bi = File(_imageBi!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadBI();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadBI() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/bi');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("bi", bi!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else {
        // ignore: duplicate_ignore, duplicate_ignore
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o BI.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de BI");
      print(e);
    }
  }

  // Livrete
  Future getLivreteGaleria() async {
    _imageLivrete = await picker.pickImage(source: ImageSource.gallery);
    if (_imageLivrete != null) {
      setState(() {
        livrete = File(_imageLivrete!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadLivrete();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getLivereteCamera() async {
    _imageLivrete = await picker.pickImage(source: ImageSource.camera);
    if (_imageLivrete != null) {
      setState(() {
        livrete = File(_imageLivrete!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadLivrete();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadLivrete() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/livrete');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("livrete", livrete!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o Livrete.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de Livrete");
      print(e);
    }
  }

  // Titulo
  Future getTituloGaleria() async {
    _imageTitulo = await picker.pickImage(source: ImageSource.gallery);
    if (_imageLivrete != null) {
      setState(() {
        titulo = File(_imageTitulo!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadTitulo();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getTituloCamera() async {
    _imageTitulo = await picker.pickImage(source: ImageSource.camera);
    if (_imageTitulo != null) {
      setState(() {
        titulo = File(_imageTitulo!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadTitulo();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadTitulo() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url =
          Uri.parse('$endpoint/motoristaapi/actualizar/titulo_propriedade');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic =
          await http.MultipartFile.fromPath("titulo_propriedade", titulo!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o Título.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de Titulo");
      print(e);
    }
  }

// registo_criminal
  Future getRCGaleria() async {
    _imageRC = await picker.pickImage(source: ImageSource.gallery);
    if (_imageRC != null) {
      setState(() {
        rc = File(_imageRC!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadRC();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getRCCamera() async {
    _imageRC = await picker.pickImage(source: ImageSource.camera);
    if (_imageRC != null) {
      setState(() {
        rc = File(_imageRC!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadRC();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadRC() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/registo_criminal');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("registo_criminal", rc!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o RC.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de RC");
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEEE9),
      body: SingleChildScrollView(
        child: Column(children: [
          Center(
            child: CircleAvatar(
                radius: 30,
                backgroundImage: bi != null
                    ? Image.file(File(bi!.path)).image
                    : fotoBI == null
                        ? Image.asset('assets/images/nofoto.png').image
                        : Image.network(urlImagem + fotoBI).image),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: const Color(0xFaeb2b5),
            ),
            height: 70,
            width: MediaQuery.of(context).size.width / 1.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Bilhete de Identidade',
                  style: TextStyle(
                    color: Colors.black87,
                    letterSpacing: 0,
                    fontSize: 11.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Dialogs.bottomMaterialDialog(
                          msg: 'Carregar Bilhete de Identidade',
                          title: 'Carregar documento',
                          context: context,
                          actions: [
                            IconsOutlineButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getBICamera();
                              },
                              text: 'Câmera',
                              iconData: Icons.camera_alt,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                            IconsButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getBIGaleria();
                              },
                              text: 'Galeria',
                              iconData: Icons.image,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                          ]);
                    },
                    icon: const Icon(Icons.add_a_photo))
              ],
            ),
          ),
          Center(
            child: CircleAvatar(
                radius: 30,
                backgroundImage: carta != null
                    ? Image.file(File(carta!.path)).image
                    : fotoCarta == null
                        ? Image.asset('assets/images/nofoto.png').image
                        : Image.network(urlImagem + fotoCarta).image),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: const Color(0xFaeb2b5),
            ),
            height: 70,
            width: MediaQuery.of(context).size.width / 1.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Carta de Condução',
                  style: TextStyle(
                    color: Colors.black87,
                    letterSpacing: 0,
                    fontSize: 11.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Dialogs.bottomMaterialDialog(
                          msg: 'Carregar Carta de Condução',
                          title: 'Carregar documento',
                          context: context,
                          actions: [
                            IconsOutlineButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getCartaCamera();
                              },
                              text: 'Câmera',
                              iconData: Icons.camera_alt,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                            IconsButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getCartaGaleria();
                              },
                              text: 'Galeria',
                              iconData: Icons.image,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                          ]);
                    },
                    icon: const Icon(Icons.add_a_photo))
              ],
            ),
          ),
          Center(
            child: CircleAvatar(
                radius: 30,
                backgroundImage: livrete != null
                    ? Image.file(File(livrete!.path)).image
                    : fotoLivrete == null
                        ? Image.asset('assets/images/nofoto.png').image
                        : Image.network(urlImagem + fotoLivrete).image),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: const Color(0xFaeb2b5),
            ),
            height: 70,
            width: MediaQuery.of(context).size.width / 1.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Livrete',
                  style: TextStyle(
                    color: Colors.black87,
                    letterSpacing: 0,
                    fontSize: 11.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Dialogs.bottomMaterialDialog(
                          msg: 'Carregar Livrete',
                          title: 'Carregar documento',
                          context: context,
                          actions: [
                            IconsOutlineButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getLivereteCamera();
                              },
                              text: 'Câmera',
                              iconData: Icons.camera_alt,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                            IconsButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getLivreteGaleria();
                              },
                              text: 'Galeria',
                              iconData: Icons.image,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                          ]);
                    },
                    icon: const Icon(Icons.add_a_photo))
              ],
            ),
          ),
          Center(
            child: CircleAvatar(
                radius: 30,
                backgroundImage: titulo != null
                    ? Image.file(File(titulo!.path)).image
                    : fotoTitulo == null
                        ? Image.asset('assets/images/nofoto.png').image
                        : Image.network(urlImagem + fotoTitulo).image),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: const Color(0xFaeb2b5),
            ),
            height: 70,
            width: MediaQuery.of(context).size.width / 1.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Título de Propriedade',
                  style: TextStyle(
                    color: Colors.black87,
                    letterSpacing: 0,
                    fontSize: 11.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Dialogs.bottomMaterialDialog(
                          msg: 'Carregar Título de Propriedade',
                          title: 'Carregar documento',
                          context: context,
                          actions: [
                            IconsOutlineButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getTituloCamera();
                              },
                              text: 'Câmera',
                              iconData: Icons.camera_alt,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                            IconsButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getTituloGaleria();
                              },
                              text: 'Galeria',
                              iconData: Icons.image,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                          ]);
                    },
                    icon: const Icon(
                      Icons.add_a_photo,
                    )),
              ],
            ),
          ),
          Center(
            child: CircleAvatar(
                radius: 30,
                backgroundImage: rc != null
                    ? Image.file(File(rc!.path)).image
                    : fotoRC == null
                        ? Image.asset('assets/images/nofoto.png').image
                        : Image.network(urlImagem + fotoRC).image),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: const Color(0xFaeb2b5),
            ),
            height: 70,
            width: MediaQuery.of(context).size.width / 1.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Registo Criminal',
                  style: TextStyle(
                    color: Colors.black87,
                    letterSpacing: 0,
                    fontSize: 11.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Dialogs.bottomMaterialDialog(
                          msg: 'Carregar o Registo Criminal',
                          title: 'Carregar documento',
                          context: context,
                          actions: [
                            IconsOutlineButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getRCCamera();
                              },
                              text: 'Câmera',
                              iconData: Icons.camera_alt,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                            IconsButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                getRCGaleria();
                              },
                              text: 'Galeria',
                              iconData: Icons.image,
                              color: const Color(0xFFFF0066),
                              textStyle: const TextStyle(color: Colors.white),
                              iconColor: Colors.white,
                            ),
                          ]);
                    },
                    icon: const Icon(Icons.add_a_photo))
              ],
            ),
          )
        ]),
      ),
      appBar: AppBar(
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
        actions: const [],
      ),
    );
  }
}
