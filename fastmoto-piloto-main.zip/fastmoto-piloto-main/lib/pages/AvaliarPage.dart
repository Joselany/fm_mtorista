import 'dart:convert';
import 'package:fastmoto_piloto/config/Constats.dart';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'DriverPage.dart';
import 'Loading.dart';

double avaliacao = 0.0;

class AvaliarPage extends StatefulWidget {
  @override
  _AvaliarPage createState() => _AvaliarPage();
}

class _AvaliarPage extends State<AvaliarPage> {
  @override
  void initState() {
    super.initState();
  }

  loading load = loading();

  Future AvaliarPassageiro() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/actualizar');
      var response = await http.post(url, body: {
        "avaliacao_passageiro": avaliacao.toString(),
        "id": idViagem.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        setState(() {
          status_viagem = false;
          status_chamada = false;
          call = false;
          numeropedido = null;
          idViagem = null;
        });
        await SessionManager().set("call", false);
        await SessionManager().set("status_viagem", false);
        await SessionManager().set("status_chamada", false);
        await SessionManager().set("numeropedido", "");
        await SessionManager().set("idViagem", "");
        avaliacao = 0.0;
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'A sua avaliação foi enviada com sucesso!',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => PrincipalPage()),
          (Route<dynamic> route) => false,
        );
      }
    } catch (e) {
      print(e);
    }
  }

  Widget _BtnFinalizar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: () {
          AvaliarPassageiro();
        },
        child: const Text(
          'Enviar Avaliação',
          style: TextStyle(
            color: Color(0xFF00008B),
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF00008B),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: CircleAvatar(
                radius: 45,
                backgroundColor: Colors.white,
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage: foto_viajante == null
                      ? Image.asset('assets/images/nofoto.png').image
                      : Image.network(urlImagem + foto_viajante).image,
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              '$viajante',
              style: const TextStyle(
                color: Colors.white,
                letterSpacing: 0,
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            const Text(
              'Avalie o seu Passageiro',
              style: TextStyle(
                color: Colors.white,
                letterSpacing: 0,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            SmoothStarRating(
              rating: avaliacao,
              size: 40,
              filledIconData: Icons.star,
              halfFilledIconData: Icons.star_half,
              defaultIconData: Icons.star_border,
              color: const Color(0xFFFF0066),
              borderColor: Colors.white,
              starCount: 5,
              allowHalfRating: true,
              spacing: 2.0,
              onRatingChanged: (value) {
                setState(() {
                  avaliacao = value;
                  print("Avaliação-> $value");
                  print(value);
                });
              },
            ),
            const SizedBox(
              height: 15,
            ),
            _BtnFinalizar(),
          ],
        ));
  }
}
