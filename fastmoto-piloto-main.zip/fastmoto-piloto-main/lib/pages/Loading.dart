
import 'package:flutter/material.dart';

class loading{

  Future getFuture() {
    return Future(() async {
      await Future.delayed(const Duration(seconds: 5));
      return const CircularProgressIndicator.adaptive();
    });
  }

}
