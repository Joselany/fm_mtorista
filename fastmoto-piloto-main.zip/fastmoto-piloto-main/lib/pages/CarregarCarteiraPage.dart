import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
// ignore: depend_on_referenced_packages

// ignore: depend_on_referenced_packages
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'MetodoCarregamentoPage.dart';

var valor_carregamento = "0";

class CarregarCarteiraPage extends StatefulWidget {
  @override
  _CarregarCarteiraPage createState() => _CarregarCarteiraPage();
}

class _CarregarCarteiraPage extends State<CarregarCarteiraPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _valor = TextEditingController();
  bool btnCarregar = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget _TxtValor() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.number,
        labelText: "Valor a carregar",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 20,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.monetization_on,
          color: Color(0xFFFF0066),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _valor,
      ),
    );
  }

  Widget _BtnCarregar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnCarregar == false
            ? () {
                setState(() {
                  btnCarregar = true;
                });
                valor_carregamento = _valor.text;
                if (valor_carregamento == "") {
                  setState(() {
                    btnCarregar = false;
                  });
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.info(
                      message: 'Informe o Valor a Carregar',
                    ),
                  );
                } else {
                  setState(() {
                    btnCarregar = false;
                  });
                  Navigator.of(context).pushReplacement(CupertinoPageRoute(
                      builder: (BuildContext context) =>
                          MetodoCarregamentoPage()));
                }
              }
            : () {},
        child: btnCarregar == false
            ? const Text(
                'Continuar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      elevation: 10,
                      color: Colors.white,
                      shadowColor: const Color(0xFFFF0066),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: InkWell(
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            children: [
                              const Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [],
                              ),
                              Container(
                                alignment: Alignment.center,
                                child: _TxtValor(),
                              ),
                            ],
                          ),
                        ),
                        onTap: () {
                          // Function is executed on tap.
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _BtnCarregar(),
                const SizedBox(
                  height: 100,
                )
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Carregar Carteira",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 10,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
