import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:count_up_flutter/count_up_flutter.dart';
import 'package:fastmoto_piloto/pages/FinalizarPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import 'package:get/get.dart';
import '../main.dart';
import 'Back_Services.dart';
import 'ChamadaPage.dart';
import 'ChatPage.dart';
import 'package:radio_group_v2/radio_group_v2.dart';

// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'Loading.dart';
import 'LocalNotification.dart';
import 'PrincipalPage.dart';
import 'SplashPage.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'ForegroundTaskService.dart' as foregroundTaskService;

var idViagem;
bool btnIniciar = false;
bool btnPausar = false;
bool btnPegar = false;
bool btnRetomar = false;
bool btnConcluir = false;
int tempoParagemFinal = 0;
double calc_distancia_viagem2 = 0.0;
var urlNavegacao;
int tempo_inicial = 0;
var tempo_viagem;
var status_passageiro;

class DriverPage extends StatefulWidget {
  @override
  _DriverPage createState() => _DriverPage();
}

class _DriverPage extends State<DriverPage> {
  final f = NumberFormat("#,##0", "pt_BR");
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  final controllerMap = Get.put(MapController());
  BitmapDescriptor marker = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon1 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon2 = BitmapDescriptor.defaultMarker;

  ElapsedController elapsedCountUpController = ElapsedController();

  bool con = false;

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    print(con);
  }

  final CameraPosition _initialLocation = const CameraPosition(
      target: LatLng(-8.56148317153996, 13.593409574676945), zoom: 0);
  late GoogleMapController mapController;

  loading load = loading();

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.scrollBy(5, 5));
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(origem.latitude, origem.longitude),
        zoom: 16,
      )));
      setState(() {
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
        addCustomIcon();
      });
      Carregamento();
    }).catchError((e) async {
      print(e);
    });
  }

  UpdategetCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 14.5,
      )));
      setState(() {
        controllerMap.getAddress();
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
        posicaomotorista = "$posicaoV1,$posicaoV2";
      });
    }).catchError((e) async {
      print(e);
    });
  }

  FinalizargetCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 14.5,
      )));
      setState(() {
        controllerMap.getAddress();
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
        posicaomotorista = "$posicaoV1,$posicaoV2";
      });
      Carregamento();
      _CalcularPagamento();
    }).catchError((e) async {
      print(e);
    });
  }

  Future Tracking() async {
    if (posicaomotorista == null ||
        posicaomotorista == "" ||
        posicaomotorista == 0) {
    } else {
      try {
        var url = Uri.parse('$endpoint/motoristaapi/localizacao/enviar');
        var response = await http.post(url, body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "localizacao_actual": posicaomotorista.toString(),
        });
        final map = json.decode(response.body);
        final msgr = map["retorno"];
        print(posicaomotorista);
      } catch (e) {
        print(e);
      }
    }
  }

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  List<LatLng> polylineCoordinates = [];

  void getPolyPoint() async {
    PolylinePoints polylinePoints = PolylinePoints();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleApiKey: google_api_key,
        request: PolylineRequest(
            origin: PointLatLng(posicaoV1, posicaoV2),
            destination: PointLatLng(destino.latitude, destino.longitude),
            mode: TravelMode.driving));
    if (result.points.isNotEmpty) {
      setState(() {
        result.points.forEach(
          (PointLatLng point) => polylineCoordinates.add(
            LatLng(point.latitude, point.longitude),
          ),
        );
      });
    }
  }

  List<LatLng> polylineCoordinates2 = [];

  void getPolyPoint2() async {
    PolylinePoints polylinePoints = PolylinePoints();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleApiKey: google_api_key,
        request: PolylineRequest(
            origin: PointLatLng(posicaoV1, posicaoV2),
            destination: PointLatLng(origem.latitude, origem.longitude),
            mode: TravelMode.driving));
    if (result.points.isNotEmpty) {
      setState(() {
        result.points.forEach(
          (PointLatLng point) => polylineCoordinates2.add(
            LatLng(point.latitude, point.longitude),
          ),
        );
      });
    }
  }

  LatLng origem = LatLng(lat1!, long1!);
  LatLng destino = LatLng(lat2!, long2!);

  void addCustomIcon() {
    BitmapDescriptor.asset(
            const ImageConfiguration(), "assets/images/moto_gps.png")
        .then(
      (icon) {
        setState(() {
          marker = icon;
        });
      },
    );

    BitmapDescriptor.asset(
            const ImageConfiguration(), "assets/images/location_pin.png")
        .then(
      (icon) {
        setState(() {
          markerIcon1 = icon;
        });
      },
    );

    BitmapDescriptor.asset(
            const ImageConfiguration(), "assets/images/location_pin.png")
        .then(
      (icon) {
        setState(() {
          markerIcon2 = icon;
        });
      },
    );
  }

  var rating = 0.0;

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 200,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.circular(10)),
            color: Color(0xFFFF0066)),
        child: Row(
          children: [
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      height: 200,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ElapsedTimer(
                            width: MediaQuery.of(context).size.width * 0.4,
                            height: 20,
                            duration: 60 * 100,
                            initialDuration: tempo_inicial,
                            fillColor: Colors.red,
                            ringColor: const Color(0xffE1E6EC),
                            controller: elapsedCountUpController,
                            backgroundColor: const Color(0xffE6D9EF),
                            strokeWidth: 10.0,
                            strokeCap: StrokeCap.round,
                            isTimerTextShown: true,
                            textFormat: ElapsedTimerTextFormat.HH_MM_SS,
                            isReverse: false,
                            autoStart: false,
                            textStyle: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.normal,
                              fontSize: 18,
                            ),
                            onComplete: () {},
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          CircleAvatar(
                            radius: 45,
                            backgroundColor: status_passageiro == 1
                                ? Colors.green
                                : Colors.grey,
                            child: foto_viajante == null
                                ? CircleAvatar(
                                    radius: 40,
                                    backgroundImage:
                                        Image.asset('assets/images/nofoto.png')
                                            .image,
                                  )
                                : CircleAvatar(
                                    radius: 40,
                                    backgroundImage:
                                        Image.network(urlImagem + foto_viajante)
                                            .image,
                                  ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          viajante == null
                              ? const Text(
                                  '  ---  ',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                )
                              : Text(
                                  '  $viajante  ',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6,
                  height: 200,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 20,
                      ),
                      Row(
                        children: [
                          ListTile(
                            title: Text(
                              "${f.format(valorViagem).toString()} Kz",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 30.0,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'gotham',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(
                        height: 30,
                        color: Color(0xFF00008B),
                      ),
                      ListTile(
                        title: Text(
                          "$metodo_pagamento",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18.0,
                            fontWeight: FontWeight.normal,
                            fontFamily: 'gotham',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  void MostrarDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Informe o Motivo do Cancelamento.'),
          titleTextStyle: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
          content: _MotivoCancela(),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar',
                  style: TextStyle(
                    color: Colors.black54,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  )),
            ),
            TextButton(
              onPressed: () {
                _CancelarViagem();
              },
              child: const Text('Enviar',
                  style: TextStyle(
                    color: Color(0xFFFF0066),
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  )),
            )
          ],
        );
      },
    );
  }

  Widget _MotivoCancela() {
    return RadioGroup(
      controller: myMotivo,
      values: const [
        "Problemas mecânicos- Ups, a minha moto está com problemas.",
        "Clima - Mau dia, mau dia! Condições meteorológicas não boas.",
        "Urgência pessoal (algo de errado aconteceu).",
        "Segurança- tenho dúvidas sobre a minha segurança nesta corrida.",
        "Local de recolha do cliente não está correta.",
        "O cliente está muito longe.",
        "Cliente não atende o telefone."
      ],
      indexOfDefault: 0,
      orientation: RadioGroupOrientation.vertical,
      decoration: const RadioGroupDecoration(
        toggleable: true,
        splashRadius: 10,
        spacing: 80.0,
        labelStyle: TextStyle(
          color: Colors.black,
        ),
        activeColor: Color(0xFFFF0066),
      ),
    );
  }

  Widget _BtnCancelar() {
    return SizedBox(
      width: 230,
      height: 50,
      child: TextButton.icon(
        icon: btnIniciar == true
            ? const Icon(
                Icons.cancel,
                color: Colors.grey,
                size: 40,
              )
            : const Icon(
                Icons.cancel,
                color: Color(0xFFFF0066),
                size: 40,
              ),
        label: btnIniciar == true
            ? const Text("Cancelar",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold))
            : const Text("Cancelar",
                style: TextStyle(
                    color: Color(0xFFFF0066),
                    fontSize: 14,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold)),
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnIniciar == true
            ? () {}
            : () {
                Dialogs.bottomMaterialDialog(
                    msg: 'Deseja cancelar a viagem?',
                    title: 'Cancelar Viagem',
                    context: context,
                    actions: [
                      IconsOutlineButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        text: 'Não',
                        iconData: Icons.cancel_outlined,
                        textStyle: const TextStyle(color: Colors.grey),
                        iconColor: Colors.grey,
                      ),
                      IconsButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          MostrarDialog();
                        },
                        text: 'Sim',
                        iconData: Icons.cancel,
                        color: const Color(0xFFFF0066),
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                    ]);
              },
      ),
    );
  }

  Future<void> _Call() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: contacto_viajante,
    );
    await launchUrl(launchUri);
  }

  Widget _BtnConcluir() {
    return SizedBox(
      width: 230,
      height: 50,
      child: TextButton.icon(
        icon: btnIniciar == false
            ? const Icon(
                Icons.done,
                color: Colors.grey,
                size: 40,
              )
            : const Icon(
                Icons.done,
                color: Colors.green,
                size: 40,
              ),
        label: btnIniciar == false
            ? const Text("Finalizar",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold))
            : const Text("Finalizar",
                style: TextStyle(
                    color: Colors.green,
                    fontSize: 14,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold)),
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnIniciar == false
            ? () {}
            : () {
                Dialogs.bottomMaterialDialog(
                    msg: 'Deseja finalizar a viagem?',
                    title: 'Concluir Viagem',
                    context: context,
                    actions: [
                      IconsOutlineButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        text: 'Não',
                        iconData: Icons.cancel_outlined,
                        textStyle: const TextStyle(color: Colors.grey),
                        iconColor: Colors.grey,
                      ),
                      IconsButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          elapsedCountUpController.pause();
                          tempo_viagem = elapsedCountUpController.getTime();
                          FinalizargetCurrentLocation();
                        },
                        text: 'Sim',
                        iconData: Icons.done,
                        color: Colors.green,
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                    ]);
              },
      ),
    );
  }

  Widget _BtnIniciar() {
    return SizedBox(
      width: 230,
      height: 50,
      child: btnPegar == false
          ? TextButton.icon(
              icon: const Icon(
                Icons.back_hand_rounded,
                color: Color(0xFFFF0066),
                size: 40,
              ),
              label: const Text("Cheguei",
                  style: TextStyle(
                      color: Color(0xFFFF0066),
                      fontSize: 14,
                      fontFamily: 'Gotham',
                      fontWeight: FontWeight.bold)),
              style: TextButton.styleFrom(
                  backgroundColor: Colors.white,
                  elevation: 10,
                  padding: const EdgeInsets.all(0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100),
                  )),
              onPressed: () async {
                await SessionManager().set("btnPegar", true);
                setState(() {
                  btnPegar = true;
                });
                ActualizaPedido("3");
              },
            )
          : btnPegar == true && btnIniciar == false
              ? TextButton.icon(
                  icon: const Icon(
                    Icons.play_circle,
                    color: Color(0xFF00008B),
                    size: 40,
                  ),
                  label: const Text("Começar",
                      style: TextStyle(
                          color: Color(0xFF00008B),
                          fontSize: 14,
                          fontFamily: 'Gotham',
                          fontWeight: FontWeight.bold)),
                  style: TextButton.styleFrom(
                      backgroundColor: Colors.white,
                      elevation: 10,
                      padding: const EdgeInsets.all(0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(100),
                      )),
                  onPressed: () {
                    Dialogs.bottomMaterialDialog(
                        msg: 'Deseja iniciar a viagem?',
                        title: 'Inicializar Viagem',
                        context: context,
                        actions: [
                          IconsOutlineButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            text: 'Não',
                            iconData: Icons.cancel_outlined,
                            textStyle: const TextStyle(color: Colors.grey),
                            iconColor: Colors.grey,
                          ),
                          IconsButton(
                            onPressed: () async {
                              Navigator.of(context).pop();
                              await SessionManager().set("btnIniciar", true);
                              setState(() {
                                btnIniciar = true;
                              });
                              _IniciarViagem();
                              elapsedCountUpController.start();
                            },
                            text: 'Sim',
                            iconData: Icons.play_circle,
                            color: Colors.green,
                            textStyle: const TextStyle(color: Colors.white),
                            iconColor: Colors.white,
                          ),
                        ]);
                  },
                )
              : btnIniciar == true && btnPausar == false
                  ? TextButton.icon(
                      icon: const Icon(
                        Icons.pause_circle,
                        color: Colors.black,
                        size: 40,
                      ),
                      label: const Text("Pausar",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                              fontFamily: 'Gotham',
                              fontWeight: FontWeight.bold)),
                      style: TextButton.styleFrom(
                          backgroundColor: Colors.white,
                          elevation: 10,
                          padding: const EdgeInsets.all(0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(100),
                          )),
                      onPressed: () {
                        Dialogs.bottomMaterialDialog(
                            msg: 'Deseja pausar a viagem?',
                            title: 'Pausar Viagem',
                            context: context,
                            actions: [
                              IconsOutlineButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                text: 'Não',
                                iconData: Icons.cancel_outlined,
                                textStyle: const TextStyle(color: Colors.grey),
                                iconColor: Colors.grey,
                              ),
                              IconsButton(
                                onPressed: () async {
                                  Navigator.of(context).pop();
                                  await SessionManager().set("btnPausar", true);
                                  setState(() {
                                    btnPausar = true;
                                  });
                                  _PausarViagem();
                                  elapsedCountUpController.pause();
                                },
                                text: 'Sim',
                                iconData: Icons.done,
                                color: Colors.green,
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                            ]);
                      },
                    )
                  : btnPausar == true && btnRetomar == false
                      ? TextButton.icon(
                          icon: const Icon(
                            Icons.play_circle,
                            color: Color(0xFF00008B),
                            size: 40,
                          ),
                          label: const Text("Retomar",
                              style: TextStyle(
                                  color: Color(0xFF00008B),
                                  fontSize: 14,
                                  fontFamily: 'Gotham',
                                  fontWeight: FontWeight.bold)),
                          style: TextButton.styleFrom(
                              backgroundColor: Colors.white,
                              elevation: 10,
                              padding: const EdgeInsets.all(0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              )),
                          onPressed: () {
                            Dialogs.bottomMaterialDialog(
                                msg: 'Deseja retomar a viagem?',
                                title: 'Retomar Viagem',
                                context: context,
                                actions: [
                                  IconsOutlineButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    text: 'Não',
                                    iconData: Icons.cancel_outlined,
                                    textStyle:
                                        const TextStyle(color: Colors.grey),
                                    iconColor: Colors.grey,
                                  ),
                                  IconsButton(
                                    onPressed: () async {
                                      Navigator.of(context).pop();
                                      await SessionManager()
                                          .set("btnRetomar", true);
                                      setState(() {
                                        btnRetomar = true;
                                      });
                                      _RetomarViagem();
                                      elapsedCountUpController.resume();
                                    },
                                    text: 'Sim',
                                    iconData: Icons.done,
                                    color: Colors.green,
                                    textStyle:
                                        const TextStyle(color: Colors.white),
                                    iconColor: Colors.white,
                                  ),
                                ]);
                          },
                        )
                      : TextButton.icon(
                          icon: const Icon(
                            Icons.play_circle,
                            color: Colors.grey,
                            size: 40,
                          ),
                          label: const Text("Começar",
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 14,
                                  fontFamily: 'Gotham',
                                  fontWeight: FontWeight.bold)),
                          style: TextButton.styleFrom(
                              backgroundColor: Colors.white,
                              elevation: 10,
                              padding: const EdgeInsets.all(0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              )),
                          onPressed: () {},
                        ),
    );
  }

  Future _IniciarViagem() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/iniciar');
      var response = await http.post(url, body: {
        "origem": origem_viajante.toString(),
        "destino": destino_viajante.toString(),
        "desc_origem": origem1.toString(),
        "desc_destino": destino1.toString(),
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
        "distancia_viagem": calc_distancia_viagem.toString(),
        "tempo_viagem": "0",
      });
      final map = json.decode(response.body);
      final dados = map["viagem"];
      final msgr = map["retorno"];
      if (msgr == 1) {
        idViagem = dados["id"];
        await SessionManager().set("idViagem", idViagem);
        setState(() {
          status_pedido = 4;
        });
        ActualizaPedido("4");
        AlertaAbrirMaps();
      }
    } catch (e) {
      print(e);
    }
  }

  AlertaAbrirMaps() {
    Dialogs.bottomMaterialDialog(
        msg: 'Deseja seguir a viagem pelo Google Maps?',
        title: 'Abrir Google Maps',
        context: context,
        actions: [
          IconsOutlineButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            text: 'Não',
            iconData: Icons.cancel_outlined,
            textStyle: const TextStyle(color: Colors.white),
            iconColor: Colors.white,
            color: Colors.red,
          ),
          IconsButton(
            onPressed: () async {
              Navigator.of(context).pop();
              abrirGoogleMaps();
            },
            text: 'Sim',
            iconData: Icons.done,
            color: Colors.green,
            textStyle: const TextStyle(color: Colors.white),
            iconColor: Colors.white,
          ),
        ]);
  }

  Future InfoViagem() async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/viagem/ver-dados');
      var response = await http.post(url, body: {
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final Dadosviagem1 = map["viagem"];
      final DadosPagamento1 = map["pagamento"];
      idViagem = Dadosviagem1["id"];
      desconto = double.tryParse(DadosPagamento1["desconto"]) ?? 0.0;
    } catch (e) {
      print(e);
    }
  }

  Future _CancelarViagem() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/pedido/cancelar-motorista');
      var response = await http.post(url, body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
        "motivo": myMotivo.value.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        setState(() {
          status_viagem = false;
          status_chamada = false;
          call = false;
        });
        ActualizaPedidoCancelado("0");
        await SessionManager().set("call", false);
        await SessionManager().set("status_viagem", false);
        await SessionManager().set("status_chamada", false);
        numeropedido = "";
        await SessionManager().set("numeropedido", "");
        _viagemTimer.cancel();
        _viagemTimer2.cancel();
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => SplashPage()),
          (Route<dynamic> route) => false,
        );
      } else {}
    } catch (e) {
      print(e);
    }
  }

  RadioGroupController myMotivo = RadioGroupController();

  Future _PausarViagem() async {
    try {
      DateTime now = DateTime.now();
      String inicioParagem = DateFormat('yyyy-M-dd H:m:s').format(now);
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/actualizar');
      var response = await http.post(url, body: {
        "pedido": numeropedido.toString(),
        "local_paragem": posicaomotorista.toString(),
        "inicio_paragem": inicioParagem.toString(),
        "id": idViagem.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        UpdategetCurrentLocation();
        ActualizaPedido("5");
        setState(() {
          status_pedido = 5;
        });
      } else {}
    } catch (e) {
      print(e);
    }
  }

  Future _RetomarViagem() async {
    try {
      DateTime now = DateTime.now();
      String fimParagem = DateFormat('yyyy-M-dd H:m:s').format(now);
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/actualizar');
      var response = await http.post(url, body: {
        "pedido": numeropedido.toString(),
        "fim_paragem": fimParagem.toString(),
        "id": idViagem.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        ActualizaPedido("6");
        _TempoParagem();
        setState(() {
          status_pedido = 6;
        });
      } else {}
    } catch (e) {
      print(e);
    }
  }

  Future _TempoParagem() async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/listar/tempo-paragem');
      var response = await http.post(url, body: {
        "viagem": idViagem.toString(),
      });
      final map = json.decode(response.body);
      final viagem = map["viagem"];
      final tempo = int.tryParse(viagem["tempo_paragem"])!;
      if ((limiteParagem ~/ 60) >= tempo) {
        tempoParagemFinal = 0;
      } else {
        tempoParagemFinal =
            int.tryParse(viagem["tempo_paragem"])! - limiteParagem ~/ 60;
      }
    } catch (e) {
      print(e);
    }
  }

  Future Recibo() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/actualizar');
      var response = await http.post(url, body: {
        "pedido": numeropedido.toString(),
        "local_paragem": posicaomotorista.toString(),
        "id": idViagem.toString(),
        "destino": posicaomotorista.toString(),
        "desc_destino": destino1.toString(),
        "tempo_viagem": "0",
        "tempo_paragem": "0",
        "status": "2",
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        _viagemTimer.cancel();
        _viagemTimer2.cancel();
        // Navigator.of(context).push(CupertinoPageRoute(
        //     builder: (BuildContext context) => FinalizarPage()));
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => FinalizarPage()),
          (Route<dynamic> route) => false,
        );
      } else {}
    } catch (e) {
      print(e);
    }
  }

  Future _CalcularPagamento() async {
    InfoViagem();
    DadosViagem();
    calcularDistancia();
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/viagem/pagamento-actualizar');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave": ChavePublica.toString(),
        "viagem": idViagem.toString(),
        "valor": valorViagem.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        ActualizaPedido("7");
        Recibo();
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message:
                'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
          ),
        );
      }
    } catch (e) {
      print(e);
    }
  }

  Future ActualizaPedido(String status) async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/pedido/actualizar');
      var response = await http.post(url, body: {
        "status": status,
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final dados = map["pedido"];
    } catch (e) {
      print(e);
    }
  }

  Future ActualizaPedidoCancelado(String status) async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/pedido/actualizar');
      var response = await http.post(url, body: {
        "status": status,
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
    } catch (e) {
      print(e);
    }
  }

  Future DadosViagem() async {
    try {
      String baseURL = "$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final dados_pedido = map["pedido"];
      final retorno = map["retorno"];
      if (retorno == 1) {
        setState(() {
          status_passageiro = dados_pedido['status_passageiro'];
          origem_viajante = dados_pedido['origem'];
          destino_viajante = dados_pedido['destino'];
          status_pedido = dados_pedido['status'];
        });
        if (status_pedido == 2) {
          urlNavegacao =
              "https://www.google.com/maps/dir/$posicaomotorista/$origem_viajante";
        } else {
          urlNavegacao =
              "https://www.google.com/maps/dir/$origem_viajante/$destino_viajante";
        }
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ops! Ocorreu um erro ao carregar dados da viagem.',
          ),
        );
      }
    } catch (e) {
      print(e);
    }
  }

  void calcularDistancia() {
    setState(() {
      double? lat1 = double.tryParse(origem_viajante.toString().split(',')[0]);
      double? long1 = double.tryParse(origem_viajante.toString().split(',')[1]);
      double? lat2 = double.tryParse(posicaomotorista.toString().split(',')[0]);
      double? long2 =
          double.tryParse(posicaomotorista.toString().split(',')[1]);
      distance_rota = Geolocator.distanceBetween(lat1!, long1!, lat2!, long2!);
      calc_distancia_viagem2 = distance_rota / 1000;

      valorParagem = tempoParagemFinal.toInt() * taxaParagem.toDouble();
      double distanciaContagem = calc_distancia_viagem2 - inicio_cobranca;
      final t1 =
          tarifa_base + (distanciaContagem.round() * taxakm + valorParagem);
      tdesc = t1 * desconto / 100;
      if (calc_distancia_viagem2.round() <= inicio_cobranca) {
        valorViagem = (tarifa_base + valorParagem) - tdesc;
      } else {
        valorViagem = t1 - tdesc;
      }
    });
  }

  void PegarTarifa() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/tarifa');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final tarifa = map["tarifa"];
      tarifa_base = double.tryParse(tarifa[0]['tarifa_base'])!;
      taxakm = double.tryParse(tarifa[0]['tarifa_km'])!;
      inicio_cobranca = int.parse(tarifa[0]['inicio_cobranca']);
      print(tarifa);
    } catch (e) {
      print(e);
    }
  }

  Future getTaxaParagem() async {
    try {
      String baseURL = "$endpoint/corridaapi/listar/config-paragem";
      final response = await http.get(Uri.parse(baseURL));
      final map = json.decode(response.body);
      final res = map["config_paragem"];
      taxaParagem = int.tryParse(res["taxa"])!;
      limiteParagem = double.parse(res["tempo_limite"])!;
    } catch (e) {
      print(e);
    }
  }

  void ActivarViagem() async {
    setState(() {
      status_viagem = true;
    });
    await SessionManager().set("status_viagem", true);
    await SessionManager().set("numeropedido", numeropedido);
  }

  Future abrirSMS() async {
    try {
      String baseURL = "$endpoint/corridaapi/chat/abrir-msg";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
    } catch (e) {
      print(e);
    }
  }

  Future verificarSMS() async {
    try {
      String baseURL = "$endpoint/corridaapi/chat/notificacao";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      var msgChat = map["mensagens"];
      var msgRotorno = map["retorno"];
      if (msgRotorno == 1) {
        // LocalNotification.showBigTextNotification(
        //     title: 'Nova Mensagem',
        //     body: "",
        //     fln: flutterLocalNotificationsPlugin,
        //     // ignore: use_build_context_synchronously
        //     payload: Navigator.of(context).push(CupertinoPageRoute(
        //         builder: (BuildContext context) => ChatPage())));
      }
      abrirSMS();
    } catch (e) {
      print(e);
    }
  }

  void VerificarPedido() async {
    if (status_pedido == 0) {
      status_viagem = false;
      status_chamada = false;
      call = false;
      await SessionManager().set("call", false);
      await SessionManager().set("status_viagem", false);
      await SessionManager().set("status_chamada", false);
      numeropedido = "";
      await SessionManager().set("numeropedido", "");
      foregroundTaskService.FirstTaskHandler.showNotification(2, "Viagem Cancelada", "A sua viagem foi cancelada pelo Passageiro");
      _viagemTimer.cancel();
      _viagemTimer2.cancel();
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => SplashPage()),
        (Route<dynamic> route) => false,
      );
    } else {}
  }

  void VerificarStatusPassageiro() async {
    if (status_passageiro == 0) {
      status_viagem = false;
      status_chamada = false;
      call = false;
      await SessionManager().set("call", false);
      await SessionManager().set("status_viagem", false);
      await SessionManager().set("status_chamada", false);
      numeropedido = "";
      await SessionManager().set("numeropedido", "");
      foregroundTaskService.FirstTaskHandler.showNotification(3, "Corrida abandonada", "O Passageiro desistiu da corrida");
      _viagemTimer.cancel();
      _viagemTimer2.cancel();
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => SplashPage()),
        (Route<dynamic> route) => false,
      );
    } else {
      _viagemTimer2.cancel();
    }
  }

  late Timer _viagemTimer;
  late Timer _viagemTimer2;

  @override
  void initState() {
    super.initState();
    conexao();
    ActivarViagem();
    getCurrentLocation();
    getPolyPoint();
    getTaxaParagem();
    PegarTarifa();
    DadosViagem();
    controllerMap.getAddress();
    _viagemTimer = Timer.periodic(const Duration(seconds: 4), (Timer t) {
      conexao();
      if (con == true) {
        verificarSMS();
        DadosViagem();
        VerificarPedido();
        UpdategetCurrentLocation();
        Tracking();
      } else {}
    });
    _viagemTimer2 = Timer.periodic(const Duration(seconds: 60), (Timer t) {
      conexao();
      if (con == true) {
        VerificarStatusPassageiro();
      } else {}
    });
    foregroundTaskService.startCallback();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget _BtnChat() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDEEE9),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).push(CupertinoPageRoute(
              builder: (BuildContext context) => ChatPage()));
        },
        child: const Icon(
          Icons.chat_outlined,
          color: Color(0xFF00008B),
          size: 45,
        ),
      ),
    );
  }

  Widget _BtnCall() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDEEE9),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _Call();
        },
        child: const Icon(
          Icons.call,
          color: Color(0xFF00008B),
          size: 45,
        ),
      ),
    );
  }

  Widget _BtnNavegacao() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDEEE9),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          abrirGoogleMaps();
        },
        child: const Icon(
          Icons.directions,
          color: Color(0xFF00008B),
          size: 45,
        ),
      ),
    );
  }

  void abrirGoogleMaps() async {
    if (await canLaunchUrl(Uri.parse(urlNavegacao))) {
      await launchUrl(Uri.parse(urlNavegacao));
    } else {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.info(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) async {
        if (status_service == 1) {
          // Exibe uma mensagem de aviso se o status do serviço for 1
          showTopSnackBar(
            Overlay.of(context),
            const CustomSnackBar.info(
              message: 'Não pode fechar o app com o serviço ligado.',
            ),
          );
        } else {
          // Se o status do serviço não for 1, prossegue com o fechamento
          if (Platform.isAndroid) {
            await Future.delayed(
                const Duration(milliseconds: 1000)); // Espera 1 segundo
            SystemNavigator.pop(); // Fecha o app no Android
          } else if (Platform.isIOS) {
            await Future.delayed(
                const Duration(milliseconds: 1000)); // Espera 1 segundo
            exit(0); // Fecha o app no iOS
          }
        }
      },
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(fontFamily: 'Gotham'),
        home: Scaffold(
          body: Stack(
            children: [
              SafeArea(
                child: status_pedido == 2
                    ? GoogleMap(
                        markers: {
                          Marker(
                            markerId: const MarkerId("location"),
                            position: LatLng(posicaoV1, posicaoV2),
                            icon: marker,
                          ),
                          Marker(
                            markerId: const MarkerId("origem"),
                            position: LatLng(posicaoV1, posicaoV2),
                            icon: markerIcon1,
                          ),
                          /* Marker(
                            markerId: const MarkerId("destino"),
                            position: LatLng(lat1!, long1!),
                            icon: markerIcon2,
                          )*/
                        },
                        polylines: {
                          Polyline(
                            polylineId: const PolylineId("route"),
                            points: polylineCoordinates2,
                            color: const Color(0xFFFF0066),
                            width: 6,
                          ),
                        },
                        mapType: MapType.normal,
                        initialCameraPosition: _initialLocation,
                        myLocationEnabled: false,
                        myLocationButtonEnabled: false,
                        zoomGesturesEnabled: true,
                        zoomControlsEnabled: false,
                        onMapCreated: (GoogleMapController controller) async {
                          _controller.complete(controller);
                        },
                      )
                    : GoogleMap(
                        markers: {
                          Marker(
                            markerId: const MarkerId("location"),
                            position: LatLng(posicaoV1, posicaoV2),
                            icon: marker,
                          ),
                          /* Marker(
                            markerId: const MarkerId("origem"),
                            position: LatLng(lat1!, long1!),
                            icon: markerIcon1,
                          ),*/
                          Marker(
                            markerId: const MarkerId("destino"),
                            position: destino,
                            icon: markerIcon2,
                          )
                        },
                        polylines: {
                          Polyline(
                            polylineId: const PolylineId("route"),
                            points: polylineCoordinates,
                            color: const Color(0xFFFF0066),
                            width: 6,
                          ),
                        },
                        mapType: MapType.normal,
                        initialCameraPosition: _initialLocation,
                        myLocationEnabled: true,
                        myLocationButtonEnabled: false,
                        zoomGesturesEnabled: true,
                        zoomControlsEnabled: false,
                        onMapCreated: (GoogleMapController controller) async {
                          _controller.complete(controller);
                        },
                      ),
              ),
              SafeArea(
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                      padding:
                          const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 0,
                          ),
                          Container(
                            padding: const EdgeInsets.all(0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0),
                              color: const Color(0xFFFF0066),
                            ),
                            width: MediaQuery.of(context).size.width,
                            height: 65,
                            child: Column(
                              children: [
                                ListTile(
                                  leading: const Icon(Icons.location_on,
                                      size: 30, color: Color(0xFF00008B)),
                                  dense: true,
                                  title: status_pedido == 2
                                      ? Text(
                                          "$origem1",
                                          maxLines: 1,
                                          overflow: TextOverflow.visible,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'gotham',
                                          ),
                                        )
                                      : status_pedido == 5
                                          ? const Text(
                                              "Viagem Parada",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'gotham',
                                              ),
                                            )
                                          : Text(
                                              "$destino1",
                                              maxLines: 1,
                                              overflow: TextOverflow.visible,
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'gotham',
                                              ),
                                            ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )),
                ),
              ),
              SafeArea(
                  child: Padding(
                padding: EdgeInsets.only(
                  right: MediaQuery.of(context).size.width / 1.5,
                  top: 70,
                  left: 10,
                ),
                child: Column(
                  children: [
                    _BtnNavegacao(),
                    const SizedBox(
                      height: 5,
                    ),
                    _BtnChat(),
                    const SizedBox(
                      height: 5,
                    ),
                    _BtnCall(),
                  ],
                ),
              )),
              SafeArea(
                  child: Padding(
                padding: EdgeInsets.only(
                  right: 10,
                  top: 70,
                  left: MediaQuery.of(context).size.width / 1.7,
                ),
                child: Column(
                  children: [
                    _BtnCancelar(),
                    const SizedBox(
                      height: 8,
                    ),
                    _BtnIniciar(),
                    const SizedBox(
                      height: 8,
                    ),
                    _BtnConcluir(),
                  ],
                ),
              )),
              Container(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: [
                    Row(
                      children: [
                        InfoBar(),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ));
}
