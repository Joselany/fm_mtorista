import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import '../config/Constats.dart';
import 'ConfigPerfilPage3.dart';
import 'Loading.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:intl/intl.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;

import 'PrincipalPage.dart';
import 'SplashPage.dart';

class ConfigPerfilPage2 extends StatefulWidget {
  @override
  _ConfigPerfilPage2 createState() => _ConfigPerfilPage2();
}

class _ConfigPerfilPage2 extends State<ConfigPerfilPage2> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();
  String? provincia = 'Luanda';
  final TextEditingController _bi = TextEditingController();
  final TextEditingController _carta = TextEditingController();
  final TextEditingController _cidade = TextEditingController();
  final TextEditingController _endereco = TextEditingController();

  DateTime now = DateTime.now();
  late TextEditingController _validadebi;
  late TextEditingController _validadecarta;
  var dataActual = DateTime.now();

  @override
  void initState() {
    _validadebi = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    _validadecarta = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    super.initState();
  }

  List<String> items = [
    'Luanda',
  ];

  loading load = loading();

  Future Registar() async {
    try {
      setState(() {
        btnRg3 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/info');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "provincia": provincia,
        "cidade": _cidade.text,
        "endereco": _endereco.text,
        "carta_conducao": _carta.text,
        "bi": _bi.text,
        "validade_bi": _validadebi.text,
        "validade_carta_conducao": _validadecarta.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["info_motorista"];
      if (msgr == 1) {
        provincia_motorista = provincia.toString();
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        setState(() {
          btnRg3 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => ConfigPerfilPage3()));
      } else if (msgr == 0) {
        setState(() {
          btnRg3 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message:
                'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg3 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _TxtProvincia() {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        barrierColor: Colors.black12,
        style: const TextStyle(
          fontFamily: 'Gotham',
          color: Colors.black54,
        ),
        buttonStyleData: ButtonStyleData(
          height: 60,
          width: MediaQuery.of(context).size.width * 0.80,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          overlayColor: WidgetStateProperty.all(Colors.black26),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.black12,
          ),
        ),
        isExpanded: true,
        hint: const Text(
          'Província',
          style: TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        items: items
            .map((item) => DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item,
                    style: const TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ))
            .toList(),
        value: provincia,
        onChanged: (value) {
          setState(() {
            provincia = value;
            provincia_motorista = value;
            print(value);
          });
        },
        menuItemStyleData: const MenuItemStyleData(
          height: 60, // Correção: altura dos itens definida aqui
          padding: EdgeInsets.symmetric(horizontal: 16),
        ),
        dropdownStyleData: const DropdownStyleData(
          maxHeight: 200,
          scrollPadding: EdgeInsets.all(8), // Ajuste para evitar sobreposição
        ),
      ),
    );
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnRg3 == false
            ? () {
                if (_bi.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe o Nº do Bilhete de Identidade.',
                    ),
                  );
                } else if (_validadebi.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe a data de validade do Bilhete de Identidade.',
                    ),
                  );
                } else if (_carta.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe o Nº da Carta/Licença.',
                    ),
                  );
                } else if (_validadecarta.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe a data de validade da Carta/Licença.',
                    ),
                  );
                } else if (_cidade.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe a sua Cidade.',
                    ),
                  );
                } else if (_endereco.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe o seu Endereço.',
                    ),
                  );
                } else {
                  Registar();
                }
              }
            : () {},
        child: btnRg3 == false
            ? const Text(
                'Continuar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _TxtBI() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº. Bilhete de Identidade",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.add_card,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _bi,
      ),
    );
  }

  Widget _TxtValidadeBI() {
    return Container(
      color: Colors.black12,
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextFormField(
        keyboardType: TextInputType.text,
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        onTap: () async {
          await showDate1(context);
        },
        readOnly: true,
        textInputAction: TextInputAction.next,
        decoration: const InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(width: 0, color: Colors.black12),
          ),
          fillColor: Colors.black12,
          prefixIcon: Icon(
            Icons.calendar_month_outlined,
            color: Color(0xFF00008B),
            size: 25,
          ),
          hintText: 'Data de Validade',
        ),
        validator: FormValidation.requiredTextField,
        controller: _validadebi,
      ),
    );
  }

  Widget _TxtValidadeCarta() {
    return Container(
      color: Colors.black12,
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextFormField(
        keyboardType: TextInputType.text,
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        onTap: () async {
          await showDate2(context);
        },
        readOnly: true,
        textInputAction: TextInputAction.next,
        decoration: const InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(width: 0, color: Colors.black12),
          ),
          fillColor: Colors.black12,
          prefixIcon: Icon(
            Icons.calendar_month_outlined,
            color: Color(0xFF00008B),
            size: 25,
          ),
          hintText: 'Data de Validade',
        ),
        validator: FormValidation.requiredTextField,
        controller: _validadecarta,
      ),
    );
  }

  Widget _TxtCidade() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Cidade",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.location_city,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _cidade,
      ),
    );
  }

  Widget _TxtEndereco() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Endereço",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.local_library_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _endereco,
      ),
    );
  }

  Widget _TxtCarta() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº Carta/Licença",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.add_card,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _carta,
      ),
    );
  }

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2023),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      _validadebi = TextEditingController(text: selectdata1);
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2023),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      _validadecarta = TextEditingController(text: selectdata1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(
                  height: 40,
                ),
                const Align(
                  alignment: Alignment.center,
                ),
                _TxtBI(),
                const SizedBox(
                  height: 10,
                ),
                _TxtValidadeBI(),
                const SizedBox(
                  height: 10,
                ),
                _TxtCarta(),
                const SizedBox(
                  height: 10,
                ),
                _TxtValidadeCarta(),
                const SizedBox(
                  height: 10,
                ),
                _TxtProvincia(),
                const SizedBox(
                  height: 10,
                ),
                _TxtCidade(),
                const SizedBox(
                  height: 10,
                ),
                _TxtEndereco(),
                const SizedBox(
                  height: 20,
                ),
                _BtnComecar(),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Configurar dados Pessoais",
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
