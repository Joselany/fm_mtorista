import 'dart:convert';
import 'package:fastmoto_piloto/config/Constats.dart';
import 'package:fastmoto_piloto/pages/ConfigPerfilPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:geolocator/geolocator.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'CarregarPerfilPage.dart';
import 'DigitePinPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'ResetSenhaPage.dart';
import 'SplashPage.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPage createState() => _LoginPage();
}

class _LoginPage extends State<LoginPage> {
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  var seguro = true;
  bool phone = false;
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController _senha = TextEditingController();

  @override
  void initState() {
    myfocus.requestFocus();
    super.initState();
  }

  Future<Position> posicaoActual() async {
    LocationPermission permission;
    bool activado = await Geolocator.isLocationServiceEnabled();
    if (!activado) {
      return Future.error('Por favor, habilite a sua localização');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      return Future.error('Você precisa autorizar o acesso à localização');
    }
    ValidarNumero();
    return await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(accuracy: LocationAccuracy.best));
  }

  loading load = loading();
  FocusNode myfocus = FocusNode();

  void GerarSessao(String id, chave, idMotoristaInteiro) async {
    await SessionManager().set("idMotorista", id);
    await SessionManager().set("ChavePublica", chave);
    await SessionManager().set("idMotoristaInteiro", idMotoristaInteiro);
  }

  Future Validarlogin() async {
    try {
      setState(() {
        btnRg1 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/login');
      var response = await http.post(url, body: {
        "usuario": PhoneController.text.toString(),
        "senha": _senha.text.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["perfil_motorista"];
      final cp = map['chave_publica'];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        idMotorista = dados['id'];
        idMotoristaInteiro = dados['int_id'];
        ChavePublica = cp;
        GerarSessao(idMotorista, ChavePublica, idMotoristaInteiro);
        setState(() {
          btnRg1 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarregarPerfilPage()));
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Telefone ou Palavra-passe inválida.',
          ),
        );
        setState(() {
          btnRg1 = false;
        });
      }
    } catch (e) {
      setState(() {
        btnRg1 = false;
      });
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message: 'Ops! Erro ao efectuar o login. Verifique a sua Internet',
        ),
      );
    }
  }

  Future ValidarNumero() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo1');
      var response = await http.post(url, body: {
        "telefone": PhoneController.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      print(map);
      print(msgr);
      print(map);
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPage()));
      } else if (msgr == 0) {
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => ConfigPerfilPage()));
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnRg1 == false
            ? () {
                numeroTel = PhoneController.text;
                if (PhoneController.text == "") {
                  showTopSnackBar(
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Por favor, Preencher o número de telefone.',
                    ),
                  );
                  myfocus.requestFocus();
                } else {
                  Validarlogin();
                }
              }
            : () {},
        child: btnRg1 == false
            ? Padding(
                padding: const EdgeInsets.only(top: 10),
                child: const Text(
                  'Iniciar sessão',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'gotham',
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                  maxLines: 1,
                ))
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _TxtSenha() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Palavra-passe",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 20,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.lock_outline,
          color: Color(0xFF00008B),
          size: 25,
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _toggleVisibility = !_toggleVisibility;
            });
          },
          icon: _toggleVisibility
              ? const Icon(
                  Icons.visibility_off_outlined,
                  size: 20,
                )
              : const Icon(
                  Icons.visibility_outlined,
                  size: 20,
                ),
          color: const Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _senha,
        obscureText: _toggleVisibility,
      ),
    );
  }

  String text = "";
  int maxLength = 9;

  Widget _TxtTelefone() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        onChanged: (String newVal) {
          if (newVal.length <= maxLength) {
            text = newVal;
          } else {
            PhoneController.text = text;
          }
        },
        keyboardType: TextInputType.number,
        labelText: "Telefone",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 20,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.phone_android_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: PhoneController,
      ),
    );
  }

  Widget _btnRegisto() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => ConfigPerfilPage()));
      },
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Não possui conta? ',
              style: TextStyle(
                color: Colors.black,
                fontSize: 12.0,
                fontWeight: FontWeight.normal,
              ),
            ),
            TextSpan(
              text: 'Registar-se.',
              style: TextStyle(
                decoration: TextDecoration.underline,
                color: Colors.black,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _btnReset() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (BuildContext context) => ResetSenhaPage()));
      },
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Esqueci-me da palavra-passe.',
              style: TextStyle(
                color: Colors.black54,
                fontSize: 12.0,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Center(
                child: Image(
                  image: AssetImage("assets/images/logo_rosa.png"),
                  width: 280,
                  height: 154,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              const Text(
                'ENTRAR',
                style: TextStyle(
                  color: Colors.black54,
                  letterSpacing: 0,
                  fontSize: 22.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              _TxtTelefone(),
              const SizedBox(
                height: 10,
              ),
              _TxtSenha(),
              const SizedBox(
                height: 15,
              ),
              _btnReset(),
              const SizedBox(
                height: 15,
              ),
              _BtnComecar(),
              const SizedBox(
                height: 15,
              ),
              _btnRegisto(),
              const SizedBox(
                height: 15,
              ),
            ],
          ),
        ));
  }
}
