import 'dart:async';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import 'ChamadaPage.dart';
import 'PrincipalPage.dart';
import 'Loading.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

bool carregarDados = false;

class CarregarPerfilPage extends StatefulWidget {
  @override
  _CarregarPerfilPage createState() => _CarregarPerfilPage();
}

class _CarregarPerfilPage extends State<CarregarPerfilPage> {
  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  FocusNode myfocus = FocusNode();

  final TextEditingController locationController = TextEditingController();
  final TextEditingController servicoController = TextEditingController();
  final TextEditingController locationController2 = TextEditingController();
  loading load = loading();

  Future<void> getCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 13.5,
      )));
      setState(() {
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
      });
    }).catchError((e) {
      print(e);
    });
  }

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  void ActivarSessao() async {
    await SessionManager().set("btnIniciar", false);
    await SessionManager().set("btnPausar", false);
    await SessionManager().set("btnPegar", false);
    await SessionManager().set("btnRetomar", false);
    await SessionManager().set("btnConcluir", false);
    sessao_usuario = 1;
    await SessionManager().set("sessao_usuario", 1);
    status_chamada = false;
    call = false;
    await SessionManager().set("call", false);
  }

  Future CarregarDados() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/dados');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final perfil = map["perfil_motorista"];
      rating = double.parse(map['avaliacao']);
      avaliacao_motorista = double.parse(map['avaliacao']);
      nomeMotorista = perfil['nome'];
      sobrenomeMotorista = perfil['apelido'];
      fotoPerfil = perfil['foto'].startsWith('http')
          ? perfil['foto']
          : urlImagem + perfil['foto'];
      emailMotorista = perfil['email'];
      telefoneMotorista = perfil['telefone'];
      setState(() {
        carregarDados = true;
      });
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => PrincipalPage()));
    } catch (e) {
      print(e);
    }
  }

  void _GanhosDia() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/ganhos-diarios');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      ganhoDia = map['ganhos'];
    } catch (e) {
      print(e);
    }
  }

  Future ConsultarSaldo() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/saldo');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      setState(() {
        SaldoConta = double.parse(map['saldo']);
      });
    } catch (e) {
      print(e);
    }
  }

  void PegarTarifa() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/tarifa');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final tarifa = map["tarifa"];
      tarifa_base = double.tryParse(tarifa[0]['tarifa_base'])!;
      taxakm = double.tryParse(tarifa[0]['tarifa_km'])!;
      print(tarifa_base);
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
    getCurrentLocation();
    ActivarSessao();
    CarregarDados();
    PegarTarifa();
    ConsultarSaldo();
    _GanhosDia();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Aguarde um momento.",
                    style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'gotham',
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                SizedBox(
                  height: 10,
                ),
                Text("Estamos a configurar o seu perfil...",
                    style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'gotham',
                        fontSize: 14,
                        fontWeight: FontWeight.normal)),
                SizedBox(
                  height: 10,
                ),
                CircularProgressIndicator.adaptive(
                  backgroundColor: Colors.white,
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF0066)),
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
