import 'dart:convert';
import 'package:fastmoto_piloto/pages/InfoPerfilPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';

class EditarPerfilPage extends StatefulWidget {
  @override
  _EditarPerfilPage createState() => _EditarPerfilPage();
}

class _EditarPerfilPage extends State<EditarPerfilPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();
  final globalKey = GlobalKey<FormState>();
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController _senha = TextEditingController();

  loading load = loading();

  Future Registar() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/perfil');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "nome": _nome.text,
          "sobrenome": _sobrenome.text,
          "email": _email.text,
        },
      );
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(message: 'Actualizado com sucesso.'),
        );
        setState(() {
          btnRg2 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (BuildContext context) => PrincipalPage()),
        );
      } else if (msgr == 0) {
        setState(() {
          btnRg2 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao actualizar o registo.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  void pegarDados() {
    _email.text = emailMotorista.toString();
    _nome.text = nomeMotorista.toString();
    _sobrenome.text = sobrenomeMotorista.toString();
  }

  @override
  void initState() {
    pegarDados();
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: const Color(0xFFFF0066),
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: EdgeInsets.only(top: 12.0),
        ),
        onPressed:
            btnRg2 == false
                ? () {
                  if (_nome.text == '') {
                    showTopSnackBar(
                      Overlay.of(context),
                      const CustomSnackBar.error(
                        message: 'Ops! Por favor, Informe o seu nome.',
                      ),
                    );
                  } else if (_sobrenome.text == '') {
                    showTopSnackBar(
                      Overlay.of(context),
                      const CustomSnackBar.error(
                        message: 'Ops! Por favor, Informe o seu sobrenome.',
                      ),
                    );
                  } else {
                    Registar();
                  }
                }
                : () {},
        child: Center(
          child:
              btnRg2 == false
                  ? const Text(
                    'Salvar',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.0,
                      fontWeight: FontWeight.normal,
                      fontFamily: 'gotham',
                    ),
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.fade,
                    maxLines: 1,
                  )
                  : const CircularProgressIndicator.adaptive(
                    backgroundColor: Color(0xFFFF0066),
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
        ),
      ),
    );
  }

  Widget _TxtNome() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFEDEEE9)),
      ),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nome",
        theme: FilledOrOutlinedTextTheme(fillColor: Colors.black12, radius: 10),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.person,
          size: 25,
          color: Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _nome,
      ),
    );
  }

  Widget _TxtSobreNome() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFEDEEE9)),
      ),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Apelido",
        theme: FilledOrOutlinedTextTheme(fillColor: Colors.black12, radius: 10),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.person,
          size: 25,
          color: Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _sobrenome,
      ),
    );
  }

  Widget _TxtEmail() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFEDEEE9)),
      ),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "E-mail(Opcional)",
        theme: FilledOrOutlinedTextTheme(fillColor: Colors.black12, radius: 10),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.email, color: Color(0xFF00008B), size: 25),
        validator: FormValidation.requiredTextField,
        controller: _email,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SafeArea(
            child: Column(
              children: [
                SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(height: 50),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(children: [_TxtNome()]),
                          Column(
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.02,
                              ),
                            ],
                          ),
                          Column(children: [_TxtSobreNome()]),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _TxtEmail(),
                      const SizedBox(height: 20),
                      Container(
                        alignment: Alignment.bottomCenter,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [_BtnComecar(), const SizedBox(height: 10)],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Editar Perfil",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (BuildContext context) => InfoPerfilPage(),
                ),
              );
            },
            child: const Text(
              "Editar Outras Info. Pessoais",
              style: TextStyle(
                color: Color(0xFFFF0066),
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
