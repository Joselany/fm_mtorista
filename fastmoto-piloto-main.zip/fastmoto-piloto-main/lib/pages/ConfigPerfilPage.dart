import 'dart:convert';
import 'dart:io';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:image_picker/image_picker.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import 'ConfigPerfilPage2.dart';
import 'Loading.dart';
import 'LoginPage.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'SplashPage.dart';

var senha;
var numeroTel;

class ConfigPerfilPage extends StatefulWidget {
  @override
  _ConfigPerfilPage createState() => _ConfigPerfilPage();
}

class _ConfigPerfilPage extends State<ConfigPerfilPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController _senha = TextEditingController();
  bool _checked = false;
  loading load = loading();

  Future Registar() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/cadastro');
      var response = await http.post(url, body: {
        "telefone": PhoneController.text,
        "email": _email.text,
        "senha": _senha.text,
        "nome": _nome.text,
        "apelido": _sobrenome.text
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["perfil_motorista"];
      final cp = map["chave_publica"];
      final msg = map["msg"];
      idMotorista = dados["id"];
      ChavePublica = cp;
      if (msgr == 1) {
        print(msg);
        numeroTel = PhoneController.text;
        senha = _senha.text;
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        if (file == null) {
          setState(() {
            btnRg2 = false;
          });
          Navigator.of(context).pushReplacement(CupertinoPageRoute(
              builder: (BuildContext context) => ConfigPerfilPage2()));
        } else {
          _UploadFoto();
        }
      } else if (msgr == 0) {
        showTopSnackBar(
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Lamentamos! A conta que deseja criar, já existe.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message: 'Lamentamos! A conta que deseja criar, já existe.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor:
                _checked == false ? Colors.grey : const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: _checked == false
            ? null
            : btnRg2 == false
                ? () {
                    if (file == null) {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message:
                              'Ops! Por favor, Carregue a sua foto de perfil.',
                        ),
                      );
                    } else {
                      if (_nome.text == '') {
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message: 'Ops! Por favor, Informe o seu nome.',
                          ),
                        );
                      } else if (_sobrenome.text == '') {
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message: 'Ops! Por favor, Informe o seu sobrenome.',
                          ),
                        );
                      } else if (PhoneController.text == '') {
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message: 'Ops! Por favor, Informe o seu Telefone.',
                          ),
                        );
                      } else if (_senha.text == '') {
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.error(
                            message:
                                'Ops! Por favor, Informe a sua Palavra-passe.',
                          ),
                        );
                      } else {
                        Registar();
                      }
                    }
                  }
                : () {},
        child: btnRg2 == false
            ? Padding(
                padding: const EdgeInsets.only(top: 8),
                child: const Text(
                  'Continuar',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                  maxLines: 1,
                ))
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _TxtNome() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nome",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.person,
          size: 25,
          color: Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _nome,
      ),
    );
  }

  Widget _TxtSobreNome() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.39,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Apelido",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.person,
          size: 25,
          color: Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _sobrenome,
      ),
    );
  }

  String text = "";
  int maxLength = 9;

  Widget _TxtTelefone() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        onChanged: (String newVal) {
          if (newVal.length <= maxLength) {
            text = newVal;
          } else {
            PhoneController.text = text;
          }
        },
        keyboardType: TextInputType.number,
        labelText: "Telefone",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.phone_android_outlined,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: PhoneController,
      ),
    );
  }

  Widget _TxtSenha() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Palavra-passe",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.lock_outline,
          color: Color(0xFF00008B),
          size: 25,
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _toggleVisibility = !_toggleVisibility;
            });
          },
          icon: _toggleVisibility
              ? const Icon(
                  Icons.visibility_off_outlined,
                  size: 20,
                )
              : const Icon(
                  Icons.visibility_outlined,
                  size: 20,
                ),
          color: const Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _senha,
        obscureText: _toggleVisibility,
      ),
    );
  }

  Widget _TxtEmail() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "E-mail(Opcional)",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.email,
          color: Color(0xFF00008B),
          size: 25,
        ),
        validator: FormValidation.requiredTextField,
        controller: _email,
      ),
    );
  }

  File? file;
  XFile? _image;

  // PickedFile? get image => _image;
  final picker = ImagePicker();

  Future getImageGaleria() async {
    _image = await picker.pickImage(source: ImageSource.gallery);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
    }
  }

  Future<void> getImageCamera() async {
    _image = await picker.pickImage(source: ImageSource.camera);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
    }
  }

  Future _UploadFoto() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/alterarfoto');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("foto", file!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        // ValidarNumero();
        setState(() {
          btnRg2 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => ConfigPerfilPage2()));
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message:
                'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de foto");
      print(e);
    }
  }

  Future ValidarNumero() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/activar/passo1');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'O número de telemóvel informado é inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _btnEntrar() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).pushReplacement(
            CupertinoPageRoute(builder: (BuildContext context) => LoginPage()));
      },
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Já possui conta? ',
              style: TextStyle(
                color: Colors.black,
                fontSize: 12.0,
                fontWeight: FontWeight.normal,
              ),
            ),
            TextSpan(
              text: 'Entrar.',
              style: TextStyle(
                decoration: TextDecoration.underline,
                color: Colors.black,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _TxtTermos() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: CheckboxListTile(
        controlAffinity: ListTileControlAffinity.platform,
        title: const Text(
          'Aceito os Termos e Condições',
          style: TextStyle(
            decoration: TextDecoration.none,
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        value: _checked,
        onChanged: (bool? value) {
          setState(() {
            _checked = value!;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SafeArea(
              child: Column(
            children: [
              SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(
                      height: 30,
                    ),
                    Center(
                      child: CircleAvatar(
                          radius: 50,
                          backgroundImage: file == null
                              ? Image.asset('assets/images/nofoto.png').image
                              : Image.file(File(file!.path)).image),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: const Color(0xFaeb2b5),
                      ),
                      height: 50,
                      width: 40,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                              onPressed: () {
                                Dialogs.bottomMaterialDialog(
                                    msg: 'Carregar foto de perfil',
                                    title: 'Foto de Perfil',
                                    context: context,
                                    actions: [
                                      IconsOutlineButton(
                                        onPressed: () {
                                          getImageCamera();
                                          Navigator.of(context).pop();
                                        },
                                        text: 'Câmera',
                                        iconData: Icons.camera_alt,
                                        color: const Color(0xFFFF0066),
                                        textStyle: const TextStyle(
                                            color: Colors.white),
                                        iconColor: Colors.white,
                                      ),
                                      IconsButton(
                                        onPressed: () {
                                          getImageGaleria();
                                          Navigator.of(context).pop();
                                        },
                                        text: 'Galeria',
                                        iconData: Icons.image,
                                        color: const Color(0xFFFF0066),
                                        textStyle: const TextStyle(
                                            color: Colors.white),
                                        iconColor: Colors.white,
                                      ),
                                    ]);
                              },
                              icon: const Icon(
                                Icons.add_a_photo,
                                size: 30,
                                color: Color(0xFFFF0066),
                              ))
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [_TxtNome()],
                        ),
                        Column(
                          children: [
                            SizedBox(
                                width: MediaQuery.of(context).size.width * 0.02)
                          ],
                        ),
                        Column(
                          children: [_TxtSobreNome()],
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtTelefone(),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtEmail(),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtSenha(),
                    const SizedBox(
                      height: 20,
                    ),
                    _btnEntrar(),
                    const SizedBox(
                      height: 30,
                    ),
                    _TxtTermos(),
                    const SizedBox(
                      height: 20,
                    ),
                    _BtnComecar(),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 50,
              )
            ],
          )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Configurar dados do Perfil",
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
