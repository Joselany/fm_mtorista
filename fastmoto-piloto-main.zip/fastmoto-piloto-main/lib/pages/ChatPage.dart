import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/CardChat.dart';
import 'PrincipalPage.dart';
import 'package:url_launcher/url_launcher.dart';

class ChatPage extends StatefulWidget {
  @override
  _ChatPage createState() => _ChatPage();
}

class _ChatPage extends State<ChatPage> {
  final TextEditingController chatController = TextEditingController();

  var carregado = false;
  var dadosChat;

  Future getChat() async {
    try {
      String baseURL = "$endpoint/corridaapi/chat/ver-msg";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave": ChavePublica.toString(),
        "passageiro": passageiroOn.toString(),
      });
      final map = json.decode(response.body);
      setState(() {
        dadosChat = map["mensagens"];
        carregado = true;
        abrirSMS();
      });
    } catch (e) {
      print(e);
    }
  }

  Future abrirSMS() async {
    try {
      String baseURL = "$endpoint/corridaapi/chat/abrir-msg";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
    } catch (e) {
      print(e);
    }
  }

  Future addChat() async {
    try {
      String baseURL = "$endpoint/corridaapi/chat/enviar-msg";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave_motorista": ChavePublica.toString(),
        "passageiro": passageiroOn.toString(),
        "mensagem": chatController.text,
      });
      final map = json.decode(response.body);
      setState(() {
        getChat();
      });
    } catch (e) {
      print(e);
    }
  }

  Widget _daoChat() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregado
          ? const Text("Carregando...")
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: dadosChat.length,
              itemBuilder: (BuildContext context, int index) {
                return CardChat(
                  mensagem: dadosChat[index]['mensagem'],
                  id: dadosChat[index]['id'].toString(),
                  data: dadosChat[index]['data'],
                  hora: dadosChat[index]['hora'],
                  status: dadosChat[index]['status_motorista'],
                );
              },
            ),
    );
  }

  Future<void> _Call() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: contacto_viajante,
    );
    await launchUrl(launchUri);
  }

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 60,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.zero),
            color: Colors.white),
        child: Row(
          children: [
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width - 50,
                      height: 50,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TxtChat(),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  width: 50,
                  height: 50,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _BtnChat(),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget TxtChat() {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 50,
      child: MaterialTextField(
        hint: 'Escrever mensagem',
        keyboardType: TextInputType.text,
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.white,
          radius: 0,
        ),
        style: const TextStyle(
          color: Colors.black,
          fontSize: 18,
          fontFamily: 'Gotham',
        ),
        controller: chatController,
      ),
    );
  }

  Widget _BtnCall() {
    return SizedBox(
      width: 40,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _Call();
        },
        child: const Icon(
          Icons.call,
          color: Color(0xFFFF0066),
          size: 30,
        ),
      ),
    );
  }

  Widget _BtnClose() {
    return SizedBox(
      width: 40,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pop();
        },
        child: const Icon(
          Icons.cancel,
          color: Color(0xFFFF0066),
          size: 30,
        ),
      ),
    );
  }

  Widget _BtnChat() {
    return SizedBox(
      width: 45,
      height: 45,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0),
            )),
        onPressed: () {
          setState(() {
            addChat();
            getChat();
          });
          chatController.text = "";
        },
        child: const Icon(
          Icons.send_outlined,
          color: Color(0xFF00008B),
          size: 30,
        ),
      ),
    );
  }

  @override
  void initState() {
    getChat();
    abrirSMS();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        body: Stack(
          children: [
            // Add listview
            SafeArea(
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                    padding: const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(0),
                            color: Colors.white,
                          ),
                          width: MediaQuery.of(context).size.width,
                          height: 65,
                          child: Column(
                            children: [
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 50,
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircleAvatar(
                                        radius: 25,
                                        backgroundColor: Colors.grey,
                                        child: foto_viajante == null
                                            ? CircleAvatar(
                                                radius: 22,
                                                backgroundImage: Image.asset(
                                                        'assets/images/nofoto.png')
                                                    .image,
                                              )
                                            : CircleAvatar(
                                                radius: 22,
                                                backgroundImage: Image.network(
                                                        pathURL + foto_viajante)
                                                    .image,
                                              ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 5,
                                      )
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        '$viajante',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topRight,
                child: Padding(
                    padding:
                        const EdgeInsets.only(right: 5, bottom: 0, top: 20),
                    child: Column(
                      children: [
                        _BtnCall(),
                      ],
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topLeft,
                child: Padding(
                    padding:
                        const EdgeInsets.only(right: 0, bottom: 0, top: 20),
                    child: Column(
                      children: [
                        _BtnClose(),
                      ],
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                    padding:
                        const EdgeInsets.only(right: 0, bottom: 0, top: 70),
                    child: Container(
                      color: Colors.black54,
                      height: 2,
                      width: MediaQuery.of(context).size.width,
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                    padding: const EdgeInsets.only(right: 0, bottom: 50),
                    child: Container(
                      color: Colors.black54,
                      height: 2,
                      width: MediaQuery.of(context).size.width,
                    )),
              ),
            ),
            Container(
              alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _daoChat(),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: [
                  Row(
                    children: [
                      InfoBar(),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
