import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:draggable_bottom_sheet_nullsafety/draggable_bottom_sheet_nullsafety.dart';
import 'package:fastmoto_piloto/pages/InfoViaturaPage.dart';
import 'package:fastmoto_piloto/services/sse.dart';
// import 'package:fastmoto_piloto/pages/foregroundService.dart' show ForegroundTaskService;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location_permissions/location_permissions.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:share_plus/share_plus.dart';
import '../main.dart';
import 'Back_Services.dart';
import 'CarregarPerfilPage.dart';
import 'CarteiraPage.dart';
import 'ChamadaPage.dart';
import 'DocumentosPage.dart';
import 'ForegroundTaskService.dart' as foregroundTaskService;
import 'GanhosPage.dart';
import 'InfoPerfilPage.dart';
import 'PerfilPage.dart';
import 'Loading.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:vibration/vibration.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'ViagensPage.dart';

var sessao_usuario;
var idMotorista;
var idMotoristaInteiro;
var ChavePublica;
var nomeMotorista;
var sobrenomeMotorista;
var fotoPerfil;
var emailMotorista;
var telefoneMotorista;
var provincia_motorista;
var categoria_motorista;
var endereco;
var marca_viatura;
var modelo_viatura;
var matricula;
var cor;
var livrete;
var titulo_propriedade;
var validade_carta_conducao;
var validade_bi;
var bi;
var cidade;
var carta_conducao;
var origem_viajante;
double avaliacao_passageiro = 0.0;
var destino_viajante;
var origem1;
var destino1;
var metodo_pagamento;
var viajante;
var passageiroOn;
var contacto_viajante;
var foto_viajante;
var numeropedido;
var nNotificacao;
var Totalpedido;
bool status_chamada = false;
bool status_viagem = false;
bool status_service_back = false;
bool call = false;
var status_pedido;
var ganhoDia;
double SaldoConta = 0.0;
double avaliacao_motorista = 0.0;
int status_activacao = 0;
double rating = 0.0;

class PrincipalPage extends StatefulWidget {
  @override
  _PrincipalPage createState() => _PrincipalPage();
}

class _PrincipalPage extends State<PrincipalPage> with WidgetsBindingObserver {
  ReceivePort port = ReceivePort();
  String logStr = '';
  late bool isRunning;

  String textEvents = "";

  bool con = false;
  loading load = loading();

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    // print(con);
  }

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  final TextEditingController locationController = TextEditingController();
  final TextEditingController servicoController = TextEditingController();

  bool carregar = false;

  final CameraPosition _initialLocation = const CameraPosition(
    target: LatLng(-8.56148317153996, 13.593409574676945),
    zoom: 0,
  );
  late GoogleMapController mapController;

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(
      locationSettings: LocationSettings(accuracy: LocationAccuracy.best),
    ).then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 13.5,
          ),
        ),
      );
      setState(() {
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
        posicaomotorista = "$posicaoV1,$posicaoV2";
      });
    }).catchError((e) {
      print(e);
    });
  }

  void addCustomIcon() {
    BitmapDescriptor.asset(
      const ImageConfiguration(),
      "assets/images/moto_gps.png",
    ).then((icon) {
      setState(() {
        markerIcon = icon;
      });
    });
  }

  Future ConsultarSaldo() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/saldo');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      setState(() {
        SaldoConta = double.parse(map['saldo']);
      });
      if (SaldoConta <= 100) {
        AlertaCarteira2();
      } else if (SaldoConta <= 1000) {
        AlertaCarteira1();
      } else {}
    } catch (e) {
      print(e);
    }
  }

  AlertaCarteira1() {
    Dialogs.bottomMaterialDialog(
      msg:
          'Saldo baixo, solicite um carregamento e evite ficar sem receber chamadas.',
      title: 'Carregar Saldo',
      context: context,
      actions: [
        IconsOutlineButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          text: 'Carregar depois',
          iconData: Icons.access_time,
          color: const Color(0xFFFF0066),
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
        IconsButton(
          onPressed: () async {
            Navigator.of(context).pushReplacement(
              CupertinoPageRoute(
                builder: (BuildContext context) => CarteiraPage(),
              ),
            );
          },
          text: 'Carregar agora',
          iconData: CupertinoIcons.add_circled,
          color: Colors.green,
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
      ],
    );
  }

  AlertaCarteira2() {
    Dialogs.bottomMaterialDialog(
      msg:
          'Saldo insuficiente, solicite agora um carregamento para continuar a receber chamadas.',
      title: 'Carregar Saldo',
      context: context,
      actions: [
        IconsOutlineButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          text: 'Carregar depois',
          iconData: Icons.access_time,
          color: const Color(0xFFFF0066),
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
        IconsButton(
          onPressed: () async {
            Navigator.of(context).pushReplacement(
              CupertinoPageRoute(
                builder: (BuildContext context) => CarteiraPage(),
              ),
            );
          },
          text: 'Carregar agora',
          iconData: CupertinoIcons.add_circled,
          color: Colors.green,
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
      ],
    );
  }

  void pesquisarCorrida() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/chamada/ver');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      Totalpedido = map["total"];
      var verificacao = map["notificacoes_motorista"];
      nNotificacao = verificacao[0]['id'];
      numeropedido = verificacao[0]['pedido'];
      var dataNotificacao = verificacao[0]['data'];
      DateTime hora1 = DateTime.parse(dataNotificacao);
      DateTime horaActual = DateTime.now();
      // ignore: non_constant_identifier_names
      int daysBetween_wrong1(DateTime date1, DateTime date2) {
        return date1.difference(date2).inSeconds;
      }

      print(">>>>>>>>>>>>>>>>>> Totalpedido $Totalpedido");

      int tempoNotificacao = daysBetween_wrong1(horaActual, hora1);
      PegarTarifa();
      if (mounted && Totalpedido > 0 &&
          status_chamada == false &&
          tempoNotificacao < 3630) {
        Vibration.vibrate(duration: 5000);
        PegarTarifa();
        DadosViagem();
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => ChamadaPage()));
      } else {}
    } catch (e) {
      print(e);
    }
  }

  void _GanhosDia() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/ganhos-diarios');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      ganhoDia = map['ganhos'];
    } catch (e) {
      print(e);
    }
  }

  Future DadosViagem() async {
    try {
      String baseURL = "$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=motorista';
      var response = await http.post(
        Uri.parse(request),
        body: {
          "motorista": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "pedido": numeropedido.toString(),
        },
      );
      final map = json.decode(response.body);
      final dadosPedido = map["pedido"];
      final dadosPassageiro = map["passageiro"];
      if (mounted) {
        setState(() {
          origem_viajante = dadosPedido['origem'];
          avaliacao_passageiro = double.tryParse(map['avaliacao'].toString()) ?? 0.0;
          destino_viajante = dadosPedido['destino'];
          origem1 = dadosPedido['desc_origem'];
          destino1 = dadosPedido['desc_destino'];
          metodo_pagamento = dadosPedido['metodo_pagamento'];
          viajante = dadosPassageiro['nome'];
          passageiroOn = dadosPassageiro['id'];
          contacto_viajante = dadosPedido['contacto'];
          foto_viajante = dadosPassageiro['foto'];
          status_pedido = dadosPedido['status'];
        });
      }
      CalculaViagem();
    } catch (e) {
      print(e);
    }
  }

  void ActualizarPerfil() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/app/atualizar');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      final dadosPerfil = map["perfil_motorista"];
      // print(dadosPerfil);
    } catch (e) {
      print(e);
    }
  }

  CalculaViagem() {
    setState(() {
      lat1 = double.tryParse(origem_viajante.toString().split(',')[0]);
      long1 = double.tryParse(origem_viajante.toString().split(',')[1]);
      lat2 = double.tryParse(destino_viajante.toString().split(',')[0]);
      long2 = double.tryParse(destino_viajante.toString().split(',')[1]);
      distance_rota = Geolocator.distanceBetween(lat1!, long1!, lat2!, long2!);
      calc_distancia_viagem = distance_rota / 1000;

      if (calc_distancia_viagem <= inicio_cobranca) {
        valorViagem = tarifa_base;
      } else {
        double distanciaContagem = calc_distancia_viagem - inicio_cobranca;
        valorViagem = (taxakm * distanciaContagem.round()) + tarifa_base;
      }
    });
  }

  void PegarTarifa() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/tarifa');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      final tarifa = map["tarifa"];
      tarifa_base = double.tryParse(tarifa[0]['tarifa_base']) ?? 0.0;
      taxakm = double.tryParse(tarifa[0]['tarifa_km']) ?? 0.0;
      inicio_cobranca = int.tryParse(tarifa[0]['inicio_cobranca']) ?? 0;
    } catch (e) {
      print(e);
    }
  }

  Widget _BtnGPS() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: const Color(0xFFEDEEE9),
          elevation: 10,
          padding: const EdgeInsets.all(0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(100),
          ),
        ),
        onPressed: () {
          getCurrentLocation();
        },
        child: const Icon(Icons.gps_fixed, color: Color(0xFFFF0066), size: 30),
      ),
    );
  }

  Widget _BtnPermissao() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: const Color(0xFFEDEEE9),
          elevation: 10,
          padding: const EdgeInsets.all(0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(100),
          ),
        ),
        onPressed: () async {
          Geolocator.isLocationServiceEnabled();
          final location = await LocationPermissions().checkPermissionStatus();
          if (location == PermissionStatus.granted) {
            Dialogs.bottomMaterialDialog(
              msg: 'Activada a localização em todo tempo',
              title: 'Permissão de Localização',
              context: context,
              actions: [
                IconsOutlineButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  text: 'Não Alterar',
                  iconData: Icons.cancel,
                  color: const Color(0xFFFF0066),
                  textStyle: const TextStyle(color: Colors.white),
                  iconColor: Colors.white,
                ),
                IconsButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    Geolocator.openLocationSettings();
                  },
                  text: 'Alterar definição',
                  iconData: CupertinoIcons.settings,
                  color: const Color(0xFF00008B),
                  textStyle: const TextStyle(color: Colors.white),
                  iconColor: Colors.white,
                ),
              ],
            );
          } else {
            Dialogs.bottomMaterialDialog(
              msg: 'Activada a localização apenas enquanto usa o app.',
              title: 'Permissão de Localização',
              context: context,
              actions: [
                IconsOutlineButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  text: 'Não Alterar',
                  iconData: Icons.cancel,
                  color: const Color(0xFFFF0066),
                  textStyle: const TextStyle(color: Colors.white),
                  iconColor: Colors.white,
                ),
                IconsButton(
                  onPressed: () async {
                    Navigator.of(context).pushReplacement(
                      CupertinoPageRoute(
                        builder: (BuildContext context) => PrincipalPage(),
                      ),
                    );
                    Geolocator.openLocationSettings();
                  },
                  text: 'Alterar definição',
                  iconData: CupertinoIcons.settings,
                  color: const Color(0xFF00008B),
                  textStyle: const TextStyle(color: Colors.white),
                  iconColor: Colors.white,
                ),
              ],
            );
          }
        },
        child: const Icon(
          Icons.location_on_sharp,
          color: Color(0xFFFF0066),
          size: 30,
        ),
      ),
    );
  }

  Future ActivarServico(String value) async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/actualizar/perfil');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
          "status_servico": value,
        },
      );
      final map = json.decode(response.body);
      int msgr = map["retorno"];
      if (msgr == 1) {
        if (value == "1") {
          startService();
          _clockTimer = Timer.periodic(const Duration(seconds: 3), (Timer t) {
            if (status_service == true) {
              conexao();
            } else {
              // _clockTimer.cancel();
            }
          });
        } else {
          contador = 0;
          contador2 = 0;
          stopService();
          setState(() {
            status_service = false;
            status_service_back = false;
          });
          await SessionManager().set("status_service", false);
          MeuServico().ActualizaLocalizacao();
          // _clockTimer.cancel();
        }
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Não foi possível activar o servico.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print(e);
    }
  }

  Future CarregarDados() async {
    print("== TEste==");
    try {
      var url = Uri.parse('$endpoint/motoristaapi/dados');
      var response = await http.post(
        url,
        body: {
          "id": idMotorista.toString(),
          "chave_publica": ChavePublica.toString(),
        },
      );
      final map = json.decode(response.body);
      final perfil = map["perfil_motorista"];
      final info = map["info_motorista"];
      final docs = map["docs_motorista"];
      rating = double.parse(map['avaliacao']);
      avaliacao_motorista = double.parse(map['avaliacao']);
      status_activacao = perfil['status_cadastro'];
      nomeMotorista = perfil['nome'];
      sobrenomeMotorista = perfil['apelido'];
      fotoPerfil = urlImagem + perfil['foto'];
      categoria_motorista = info['categoria'];
      telefoneMotorista = perfil['telefone'];
      emailMotorista = perfil['email'];
      fotoLivrete = docs['livrete'];
      fotoCarta = docs['carta_conducao'];
      fotoBI = docs['bi'];
      fotoTitulo = docs['titulo_propriedade'];
      fotoRC = docs['registo_criminal'];
      provincia_motorista = info['provincia'];
      endereco = info['endereco'];
      marca_viatura = info['marca_viatura'];
      modelo_viatura = info['modelo_viatura'];
      matricula = info['matricula'];
      cor = info['cor'];
      livrete = info['livrete'];
      titulo_propriedade = info['titulo_propriedade'];
      validade_carta_conducao = info['validade_carta_conducao'];
      validade_bi = info['validade_bi'];
      cidade = info['cidade'];
      bi = info['bi'];
      carta_conducao = info['carta_conducao'];
      carregar = true;
      // validacao de dados
      if (bi == null ||
          carta_conducao == null ||
          cidade == null ||
          endereco == null ||
          provincia_motorista == null ||
          validade_bi == null ||
          validade_carta_conducao == null) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
                'Conclua com o preencimento dos seus dados, para facilitar o processo de aprovação da sua conta.',
          ),
        );
        Navigator.of(context).push(
          CupertinoPageRoute(
            builder: (BuildContext context) => InfoPerfilPage(),
          ),
        );
      } else if (marca_viatura == null ||
          modelo_viatura == null ||
          matricula == null ||
          cor == null ||
          livrete == null ||
          categoria_motorista == null) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
                'Conclua com o preencimento dos dados da sua Motorizada, para facilitar o processo de aprovação da sua conta.',
          ),
        );
        Navigator.of(context).push(
          CupertinoPageRoute(
            builder: (BuildContext context) => InfoViaturaPage(),
          ),
        );
      } else if (status_activacao == 0) {
        showTopSnackBar(
            // ignore: use_build_context_synchronously
            Overlay.of(context),
            const CustomSnackBar.error(
              message: 'Aprovação de conta pendente.',
            ));
      } else {}
      await SessionManager().set("categoria_motorista", categoria_motorista);
    } catch (e) {
      print(e);
    }
  }

  Future<void> share() async {
    await Share.share(
      'Oferece aos mototaxistas uma maneira fácil de receber novas corridas, '
      'gerir o fluxo de trabalho e maximizar ganhos. \n '
      'Baixe gratuitamente.\n'
      'www.fastmoto.com',
      subject: 'FastMoto Motoqueiro',
    );
  }

  void ActivarSessao() async {
    status_pedido = 0;
    locked = false;
    status_chamada = false;
    call = false;
    caller = false;
    sessao_usuario = 1;
    valorViagem = 0.0;
    calc_distancia_viagem = 0;
    await SessionManager().set("btnIniciar", false);
    await SessionManager().set("btnPausar", false);
    await SessionManager().set("btnPegar", false);
    await SessionManager().set("btnRetomar", false);
    await SessionManager().set("btnConcluir", false);
    await SessionManager().set("sessao_usuario", 1);
    await SessionManager().set("call", false);
    await SessionManager().set("status_chamada", false);
  }

  AlertarServicos() {
    Dialogs.bottomMaterialDialog(
      msg:
          'Ao clicar em aceitar vai permitir que o sistema recolha as suas informações de localização mesmo quando o aplicativo estiver em segundo plano.',
      title: 'Serviço de Localização',
      context: context,
      actions: [
        IconsOutlineButton(
          onPressed: () async {
            Navigator.of(context).pop();
            setState(() {
              status_service = false;
            });
            await SessionManager().set("status_service", false);
            showTopSnackBar(
              // ignore: use_build_context_synchronously
              Overlay.of(context),
              const CustomSnackBar.info(
                message: 'Activação do serviço de localização cancelada.',
              ),
            );
            Navigator.of(context).pushReplacement(
              CupertinoPageRoute(
                builder: (BuildContext context) => PrincipalPage(),
              ),
            );
          },
          text: 'Cancelar',
          iconData: Icons.cancel_outlined,
          color: Colors.red,
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
        IconsButton(
          onPressed: () async {
            final location =
                await LocationPermissions().checkPermissionStatus();
            if (location == PermissionStatus.granted) {
              Navigator.of(context).pop();
              ActivarServico("1");
              setState(() {
                status_service = true;
                status_service_back = true;
              });
              await SessionManager().set("status_service", true);
            } else {
              Dialogs.bottomMaterialDialog(
                msg:
                    'Para continuar precisa habilitar a localização em todo tempo.',
                title: 'Permissão de Localização',
                context: context,
                actions: [
                  IconsOutlineButton(
                    onPressed: () async {
                      setState(() {
                        status_service = false;
                      });
                      await SessionManager().set("status_service", false);
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.info(
                          message:
                              'Activação do serviço de localização cancelada.',
                        ),
                      );
                      Navigator.of(context).pushReplacement(
                        CupertinoPageRoute(
                          builder: (BuildContext context) => PrincipalPage(),
                        ),
                      );
                    },
                    text: 'Cancelar',
                    iconData: Icons.cancel,
                    color: const Color(0xFFFF0066),
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                  IconsButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      Geolocator.openLocationSettings();
                    },
                    text: 'Activar',
                    iconData: CupertinoIcons.settings,
                    color: const Color(0xFF00008B),
                    textStyle: const TextStyle(color: Colors.white),
                    iconColor: Colors.white,
                  ),
                ],
              );
            }
          },
          text: 'Aceitar',
          iconData: Icons.done,
          color: Colors.green,
          textStyle: const TextStyle(color: Colors.white),
          iconColor: Colors.white,
        ),
      ],
    );
  }

  Future<void> _requestPermissions() async {
    final NotificationPermission notificationPermission =
        await FlutterForegroundTask.checkNotificationPermission();
    if (notificationPermission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (Platform.isAndroid) {
      if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }
      if (!await FlutterForegroundTask.canScheduleExactAlarms) {
        await FlutterForegroundTask.openAlarmsAndRemindersSettings();
      }
    }
  }

  void startService() async {
    if (await FlutterForegroundTask.isRunningService) {
      FlutterForegroundTask.restartService();
    } else {
      FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'Serviço Ligado',
        notificationText: 'Toque para retornar ao app',
        callback: foregroundTaskService.startCallback,
      );
    }
  }

  void stopService() {
    FlutterForegroundTask.stopService();
  }

  ReceivePort? receivePort;
  late Timer _clockTimer;

  @override
  void initState() {
    ActivarSessao();
    MeuServico().requestPermissionsNotification();
    _requestPermissions();
    getCurrentLocation();
    CarregarDados();
    setState(() {
      status_atendimento = 0;
    });
    _GanhosDia();
    ConsultarSaldo();
    addCustomIcon();

    if (status_service == true) {
      _clockTimer = Timer.periodic(const Duration(seconds: 3), (Timer t) {
        pesquisarCorrida();
      });
    } else {}
    super.initState();
  }

  @override
  void dispose() {
    _clockTimer.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    setState(() async {
      if (state != AppLifecycleState.resumed) {
        locked = true;
        await SessionManager().set("locked", true);
      } else {
        locked = false;
        await SessionManager().set("locked", false);
      }
    });
  }

  Widget _nomePerfil() {
    return GestureDetector(
      onTap: () {},
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: nomeMotorista.toUpperCase().toString(),
              style: const TextStyle(
                color: Color(0xFFEDEEE9),
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _btnPerfil() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          CupertinoPageRoute(builder: (BuildContext context) => PerfilPage()),
        );
      },
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Ver Perfil',
              style: TextStyle(
                decoration: TextDecoration.underline,
                color: Color(0xFF00008B),
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        body: Stack(
          children: [
            DraggableBottomSheet(
              backgroundWidget: GoogleMap(
                markers: {
                  Marker(
                    markerId: const MarkerId("MinhaPosicao"),
                    position: LatLng(posicaoV1, posicaoV2),
                    draggable: true,
                    icon: markerIcon,
                  ),
                },
                mapType: MapType.normal,
                initialCameraPosition: _initialLocation,
                myLocationEnabled: false,
                myLocationButtonEnabled: false,
                zoomGesturesEnabled: true,
                zoomControlsEnabled: false,
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                },
              ),
              previewChild: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF00008B), Color(0xFF00008B)],
                  ),
                  //color: Color(0xFF00008B),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    Container(
                      width: 40,
                      height: 6,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFFFF0066), Color(0xFFFF0066)],
                        ),
                        // color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.only(top: 0),
                      child: LiteRollingSwitch(
                        value: status_service ?? false,
                        textOn: 'LIGADO',
                        textOff: 'DESLIGADO',
                        textOffColor: Colors.white,
                        textOnColor: Colors.white,
                        colorOn: const Color(0xFFFF0066),
                        colorOff: const Color(0xFFFF0066),
                        iconOn: Icons.done_outline,
                        iconOff: Icons.remove_circle_outline_outlined,
                        textSize: 16.0,
                        width: MediaQuery.of(context).size.width * 0.8,
                        onChanged: (bool state) async {
                          if (state == true) {
                            AlertarServicos();
                          } else {
                            ActivarServico("0");
                          }
                        },
                        onTap: () {},
                        onDoubleTap: () {},
                        onSwipe: () {},
                      ),
                    ),
                    const Divider(height: 0, color: Colors.black12),
                  ],
                ),
              ),
              expandedChild: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    const Icon(
                      Icons.keyboard_arrow_down,
                      size: 30,
                      color: Color(0xFFFF0066),
                    ),
                    const SizedBox(height: 8),
                    const Center(
                      child: Text(
                        "Ganhos do dia",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    const Divider(height: 30, color: Colors.black12),
                    Center(
                      child: ListTile(
                        leading: const Icon(
                          Icons.attach_money_outlined,
                          size: 30,
                          color: Color(0xFFFF0066),
                        ),
                        dense: true,
                        title: ganhoDia == null
                            ? const Text(
                                "0.00 KZ",
                                style: TextStyle(
                                  color: Color(0xFFFF0066),
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              )
                            : Text(
                                NumberFormat.currency(
                                  locale: 'eu',
                                  symbol: 'KZ',
                                ).format(ganhoDia).toString(),
                                style: const TextStyle(
                                  color: Color(0xFFFF0066),
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Center(
                      child: Text(
                        "Saldo Disponível",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    const Divider(height: 20, color: Colors.black12),
                    Center(
                      child: ListTile(
                        onTap: () {
                          Navigator.of(context).push(
                            CupertinoPageRoute(
                              builder: (BuildContext context) => CarteiraPage(),
                            ),
                          );
                        },
                        leading: const Icon(
                          Icons.attach_money_outlined,
                          size: 20,
                          color: Color(0xFFFF0066),
                        ),
                        trailing: const Icon(
                          Icons.navigate_next_outlined,
                          size: 20,
                          color: Color(0xFFFF0066),
                        ),
                        dense: true,
                        title: SaldoConta == null
                            ? const Text(
                                "0.00 KZ",
                                style: TextStyle(
                                  color: Color(0xFFFF0066),
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              )
                            : Text(
                                NumberFormat.currency(
                                  locale: 'eu',
                                  symbol: 'KZ',
                                ).format(SaldoConta).toString(),
                                style: const TextStyle(
                                  color: Color(0xFFFF0066),
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Center(
                      child: Text(
                        "Classificação",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    const Divider(height: 30, color: Colors.black12),
                    Center(
                      child: SmoothStarRating(
                        rating:
                            carregarDados == false ? 0.0 : avaliacao_motorista,
                        size: 60,
                        filledIconData: Icons.star,
                        halfFilledIconData: Icons.star_half,
                        defaultIconData: Icons.star_border,
                        color: const Color(0xFFFF0066),
                        borderColor: Colors.black54,
                        starCount: 5,
                        allowHalfRating: false,
                        spacing: 2.0,
                      ),
                    ),
                  ],
                ),
              ),
              minExtent: 100,
              expansionExtent: 300,
              maxExtent: 800,
            ),
            SafeArea(
              child: Padding(
                padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.8,
                  top: MediaQuery.of(context).size.height * 0.53,
                  right: 10,
                ),
                child: Column(children: [_BtnPermissao()]),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.8,
                  top: MediaQuery.of(context).size.height * 0.63,
                  right: 10,
                ),
                child: Column(children: [_BtnGPS()]),
              ),
            ),
          ],
        ),
        appBar: AppBar(
          actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
          backgroundColor: Platform.isAndroid ? Colors.transparent : null,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
          actions: status_service_back == false
              ? const [
                  Icon(Icons.portable_wifi_off, color: Colors.red, size: 40),
                ]
              : const [Icon(Icons.wifi, color: Colors.green, size: 40)],
        ),
        drawer: Drawer(
          child: ListView(
            children: [
              Container(
                color: const Color(0xFFFF0066),
                height: 150,
                width: MediaQuery.of(context).size.width / 1.5,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [Container(width: 30)],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ClipOval(
                              child: CachedNetworkImage(
                                fit: BoxFit.cover,
                                imageUrl: fotoPerfil,
                                width: 100,
                                height: 100,
                                placeholder: (context, url) =>
                                    const CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                                errorWidget: (context, url, error) =>
                                    const Icon(
                                  Icons.image_not_supported,
                                  size: 45,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [Container(width: 5)],
                        ),
                        Column(
                          children: [
                            _nomePerfil(),
                            const SizedBox(height: 10),
                            _btnPerfil(),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(height: 5, color: Colors.black12),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (BuildContext context) => InfoViaturaPage(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.settings,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Configuração",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
                subtitle: const Text(
                  "Dados da Motorizada",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 12.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (BuildContext context) => DocumentosPage(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.document_scanner,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Documentos",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
                subtitle: const Text(
                  "Carregar Documentação",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 12.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (BuildContext context) => CarteiraPage(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.account_balance_wallet,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Carteira",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
                subtitle: const Text(
                  "Consultar Créditos",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 12.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (BuildContext context) => GanhosPage(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.monetization_on_sharp,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Pagamentos",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
                subtitle: const Text(
                  "Consultar Pagamentos",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 12.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (BuildContext context) => ViagensPage(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.access_time_outlined,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Minhas Viagens",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
                subtitle: const Text(
                  "Consultar Viagens",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 12.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  share();
                },
                leading: const Icon(
                  Icons.share_outlined,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Convide Amigos",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
              const Divider(height: 30, color: Colors.black12),
              ListTile(
                onTap: () {
                  Dialogs.materialDialog(
                    color: Colors.white,
                    msg: 'FastMoto.\n\n'
                        'É a plataforma que transforma a corrida de motorizada em uma experiência de mobilidade segura.\n\nVersão: $versionApp',
                    title: 'Sobre o App',
                    context: context,
                    actions: [
                      IconsButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        text: 'OK',
                        iconData: Icons.done,
                        color: const Color(0xFFFF0066),
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                    ],
                  );
                },
                leading: const Icon(
                  Icons.info_outline,
                  size: 30,
                  color: Color(0xFF00008B),
                ),
                title: const Text(
                  "Sobre o App",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.normal,
                    fontFamily: 'gotham',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
