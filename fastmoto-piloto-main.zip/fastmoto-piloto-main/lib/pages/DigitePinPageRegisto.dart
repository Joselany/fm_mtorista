import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_text_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/style.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import '../config/Constats.dart';
import 'ConfigPerfilPage.dart';
import 'Loading.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'PrincipalPage.dart';

class DigitePinPageRegisto extends StatefulWidget {
  @override
  _DigitePinPageRegisto createState() => _DigitePinPageRegisto();
}

class _DigitePinPageRegisto extends State<DigitePinPageRegisto> {
  final TextEditingController OtpController = TextEditingController();
  loading load = loading();
  var otp;

  @override
  void initState() {
    super.initState();
  }

  void GerarSessao(String id, chave, idMotoristaInteiro) async {
    await SessionManager().set("idMotorista", id);
    await SessionManager().set("ChavePublica", chave);
    await SessionManager().set("idMotoristaInteiro", idMotoristaInteiro);
  }

  Future ValidarCodigo() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo2');
      var response = await http.post(url, body: {
        "telefone": numeroTel,
        "codigo": otp,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        Validarlogin();
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Código validado com sucesso.',
          ),
        );
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Código inválido. Digite novamente',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Future Validarlogin() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/login');
      var response = await http.post(url, body: {
        "usuario": numeroTel,
        "senha": '12345',
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["perfil_passageiro"];
      final cp = map['chave_publica'];
      print(map);
      if (msgr == 1) {
        idMotorista = dados['id'];
        idMotoristaInteiro = dados['int_id'];
        ChavePublica = cp;
        GerarSessao(idMotorista, ChavePublica, idMotoristaInteiro);
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Login inválido',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Future ValidarNumero() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/reset/passo1');
      var response = await http.post(url, body: {
        "telefone": numeroTel,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Número inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.black54,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () async {
          if (otp == "") {
            showTopSnackBar(
              Overlay.of(context),
              const CustomSnackBar.error(
                message: 'Por favor, Preencher o Código OTP.',
              ),
            );
          } else {
            await showDialog(
              context: context,
              builder: (context) => FutureProgressDialog(load.getFuture()),
            );
            ValidarCodigo();
          }
        },
        child: const Text(
          'Continuar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  Widget _BtnEnviar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
        ),
        onPressed: () async {
          setState(() {
            otp = null;
          });
          await showDialog(
            context: context,
            builder: (context) => FutureProgressDialog(load.getFuture()),
          );
          ValidarNumero;
        },
        child: const Text(
          'Reenviar código',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 14.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  Widget _TxtOPT() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 70,
      child: OTPTextField(
        length: 5,
        spaceBetween: 4,
        width: MediaQuery.of(context).size.width,
        fieldWidth: 40,
        style: const TextStyle(
            fontFamily: 'Gotham', fontWeight: FontWeight.bold, fontSize: 30),
        textFieldAlignment: MainAxisAlignment.start,
        fieldStyle: FieldStyle.underline,
        onCompleted: (pin) {
          otp = pin;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 200,
            ),
            const Center(
              child: Image(
                image: AssetImage("assets/images/logo_vermelho.png"),
                width: 75,
                height: 75,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const Text(
              'Digite o seu código de verificação',
              style: TextStyle(
                color: Colors.black87,
                letterSpacing: 0,
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 2,
            ),
            Align(
              alignment: Alignment.center,
              child: Text(
                'O seu código foi enviado para o número: $numeroTel',
                style: const TextStyle(
                  color: Colors.black87,
                  letterSpacing: 0,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            _TxtOPT(),
            const SizedBox(
              height: 10,
            ),
            _BtnComecar(),
            const SizedBox(
              height: 10,
            ),
            _BtnEnviar(),
            const SizedBox(
              height: 2,
            ),
          ],
        ));
  }
}
