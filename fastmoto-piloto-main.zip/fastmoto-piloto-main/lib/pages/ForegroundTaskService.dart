import 'dart:async';
import 'dart:convert';
import 'dart:isolate';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import '../config/Constats.dart';
import 'Back_Services.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(FirstTaskHandler());
}

class FirstTaskHandler extends TaskHandler {
  SendPort? _sendPort;
  String? _ultimoIdPedido;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    _sendPort?.send("startTask");

    var androidInitialize = const AndroidInitializationSettings('mipmap/ic_launcher');
    var iOSInitialize = const DarwinInitializationSettings();
    var initializationSettings =
        InitializationSettings(android: androidInitialize, iOS: iOSInitialize);
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  static void showNotification(int id, String title, String body) async {
    var androidDetails = const AndroidNotificationDetails(
      'pedido_channel',
      'Pedidos',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
    );

    var iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    var notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      notificationDetails,
    );
  }

  void _verificarPedido() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/chamada/ver');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      int Totaldepedidos = map["total"];
      var verificacao = map["notificacoes_motorista"];
      var dataNotificacao = verificacao[0]['data'];
      var status = verificacao[0]['status'];

      DateTime hora1 = DateTime.parse(dataNotificacao);
      DateTime horaActual = DateTime.now();
      int tempodeNotificacao = horaActual.difference(hora1).inSeconds;
      
      if (Totaldepedidos > 0 && status == 1 && tempodeNotificacao >= 0) {
        showNotification(1, "Novo Pedido", "Você tem um novo pedido!");

        FlutterForegroundTask.launchApp();
        _sendPort?.send('novo_pedido');
      }
    } catch (e) {
    }
  }

  @override
  void onRepeatEvent(DateTime timestamp) async {
    idMotorista = await SessionManager().get("idMotorista");
    ChavePublica = await SessionManager().get("ChavePublica");
    idMotoristaInteiro = await SessionManager().get("idMotoristaInteiro");
    _verificarPedido();
    MeuServico().ActivarServico();
    MeuServico().getPosicaoActual();
    MeuServico().ActualizaLocalizacao();
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    print('onDestroy $timestamp');
  }

  @override
  void onNotificationButtonPressed(String id) {
    print('onDestroy $id');
  }

  @override
  void onNotificationPressed() {
    _sendPort?.send('onNotificationPressed');
  }
}
