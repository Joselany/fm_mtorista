import 'dart:async';
import 'dart:convert';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:count_up_flutter/count_up_flutter.dart';
import 'package:fastmoto_piloto/pages/DriverPage.dart';
import 'package:fastmoto_piloto/pages/PrincipalPage.dart';
import 'package:fastmoto_piloto/pages/SplashPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:flutter_session_manager/flutter_session_manager.dart';
// ignore: depend_on_referenced_packages
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:vibration/vibration.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:intl/intl.dart';
import '../main.dart';
import 'Back_Services.dart';
import 'Loading.dart';
import 'package:get/get.dart';
import 'ForegroundTaskService.dart' as foregroundTaskService;

double? lat1;
double? long1;
double? lat2;
double? long2;
int taxaParagem = 0;
double limiteParagem = 0.0;
double tarifa_base = 0.0;
double taxakm = 0.0;
double valorParagem = 0.0;
double tdesc = 0.0;
double valorViagem = 0.0;
double distance_rota = 0.0;
double distancia_viatura = 0.0;
double calc_distancia_viagem = 0.0;
double desconto = 0.0;
int inicio_cobranca = 0;
int tempo = 0;
int status_atendimento = 0;

int tempoPedido = 0;

class ChamadaPage extends StatefulWidget {
  @override
  _ChamadaPage createState() => _ChamadaPage();
}

class _ChamadaPage extends State<ChamadaPage> {
  bool callAccepted = false;
  final f = NumberFormat("#,##0", "pt_BR");
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  final controllerMap = Get.put(MapController());
  late GoogleMapController mapController;
  bool carregar = false;
  final CountDownController _controllertimer = CountDownController();
  ElapsedController elapsedCountUpController = ElapsedController();

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(
            locationSettings: LocationSettings(accuracy: LocationAccuracy.best))
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controllerMap.getAddress();
      posicaoV1 = position.latitude;
      posicaoV2 = position.longitude;
      posicaomotorista = "$posicaoV1,$posicaoV2";
    }).catchError((e) async {
    });
  }

  void controlCall() async {
    status_chamada = true;
    await SessionManager().set("status_chamada", true);
    call = false;
    await SessionManager().set("call", false);
  }

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  void VerificarPedido() async {
    DadosViagem();
    if (tempoPedido >= 1) {
      _controllertimer.pause();
      status_atendimento = 0;
      status_chamada = false;
      await SessionManager().set("status_chamada", false);
      call = false;
      await SessionManager().set("call", false);

      foregroundTaskService.FirstTaskHandler.showNotification(1, "Chamada Perdida", "A chamada foi perdida");

      // ignore: use_build_context_synchronously
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => SplashPage()));
    } else {}
  }

  late Timer _clock1;

  @override
  void initState() {
    super.initState();
    foregroundTaskService.startCallback();
    callAccepted = false;
    controlCall();
    DadosViagem();
    PegarTarifa();
    getCurrentLocation();
    pegarVariaveisViagem();
  }

  @override
  void dispose() {
    super.dispose();
    _controllertimer.pause();
  }

  void PegarTarifa() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/listar/tarifa');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final tarifa = map["tarifa"];
      if (tarifa.isNotEmpty) {
        tarifa_base = tarifa[0]['tarifa_base'] is String
            ? double.tryParse(tarifa[0]['tarifa_base'])!
            : tarifa[0]['tarifa_base'].toDouble();
        taxakm = tarifa[0]['tarifa_km'] is String
            ? double.tryParse(tarifa[0]['tarifa_km'])!
            : tarifa[0]['tarifa_km'].toDouble();
        inicio_cobranca = tarifa[0]['inicio_cobranca'] is String
            ? int.parse(tarifa[0]['inicio_cobranca'])
            : tarifa[0]['inicio_cobranca'];
        print(tarifa_base);
      }
    } catch (e) {
    }
  }

  Future DadosViagem() async {
    try {
      String baseURL = "$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final dados_pedido = map["pedido"];
      final dados_passageiro = map["passageiro"];
      print("=== dados_pedido 1 === $dados_pedido");
      // print("=== dados_passageiro 1 === $dados_passageiro");
      var pedido_aceite = dados_pedido['status'] == 2;
      setState(() {
        status_pedido = dados_pedido['status'] ?? 0;
        origem_viajante = dados_pedido['origem'] ?? "";
        destino_viajante = dados_pedido['destino'] ?? "";
        avaliacao_passageiro = map['avaliacao'] is String
            ? double.tryParse(map['avaliacao']) ?? 0.0
            : (map['avaliacao'] ?? 0.0).toDouble();
        origem1 = dados_pedido['desc_origem'] ?? "";
        destino1 = dados_pedido['desc_destino'] ?? "";
        metodo_pagamento = dados_pedido['metodo_pagamento'] ?? "";
        viajante = dados_passageiro['nome'] ?? "";
        passageiroOn = dados_passageiro['id'] ?? "";
        contacto_viajante = dados_pedido['contacto'] ?? "";
        foto_viajante = dados_passageiro['foto'] ?? "";
        CalculaViagem();
        if (origem_viajante.isNotEmpty && origem_viajante.contains(',')) {
          var origemSplit = origem_viajante.split(',');
          lat1 = double.tryParse(origemSplit[0]);
          long1 = double.tryParse(origemSplit[1]);
        } else {
          lat1 = null;
          long1 = null;
        }

        if (destino_viajante.isNotEmpty && destino_viajante.contains(',')) {
          var destinoSplit = destino_viajante.split(',');
          lat2 = double.tryParse(destinoSplit[0]);
          long2 = double.tryParse(destinoSplit[1]);
        } else {
          lat2 = null;
          long2 = null;
        }
        carregar = true;
      });
    } catch (e) {
      print("Erro ao carregar dados da viagem: $e");
    }
  }

  CalculaViagem() {
    setState(() {
      lat1 = double.tryParse(origem_viajante.toString().split(',')[0]);
      long1 = double.tryParse(origem_viajante.toString().split(',')[1]);
      lat2 = double.tryParse(destino_viajante.toString().split(',')[0]);
      long2 = double.tryParse(destino_viajante.toString().split(',')[1]);
      distance_rota = Geolocator.distanceBetween(lat1!, long1!, lat2!, long2!);
      calc_distancia_viagem = distance_rota / 1000;

      if (calc_distancia_viagem <= inicio_cobranca) {
        valorViagem = tarifa_base;
      } else {
        double distanciaContagem = calc_distancia_viagem - inicio_cobranca;
        valorViagem = (taxakm * distanciaContagem.round()) + tarifa_base;
      }
    });
  }

  Future getPosicaoMotorista() async {
    try {
      String baseURL = "$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=motorista';
      var response = await http.post(Uri.parse(request), body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final dados_pedido = map["pedido"];
      final dados_passageiro = map["passageiro"];
      origem_viajante = dados_pedido['origem'];
      destino_viajante = dados_pedido['destino'];
      avaliacao_passageiro = map['avaliacao'] is String
          ? double.parse(map['avaliacao'])
          : map['avaliacao'].toDouble();
      origem1 = dados_pedido['desc_origem'];
      destino1 = dados_pedido['desc_destino'];
      metodo_pagamento = dados_pedido['metodo_pagamento'];
      viajante = dados_passageiro['nome'];
      passageiroOn = dados_passageiro['id'];
      contacto_viajante = dados_pedido['contacto'];
      foto_viajante = dados_passageiro['foto'];
      status_pedido = dados_pedido['status'];
    } catch (e) {
    }
  }

  void pegarVariaveisViagem() async {
    btnIniciar = await SessionManager().get("btnIniciar");
    btnPausar = await SessionManager().get("btnPausar");
    btnPegar = await SessionManager().get("btnPegar");
    btnRetomar = await SessionManager().get("btnRetomar");
    btnConcluir = await SessionManager().get("btnConcluir");
  }

  Widget _BtnRejeitar() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Rejeitar();
        },
        child: const Icon(
          Icons.cancel_outlined,
          color: Color(0xFFFF0066),
          size: 40,
        ),
      ),
    );
  }

  loading load = loading();
  
  Future Aceitar() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$newEndpoint/corridaapi/pedido/aceitar');
      var response = await http.post(url, body: {
        "motorista": idMotoristaInteiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": numeropedido.toString(),
        "local_viatura": posicaomotorista.toString(),
      });
      final map = json.decode(response.body);
      print("------------------ map: $map");
      final dados = map["pedido"];
      setState(() {
        caller = true;
        status_atendimento = 1;
        status_pedido = dados['status'];
      });
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => DriverPage()),
        (Route<dynamic> route) => false,
      );
    } catch (e) {
      print("-----------------------e:::: $e");
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => PrincipalPage()),
        (Route<dynamic> route) => false,
      );
    }
  }

  Future Rejeitar() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/notificacao/regeitar');
      var response = await http.post(url, body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "notificacao": nNotificacao.toString(),
      });
      final map = json.decode(response.body);
      final dados = map["pedido"];
      _controllertimer.pause();
      setState(() {
        status_atendimento = 0;
        status_chamada = false;
        call = false;
      });
      await SessionManager().set("call", false);
      status_pedido = dados['status'];
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => PrincipalPage()),
        (Route<dynamic> route) => false,
      );
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => PrincipalPage()),
        (Route<dynamic> route) => false,
      );
    }
  }

  void _ApagarNotificacao() async {
    try {
      var url = Uri.parse('$endpoint/motoristaapi/notificacoes/apagar');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
    } catch (e) {
    }
  }

  Future Rejeitar2() async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/notificacao/regeitar');
      var response = await http.post(url, body: {
        "motorista": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "notificacao": nNotificacao.toString(),
      });
      final map = json.decode(response.body);
      final dados = map["pedido"];
      final retorno = map["retorno"];
      if (retorno == 1) {
        _controllertimer.pause();
        setState(() {
          status_atendimento = 0;
          status_chamada = false;
          call = false;
        });
        await SessionManager().set("call", false);
        status_pedido = dados['status'];
        _ApagarNotificacao();
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => PrincipalPage()),
          (Route<dynamic> route) => false,
        );
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message:
                'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => PrincipalPage()),
        (Route<dynamic> route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF00008B),
        body: carregar == false
            ? const Center(
                child: CircularProgressIndicator.adaptive(
                  strokeWidth: 20,
                  backgroundColor: Colors.white, //<-- SEE HERE
                ),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  SafeArea(
                      child: Padding(
                    padding: EdgeInsets.only(
                      right: MediaQuery.of(context).size.width / 1.2,
                      top: 5,
                      left: 10,
                    ),
                    child: Column(
                      children: [
                        _BtnRejeitar(),
                      ],
                    ),
                  )),
                  const SizedBox(
                    height: 15,
                  ),
                  const Align(
                    alignment: Alignment.center,
                    child: Text(
                      'Dados do Pedido',
                      style: TextStyle(
                        color: Colors.white,
                        letterSpacing: 0,
                        fontSize: 15.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham light',
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  viajante == null
                      ? const Text(
                          '----',
                          style: TextStyle(
                            color: Colors.white,
                            letterSpacing: 0,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'gotham',
                          ),
                        )
                      : Text(
                          '$viajante',
                          style: const TextStyle(
                            color: Colors.white,
                            letterSpacing: 0,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'gotham',
                          ),
                        ),
                  const SizedBox(
                    height: 10,
                  ),
                  ListTile(
                    leading: const Icon(Icons.gps_fixed,
                        size: 30, color: Color(0xFFFF0066)),
                    title: origem1 == null
                        ? const Text(
                            "----",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          )
                        : Text(
                            "$origem1",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                            overflow: TextOverflow.visible,
                            maxLines: 1,
                          ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.album_outlined,
                        size: 30, color: Color(0xFFFF0066)),
                    title: destino1 == null
                        ? const Text(
                            "----",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          )
                        : Text(
                            "$destino1",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                            overflow: TextOverflow.visible,
                            maxLines: 1,
                          ),
                  ),
                  const Divider(
                    height: 30,
                    color: Colors.white,
                  ),
                  ListTile(
                    trailing: const Icon(Icons.monetization_on_sharp,
                        size: 30, color: Color(0xFFFF0066)),
                    title: calc_distancia_viagem == 0.0
                        ? const Text(
                            "0 Km",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          )
                        : Text(
                            "${f.format(calc_distancia_viagem).toString()} Km",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                    subtitle: valorViagem == 0.0
                        ? const Text(
                            "0.0",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 35.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          )
                        : Text(
                            "${f.format(valorViagem).toString()} Kz",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 25.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                  ),
                  const Divider(
                    height: 15,
                    color: Colors.white,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: LiteRollingSwitch(
                      value: false,
                      textOn: 'Cancelar',
                      textOff: 'Atender',
                      colorOn: const Color(0xFFFF0066),
                      colorOff: Colors.green,
                      iconOn: Icons.call_end,
                      iconOff: Icons.call,
                      width: MediaQuery.of(context).size.width * 0.8,
                      textOffColor: Colors.white,
                      textOnColor: Colors.white,
                      textSize: 20.0,
                      onChanged: (bool state) {
                        if (state == true) {
                          _controllertimer.pause();
                          Aceitar();
                        }
                      },
                      onTap: (bool state) {
                      },
                      onDoubleTap: (bool state) {},
                      onSwipe: (bool state) {},
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CircularCountDownTimer(
                    duration: tempoDuracao,
                    initialDuration: 0,
                    controller: _controllertimer,
                    width: 100,
                    height: 100,
                    ringColor: Colors.grey[300]!,
                    ringGradient: null,
                    fillColor: const Color(0xFF00008B),
                    fillGradient: null,
                    backgroundColor: const Color(0xFFFF0066),
                    backgroundGradient: null,
                    strokeWidth: 20.0,
                    strokeCap: StrokeCap.round,
                    textStyle: const TextStyle(
                        fontSize: 33.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                    textFormat: CountdownTextFormat.S,
                    isReverse: true,
                    isReverseAnimation: true,
                    isTimerTextShown: true,
                    autoStart: true,
                    onStart: () {
                    },
                    onComplete: () {
                    },
                    onChange: (String timeStamp) {
                    },
                    timeFormatterFunction:
                        (defaultFormatterFunction, duration) {
                      if (duration.inSeconds == 0 && status_atendimento == 0) {
                        setState(() {
                          status_atendimento = 1;
                        });
                        Rejeitar2();
                        showTopSnackBar(
                          // ignore: use_build_context_synchronously
                          Overlay.of(context),
                          const CustomSnackBar.info(
                            message: 'Chamada atendida pelo outro Piloto.',
                          ),
                        );
                        return "0";
                      } else {
                        return Function.apply(
                            defaultFormatterFunction, [duration]);
                      }
                    },
                  ),
                ],
              ));
  }
}
