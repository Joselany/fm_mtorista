import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';

class EditarSenhaPage extends StatefulWidget {
  @override
  _EditarSenhaPage createState() => _EditarSenhaPage();
}

class _EditarSenhaPage extends State<EditarSenhaPage> {
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  late bool _toggleVisibility2 = true;
  var seguro = true;

  final TextEditingController _senha = TextEditingController();
  final TextEditingController _senha2 = TextEditingController();

  loading load = loading();

  Future AlterarSenha() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri.parse('$endpoint/motoristaapi/senha');
      var response = await http.post(url, body: {
        "id": idMotorista.toString(),
        "chave_publica": ChavePublica.toString(),
        "antigasenha": _senha.text,
        "novasenha": _senha2.text,
      });
      final map = json.decode(response.body);
      // final msgr = map["retorno"];
      final msg = map["msg"];
      if (msg == 'Senha alterada com sucesso') {
        // ignore: use_build_context_synchronously
        setState(() {
          btnRg2 = false;
        });
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Senha alterada com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else {
        setState(() {
          btnRg2 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Senha actual inválida. Tente novamente!',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
  }

  Widget _TxtSenha() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Palavra-passe actual",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.lock_outline,
          color: Color(0xFF00008B),
          size: 25,
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _toggleVisibility = !_toggleVisibility;
            });
          },
          icon: _toggleVisibility
              ? const Icon(
                  Icons.visibility_off_outlined,
                  size: 20,
                )
              : const Icon(
                  Icons.visibility_outlined,
                  size: 20,
                ),
          color: const Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _senha,
        obscureText: _toggleVisibility,
      ),
    );
  }

  Widget _TxtSenha2() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFEDEEE9))),
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nova Palavra-passe",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.lock_outline,
          color: Color(0xFF00008B),
          size: 25,
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _toggleVisibility2 = !_toggleVisibility2;
            });
          },
          icon: _toggleVisibility2
              ? const Icon(
                  Icons.visibility_off_outlined,
                  size: 20,
                )
              : const Icon(
                  Icons.visibility_outlined,
                  size: 20,
                ),
          color: const Color(0xFF00008B),
        ),
        validator: FormValidation.requiredTextField,
        controller: _senha2,
        obscureText: _toggleVisibility2,
      ),
    );
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: btnRg2 == false
            ? () {
                if (_senha.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe a palavra-passe actual.',
                    ),
                  );
                } else if (_senha2.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe a nova palavra-passe.',
                    ),
                  );
                } else {
                  AlterarSenha();
                }
              }
            : () {},
        child: btnRg2 == false
            ? const Text(
                'Alterar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFFF0066),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SafeArea(
              child: Column(
            children: [
              SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(
                      height: 100,
                    ),
                    _TxtSenha(),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtSenha2(),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          _BtnComecar(),
                          const SizedBox(
                            height: 10,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Actualizar Palavra-passe",
          style: TextStyle(
            color: Colors.black,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Color(0xFFFF0066)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFFF0066), size: 40),
      ),
    );
  }
}
