import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'LoginPage.dart';

class IniciarPage extends StatefulWidget {
  @override
  _IniciarPage createState() => _IniciarPage();
}

class _IniciarPage extends State<IniciarPage> {
  late LocationPermission permission;
  late bool activado;

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: () async {
          permission = await Geolocator.checkPermission();
          if (permission == LocationPermission.denied) {
            _SolicitarPermissao();
          } else {
            // ignore: use_build_context_synchronously
            Navigator.of(context).pushReplacement(CupertinoPageRoute(
                builder: (BuildContext context) => LoginPage()));
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text(
            'Iniciar',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
          ),
        ),
      ),
    );
  }

  Future<Position> posicaoActual() async {
    activado = await Geolocator.isLocationServiceEnabled();
    if (!activado) {
      return Future.error('Por favor, habilite a sua localização');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      return Future.error('Você precisa autorizar o acesso à localização');
    }
    return await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(accuracy: LocationAccuracy.best));
  }

  Future<void> _SolicitarPermissao() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Política de Privacidade'),
          content: const SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Center(
                  child: Text(
                      'Melhore a sua experiência de viagem com informações de Localização!',
                      overflow: TextOverflow.visible,
                      maxLines: 2,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'gotham',
                      )),
                ),
                SizedBox(height: 10),
                Center(
                  child: Text('Porquê pedimos acesso à sua localização?',
                      overflow: TextOverflow.visible,
                      maxLines: 2,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'gotham',
                      )),
                ),
                SizedBox(height: 10),
                Center(
                  child: Text(
                      "O aplicativo recolhe as suas informações de localização mesmo quando o aplicativo estiver em segundo plano para rastrear a sua posição. Deste modo, permite que o aplicativo lhe atribua o motorista mais próximo e fornece actualizações precisas sobre a chegada do mesmo ao local de recolha.",
                      overflow: TextOverflow.visible,
                      maxLines: 5,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      )),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Rejeitar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Aceitar'),
              onPressed: () {
                posicaoActual();
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacement(CupertinoPageRoute(
                    builder: (BuildContext context) => LoginPage()));
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF00008B),
        body: Stack(
          children: [
            const Center(
              child: Image(
                image: AssetImage("assets/images/logo_branco.png"),
                width: 280,
                height: 154,
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _BtnComecar(),
                  const SizedBox(
                    height: 200,
                  )
                ],
              ),
            ),
          ],
        ));
  }
}
