import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:future_progress_dialog/future_progress_dialog.dart';
import '../config/Constats.dart';
import 'ChamadaPage.dart';
import 'DriverPage.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'AvaliarPage.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class FinalizarPage extends StatefulWidget {
  @override
  _FinalizarPage createState() => _FinalizarPage();
}

class _FinalizarPage extends State<FinalizarPage> {
  final f = NumberFormat("#,##0", "pt_BR");
  loading load = loading();

  @override
  void initState() {
    super.initState();
  }

  Future ActualizaPedido(String status) async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/corridaapi/pedido/actualizar');
      var response = await http.post(url, body: {
        "status": status,
        "pedido": numeropedido.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        LiberarVariaveisViagem();
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => AvaliarPage()),
          (Route<dynamic> route) => false,
        );
      }
    } catch (e) {
      print(e);
    }
  }

  void LiberarVariaveisViagem() async {
    await SessionManager().set("status_viagem", false);
    await SessionManager().set("btnIniciar", false);
    await SessionManager().set("btnPausar", false);
    await SessionManager().set("btnPegar", false);
    await SessionManager().set("btnRetomar", false);
    await SessionManager().set("btnConcluir", false);
    await SessionManager().set("call", false);
    status_viagem = false;
    btnIniciar = false;
    btnPausar = false;
    btnPegar = false;
    btnRetomar = false;
    btnConcluir = false;
    status_chamada = false;
    call = false;
  }

  Future FinalizarViagem() async {
    try {
      var url = Uri.parse('$endpoint/corridaapi/viagem/finalizar');
      var response = await http.post(url, body: {
        "viagem": idViagem.toString(),
        "valor": valorViagem.toString(),
        "valor_pago": valorViagem.toString(),
        "metodo_pagamento": metodo_pagamento.toString(),
      });
      final map = json.decode(response.body);
    } catch (e) {
      print(e);
    }
  }

  Widget _BtnFinalizar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0066),
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: () {
          FinalizarViagem();
          ActualizaPedido("8");
        },
        child: const Text(
          'Finalizar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFEDEEE9),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 30,
            ),
            Text(
              'Recibo# $idViagem',
              style: const TextStyle(
                color: Color(0xFFFF0066),
                fontSize: 22.0,
                fontWeight: FontWeight.normal,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            ListTile(
              leading: const Icon(Icons.gps_fixed,
                  size: 30, color: Color(0xFFFF0066)),
              title: origem1 == null
                  ? const Text(
                      "----",
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      ),
                    )
                  : Text(
                      "$origem1",
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      ),
                      overflow: TextOverflow.visible,
                      maxLines: 1,
                    ),
            ),
            ListTile(
              leading: const Icon(Icons.album_outlined,
                  size: 30, color: Color(0xFFFF0066)),
              title: destino1 == null
                  ? const Text(
                      "----",
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      ),
                    )
                  : Text(
                      "$destino1",
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      ),
                      overflow: TextOverflow.visible,
                      maxLines: 1,
                    ),
            ),
            const Divider(
              height: 30,
              color: Color(0xFFFF0066),
            ),
            ListTile(
              leading:
                  const Icon(Icons.timer, size: 30, color: Color(0xFFFF0066)),
              title: const Text(
                "Tempo de Viagem",
                style: TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 10.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "$tempo_viagem",
                style: const TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 20.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 10,
              color: Color(0xFFEDEEE9),
            ),
            ListTile(
              leading: const Icon(Icons.access_time_filled_rounded,
                  size: 30, color: Color(0xFFFF0066)),
              title: const Text(
                "Taxa de Paragem",
                style: TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 10.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "${f.format(valorParagem.roundToDouble()).toString()} Kz",
                style: const TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 20.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 10,
              color: Color(0xFFEDEEE9),
            ),
            ListTile(
              leading: const Icon(Icons.monetization_on_sharp,
                  size: 30, color: Color(0xFFFF0066)),
              title: const Text(
                "Desconto",
                style: TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 10.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "${f.format(desconto).toString()} Kz",
                style: const TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 20.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 10,
              color: Color(0xFFEDEEE9),
            ),
            ListTile(
              leading: const Icon(Icons.monetization_on_sharp,
                  size: 30, color: Color(0xFFFF0066)),
              title: const Text(
                "Total da Viagem",
                style: TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 10.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "${f.format(valorViagem.roundToDouble()).toString()} Kz",
                style: const TextStyle(
                  color: Color(0xFFFF0066),
                  fontSize: 25.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            _BtnFinalizar(),
          ],
        ));
  }
}
