import 'package:flutter/material.dart';

const kHintTextStyle = TextStyle(
  color: Color(0XFF363436),
  fontFamily: 'gotham',
);

const kLabelStyle = TextStyle(
  color: Colors.black,
  fontWeight: FontWeight.bold,
  fontFamily: 'gotham',
);

const kLabelStyle2 = TextStyle(
  color: Colors.white,
  fontWeight: FontWeight.bold,
  fontFamily: 'gotham',
);

const kLabelStyle3 = TextStyle(
  color: Colors.white,
  fontWeight: FontWeight.normal,
  fontFamily: 'gotham',
  fontSize: 11,
);

final kBoxDecorationStyle = BoxDecoration(
  color: const Color(0xFFFBFCFD),
  borderRadius: BorderRadius.circular(100),
  boxShadow: const [
    BoxShadow(
      color: Color(0xFFE70A0A),
      blurRadius: 6.0,
      offset: Offset(0, 2),
    ),
  ],
);

final kBoxDecorationStyle2 = BoxDecoration(
  color: const Color(0xFFFBFCFD),
  borderRadius: BorderRadius.circular(5),
  boxShadow: const [
    BoxShadow(
      color: Color(0xFFE70A0A),
      blurRadius: 6.0,
      offset: Offset(0, 2),
    ),
  ],
);