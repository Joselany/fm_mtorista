import 'package:flutter/material.dart';

class CardChat extends StatefulWidget {
  final String mensagem;
  final String data;
  final String hora;
  final String id;
  final String status;

  CardChat(
      {required this.id,
      required this.data,
      required this.hora,
      required this.mensagem,
      required this.status});

  @override
  _CardChatState createState() => _CardChatState();
}

class _CardChatState extends State<CardChat> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFBFCFD),
            Color(0xFFFBFCFD),
            Color(0xFFFBFCFD),
            Color(0xFFFBFCFD),
          ],
          stops: [0.1, 0.4, 0.7, 0.9],
        ),
      ),
      child: widget.status == "1"
          ? ListTile(
              selectedTileColor: Colors.blueAccent,
              hoverColor: Colors.blueAccent,
              leading: IconButton(
                icon: const Icon(
                  Icons.message_outlined,
                  color: Colors.blueAccent,
                  size: 20,
                ),
                onPressed: () {},
              ),
              title: Text(
                widget.mensagem,
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 11.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "${widget.data} ${widget.hora}",
                style: const TextStyle(
                  color: Colors.black45,
                  fontSize: 9.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            )
          : ListTile(
              selectedTileColor: Colors.blueAccent,
              trailing: IconButton(
                icon: const Icon(
                  Icons.insert_comment_sharp,
                  color: Colors.grey,
                  size: 20,
                ),
                onPressed: () {},
              ),
              title: Text(
                widget.mensagem,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 11.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "${widget.data} ${widget.hora}",
                style: const TextStyle(
                  color: Colors.black45,
                  fontSize: 9.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
    );
  }
}
