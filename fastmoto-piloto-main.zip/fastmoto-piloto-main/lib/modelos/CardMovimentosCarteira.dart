// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'dart:typed_data';
import 'package:fastmoto_piloto/pages/CarteiraPage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:image_picker/image_picker.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:material_dialogs/dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../pages/Loading.dart';
import '../pages/PrincipalPage.dart';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';

var fotoComprovativo;
var pdfComprovativo;

var idMovimento;

class CardMovimentosCarteira extends StatefulWidget {
  final String id;
  final String data;
  final String valor;
  final String tipo;
  final String metodo_pagamento;
  final String estado;
  String comprovativo;

  CardMovimentosCarteira(
      {required this.id,
      required this.data,
      required this.valor,
      required this.tipo,
      required this.metodo_pagamento,
      required this.estado,
      required this.comprovativo});

  @override
  _CardMovimentosCarteiraState createState() => _CardMovimentosCarteiraState();
}

class _CardMovimentosCarteiraState extends State<CardMovimentosCarteira> {
  File? fotoComprovativo;
  XFile? _fotoComprovativo;

  loading load = loading();

  final picker = ImagePicker();

  // Foto do Comprovativo
  Future getFotoGaleria() async {
    _fotoComprovativo = await picker.pickImage(source: ImageSource.gallery);
    if (_fotoComprovativo != null) {
      setState(() {
        fotoComprovativo = File(_fotoComprovativo!.path);
      });
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadFoto();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  late File file;
  late String filename;
  late String filePath;

  // PDF do Comprovativo
  Future getArquivoGaleria() async {
    FilePickerResult? _pdfComprovativo = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (_pdfComprovativo != null) {
      setState(() async {
        file = File(_pdfComprovativo.files.first.path!);
        if (file.existsSync()) {
          filename = _pdfComprovativo.files.first.name;
        }
      });

      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar o documento?',
          title: 'Upload do documento',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: const Color(0xFFFF0066),
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                UploadPdf();
              },
              text: 'Sim',
              iconData: Icons.done,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadFoto() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri.parse('$endpoint/motoristaapi/saldo-carregar-img');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idMotorista.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      response.fields['id_movimento'] = idMovimento.toString();
      var pic = await http.MultipartFile.fromPath(
          "comprovativo", fotoComprovativo!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Carregado com sucesso.',
          ),
        );
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarteiraPage()));
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o Comprovativo.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: e.toString(),
        ),
      );
      print("erro ao carregar a foto do comprovativo");
      print(e);
    }
  }

// Carregar PDF
  Future<dynamic> UploadPdf() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      String token = "12345";
      var fileName = filename.split("/").last;
      var formData = FormData.fromMap({
        'id': idMotorista.toString(),
        'chave_publica': ChavePublica.toString(),
        'id_movimento': idMovimento.toString(),
        'comprovativo': await MultipartFile.fromFile(file.path,
            filename: fileName, contentType: MediaType('application', 'pdf')),
        "type": "application/pdf"
      });
      var response = await Dio().post(
          '${pathURL}motoristaapi/saldo-carregar-pdf',
          options: Options(
              contentType: 'multipart/form-data',
              headers: {HttpHeaders.authorizationHeader: 'Token $token'}),
          data: formData);
      if (response.statusCode == 200) {
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Arquivo carregado com sucesso.',
          ),
        );
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarteiraPage()));
        // ignore: use_build_context_synchronously
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar o Comprovativo.',
          ),
        );
      }
      return response;
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: e.toString(),
        ),
      );
      print("erro ao carregar o arquivo do comprovativo");
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
            ],
            stops: [0.1, 0.4, 0.7, 0.9],
          ),
        ),
        child: Column(
          children: [
            InkWell(
                onTap: () {},
                child: widget.tipo == "Débito"
                    ? Card(
                        elevation: 10,
                        child: Column(
                          children: [
                            ListTile(
                              leading: IconButton(
                                icon: const Icon(
                                  Icons.monetization_on_sharp,
                                  color: Colors.red,
                                  size: 30,
                                ),
                                onPressed: () {},
                              ),
                              trailing: Text(
                                "-${NumberFormat.currency(locale: 'eu', symbol: 'KZ').format(double.parse(widget.valor))}",
                                style: const TextStyle(
                                  color: Colors.red,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              ),
                              title: const Text(
                                "Pagamento efectivada",
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              ),
                              subtitle: Text(
                                widget.data,
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 11.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                          ],
                        ))
                    : Card(
                        elevation: 10,
                        child: Column(
                          children: [
                            ListTile(
                              leading: IconButton(
                                icon: widget.estado == "1"
                                    ? widget.comprovativo == 'Nulo'
                                        ? const Icon(
                                            Icons.upload,
                                            color: Color(0xFFFF0066),
                                            size: 30,
                                          )
                                        : const Icon(
                                            Icons.attach_file,
                                            color: Color(0xFFFF0066),
                                            size: 30,
                                          )
                                    : widget.estado == "0"
                                        ? const Icon(
                                            Icons.cancel_outlined,
                                            color: Colors.red,
                                            size: 30,
                                          )
                                        : const Icon(
                                            Icons.monetization_on_sharp,
                                            color: Colors.green,
                                            size: 30,
                                          ),
                                onPressed: () {
                                  idMovimento = widget.id;
                                  if (widget.estado == "1" &&
                                      widget.comprovativo == 'Nulo') {
                                    Dialogs.bottomMaterialDialog(
                                        msg: 'Escolha o Formato do Ficheiro',
                                        title: 'Carregar Comprovativo',
                                        context: context,
                                        actions: [
                                          IconsOutlineButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                              getArquivoGaleria();
                                            },
                                            text: 'PDF',
                                            iconData: Icons.picture_as_pdf,
                                            color: const Color(0xFFFF0066),
                                            textStyle: const TextStyle(
                                                color: Colors.white),
                                            iconColor: Colors.white,
                                          ),
                                          IconsButton(
                                            onPressed: () async {
                                              Navigator.of(context).pop();
                                              getFotoGaleria();
                                            },
                                            text: 'Imagem',
                                            iconData: Icons.image,
                                            color: const Color(0xFFFF0066),
                                            textStyle: const TextStyle(
                                                color: Colors.white),
                                            iconColor: Colors.white,
                                          ),
                                        ]);
                                  } else {}
                                },
                              ),
                              trailing: Text(
                                "+${NumberFormat.currency(locale: 'eu', symbol: 'KZ').format(double.parse(widget.valor))}",
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'gotham',
                                ),
                              ),
                              title: widget.estado == "1"
                                  ? widget.comprovativo == 'Nulo'
                                      ? const Text(
                                          "Enviar Comprovativo",
                                          style: TextStyle(
                                            color: Color(0xFFFF0066),
                                            fontSize: 12.0,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'gotham',
                                          ),
                                        )
                                      : const Text(
                                          "Aprovação Pendente",
                                          style: TextStyle(
                                            color: Color(0xFFFF0066),
                                            fontSize: 12.0,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'gotham',
                                          ),
                                        )
                                  : widget.estado == "2"
                                      ? const Text(
                                          "Operação efectivada",
                                          style: TextStyle(
                                            color: Colors.green,
                                            fontSize: 12.0,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'gotham',
                                          ),
                                        )
                                      : widget.estado == "0"
                                          ? const Text(
                                              "Operação Cancelada",
                                              style: TextStyle(
                                                color: Colors.red,
                                                fontSize: 12.0,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'gotham',
                                              ),
                                            )
                                          : const Text(
                                              "",
                                              style: TextStyle(
                                                color: Colors.black54,
                                                fontSize: 12.0,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'gotham',
                                              ),
                                            ),
                              subtitle: Text(
                                widget.data,
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 11.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                          ],
                        ))),
          ],
        ));
  }
}
