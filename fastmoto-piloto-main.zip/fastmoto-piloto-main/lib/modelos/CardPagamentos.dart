import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';


class CardPagamentos extends StatefulWidget {
  final String data;
  final String id;
  final String valor;
  final String valor_comissao;
  final String metodo_pagamento;

  CardPagamentos({required this.id, required this.data, required, required this.valor, required this.valor_comissao, required this.metodo_pagamento});

  @override
  _CardPagamentosState createState() => _CardPagamentosState();
}
class _CardPagamentosState extends State<CardPagamentos> {


  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
            ],
            stops: [0.1, 0.4, 0.7, 0.9],
          ),
        ),
        child:Column(
          children: [
            Card(
                elevation: 10,
                child: Column(
                  children: [
                    ListTile(
                      selectedTileColor: const Color(0xFFFF0066),
                      leading: IconButton(
                        icon: const Icon(
                          Icons.monetization_on_sharp,
                          color: Color(0xFFFF0066),
                          size: 15,
                        ), onPressed: () {  },
                      ),
                      title: Text(
                        NumberFormat.currency(locale: 'eu', symbol: 'KZ').format(double.parse(widget.valor)),
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 22.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                      subtitle: Text(
                        widget.metodo_pagamento,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 14.0,
                          fontWeight: FontWeight.normal,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    ListTile(
                      selectedTileColor: const Color(0xFFFF0066),
                      leading: IconButton(
                        icon: const Icon(
                          Icons.date_range,
                          color: Color(0xFFFF0066),
                          size: 15,
                        ), onPressed: () {  },
                      ),
                      title: Text(
                        widget.data,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 10.0,
                          fontWeight: FontWeight.normal,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                  ],
                )
            ),
          ],
        )

    );
  }
}



