const google_api_key = "AIzaSyB0R8RyGL1x3IcwjThoUxnBROm21nxn_3Y";
const versionApp = "2.7";

const dom = "";
const endpoint = "http://159.89.52.185:8080";
const pathURL = "http://159.89.52.185:8080/";
const urlImagem = "http://159.89.52.185:8080/";

const newEndpoint = "http://208.68.37.81:3000";

const country = "Angola";
const language = "pt";
const reg = "Luanda";
