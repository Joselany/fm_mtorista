import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:fastmoto_piloto/pages/foregroundService.dart';
import 'package:flutter/material.dart';
import 'package:location_permissions/location_permissions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fastmoto_piloto/pages/SplashPage.dart';
import 'package:fastmoto_piloto/pages/LocalNotification.dart';
import 'package:fastmoto_piloto/pages/ForegroundTaskService.dart' as foregroundTaskService;

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  ForegroundTaskService.init();

  Permission.notification.request();
  await LocationPermissions().requestPermissions();

  await LocalNotification.initialize(flutterLocalNotificationsPlugin); 

  foregroundTaskService.startCallback();

  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashPage(),
  ));
}
