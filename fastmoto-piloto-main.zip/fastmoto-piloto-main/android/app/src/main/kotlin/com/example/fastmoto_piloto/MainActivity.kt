package com.fastmoto.piloto.fastmoto_piloto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
