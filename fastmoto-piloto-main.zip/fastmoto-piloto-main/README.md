# fastmoto_piloto

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

Celular: 938031220
Celular: 925457688
Senha: 123456
925457688

Os dois usuários têm os mesmos acessos.

Query:

select * from public.tbnotificacao_motorista t where t.motorista in (909)