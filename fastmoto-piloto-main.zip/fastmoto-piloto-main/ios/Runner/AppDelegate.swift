import Flutter
import UIKit
import PushKit
import GoogleMaps
import GoogleMapsUtils
import flutter_local_notifications
import flutter_foreground_task
import UserNotifications
import flutter_callkit_incoming

@main
@objc class AppDelegate: FlutterAppDelegate, PKPushRegistryDelegate {

    var voipRegistry: PKPushRegistry?

    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        
        GMSServices.provideAPIKey("AIzaSyB0R8RyGL1x3IcwjThoUxnBROm21nxn_3Y")
        GeneratedPluginRegistrant.register(with: self)
            SwiftFlutterForegroundTaskPlugin.setPluginRegistrantCallback { registry in
            GeneratedPluginRegistrant.register(with: registry)
            }
            if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().delegate = self as? UNUserNotificationCenterDelegate
            }
        // Configuração do PushKit para chamadas VoIP
        configureVoIPPush()
        application.registerForRemoteNotifications()
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }

    // MARK: - Configuração do PushKit (VoIP)
    private func configureVoIPPush() {
        let mainQueue = DispatchQueue.main
        voipRegistry = PKPushRegistry(queue: mainQueue)
        voipRegistry?.delegate = self
        voipRegistry?.desiredPushTypes = [.voIP]
    }

    // MARK: - Resumo de Atividades do App (CallKit)
    override func application(
        _ application: UIApplication,
        continue userActivity: NSUserActivity,
        restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void
    ) -> Bool {
        
        guard let handleObj = userActivity.handle,
              let isVideo = userActivity.isVideo else {
            return false
        }
        
        let objData = handleObj.getDecryptHandle()
        let nameCaller = objData["nameCaller"] as? String ?? ""
        let handle = objData["handle"] as? String ?? ""
        
        let callData = flutter_callkit_incoming.Data(
            id: UUID().uuidString,
            nameCaller: nameCaller,
            handle: handle,
            type: isVideo ? 1 : 0
        )
        
        SwiftFlutterCallkitIncomingPlugin.sharedInstance?.startCall(callData, fromPushKit: true)
        application.registerForRemoteNotifications()
        return super.application(application, continue: userActivity, restorationHandler: restorationHandler)
    }

    // MARK: - PKPushRegistryDelegate (Gerenciamento do VoIP Push)
    func pushRegistry(
        _ registry: PKPushRegistry,
        didUpdate credentials: PKPushCredentials,
        for type: PKPushType
    ) {
        let deviceToken = credentials.token.map { String(format: "%02x", $0) }.joined()
        SwiftFlutterCallkitIncomingPlugin.sharedInstance?.setDevicePushTokenVoIP(deviceToken)
        print("✅ VoIP Token atualizado: \(deviceToken)")
    }

    func pushRegistry(
        _ registry: PKPushRegistry,
        didInvalidatePushTokenFor type: PKPushType
    ) {
        SwiftFlutterCallkitIncomingPlugin.sharedInstance?.setDevicePushTokenVoIP("")
        print("⚠️ Token VoIP inválido, removido.")
    }

    func pushRegistry(
        _ registry: PKPushRegistry,
        didReceiveIncomingPushWith payload: PKPushPayload,
        for type: PKPushType,
        completion: @escaping () -> Void
    ) {
        guard type == .voIP else { return }

        let id = payload.dictionaryPayload["id"] as? String ?? UUID().uuidString
        let nameCaller = payload.dictionaryPayload["nameCaller"] as? String ?? "Chamada Recebida"
        let handle = payload.dictionaryPayload["handle"] as? String ?? "Desconhecido"
        let isVideo = payload.dictionaryPayload["isVideo"] as? Bool ?? false

        let callData = flutter_callkit_incoming.Data(
            id: id,
            nameCaller: nameCaller,
            handle: handle,
            type: isVideo ? 1 : 0
        )
        callData.extra = ["user": "abc@123", "platform": "ios"]

        SwiftFlutterCallkitIncomingPlugin.sharedInstance?.showCallkitIncoming(callData, fromPushKit: true)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            completion()
        }
        print("📞 Chamada recebida via PushKit: \(nameCaller) - \(handle)")
    }
}
